import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const serverSrc = readFileSync(new URL("./server.js", import.meta.url), "utf8");

test("server exposes all required AI video proxy endpoints and production Veo 3.1 models", () => {
  assert.ok(serverSrc.includes('"/health"'));
  assert.ok(serverSrc.includes('"/api/ai-video/enhance-prompt"'));
  assert.ok(serverSrc.includes('"/api/ai-video/start"'));
  assert.ok(serverSrc.includes('"/api/ai-video/status"'));
  assert.ok(serverSrc.includes('"/api/ai-video/download"'));
  assert.ok(serverSrc.includes("veo-3.1-fast-generate-001"));
  assert.ok(serverSrc.includes("veo-3.1-generate-001"));
  assert.ok(serverSrc.includes("veo-3.1-lite-generate-001"));
  assert.ok(serverSrc.includes("predictLongRunning"));
  assert.ok(serverSrc.includes("https://generativelanguage.googleapis.com/"));
});
