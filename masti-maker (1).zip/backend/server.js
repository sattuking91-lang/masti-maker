import express from "express";

const expressApp = express();
expressApp.use(express.json({ limit: "1mb" }));

const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta";
const PROMPT_MODEL = process.env.GEMINI_PROMPT_MODEL || "gemini-2.5-flash";

const ALLOWED_VEO_MODELS = new Set([
  "veo-3.1-fast-generate-001",
  "veo-3.1-generate-001",
  "veo-3.1-lite-generate-001",
]);

const ALLOWED_ASPECT_RATIOS = new Set(["9:16", "16:9"]);
const ALLOWED_DURATIONS = new Set([4, 6, 8]);
const ALLOWED_RESOLUTIONS = new Set(["720p", "1080p", "4k"]);

function getApiKey() {
  return (process.env.GEMINI_API_KEY || "").trim();
}

function classifyGoogleError(status, bodyText) {
  const lower = (bodyText || "").toLowerCase();
  const billingRequired =
    status === 402 ||
    lower.includes("billing") ||
    lower.includes("paid") ||
    lower.includes("quota") ||
    lower.includes("resource_exhausted") ||
    lower.includes("permission_denied");

  let parsedMessage = bodyText;
  try {
    const parsed = JSON.parse(bodyText);
    parsedMessage = parsed?.error?.message || bodyText;
  } catch {
    // Keep raw text fallback
  }

  return {
    httpStatus: status >= 400 ? status : 502,
    billingRequired,
    message: parsedMessage || `Google API returned HTTP ${status}`,
  };
}

expressApp.get("/health", (_req, res) => {
  res.json({
    ok: true,
    service: "masti-maker-ai-video-backend",
    apiKeyConfigured: Boolean(getApiKey()),
    promptModel: PROMPT_MODEL,
    supportedVeoModels: Array.from(ALLOWED_VEO_MODELS),
  });
});

/**
 * Step 1: Convert user Hindi/English script + animal characters into a detailed cinematic Veo 3.1 prompt.
 */
expressApp.post("/api/ai-video/enhance-prompt", async (req, res) => {
  const apiKey = getApiKey();
  if (!apiKey) {
    return res.status(503).json({
      error: "Backend GEMINI_API_KEY is not configured on Cloud Run.",
      billingRequired: false,
    });
  }

  const { script, animals, aspectRatio, durationSeconds } = req.body || {};
  const cleanedScript = String(script || "").trim();
  if (!cleanedScript) {
    return res.status(400).json({ error: "Script or story text is required." });
  }

  const animalList = Array.isArray(animals) && animals.length > 0
    ? animals.map((a) => String(a).trim()).filter(Boolean).join(", ")
    : "cute animated cat and puppy";

  const ratio = ALLOWED_ASPECT_RATIOS.has(aspectRatio) ? aspectRatio : "9:16";
  const duration = ALLOWED_DURATIONS.has(Number(durationSeconds)) ? Number(durationSeconds) : 8;

  const systemInstruction =
    "You are an expert 3D Pixar-style family animation director for Veo 3.1 video generation. " +
    "Convert the user's Hindi or English story/script and selected animals into ONE vivid, cinematic, " +
    "kid-friendly English video generation prompt. Emphasize continuous natural full-body motion: " +
    "walking, dancing, jumping, playing, joyful facial expressions, tail wagging, dynamic camera tracking, " +
    "and vibrant 3D lighting framed for " + ratio + " (" + duration + "s clip). " +
    "Return strictly valid JSON with keys: enhancedPrompt (string), sceneSummary (string), detectedLanguage (string).";

  const userPrompt =
    `User script: "${cleanedScript}"\n` +
    `Selected animal characters: ${animalList}\n` +
    `Target framing: ${ratio}, duration: ${duration} seconds.`;

  try {
    const response = await fetch(
      `${GEMINI_BASE}/models/${encodeURIComponent(PROMPT_MODEL)}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemInstruction }] },
          contents: [{ role: "user", parts: [{ text: userPrompt }] }],
          generationConfig: {
            temperature: 0.7,
            responseMimeType: "application/json",
          },
        }),
      }
    );

    const rawText = await response.text();
    if (!response.ok) {
      const info = classifyGoogleError(response.status, rawText);
      return res.status(info.httpStatus).json({
        error: info.message,
        billingRequired: info.billingRequired,
      });
    }

    const data = JSON.parse(rawText);
    const textPart = data?.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
    let parsedJson = {};
    try {
      parsedJson = JSON.parse(textPart);
    } catch {
      parsedJson = {
        enhancedPrompt: textPart,
        sceneSummary: cleanedScript,
        detectedLanguage: "auto",
      };
    }

    return res.json({
      enhancedPrompt: String(parsedJson.enhancedPrompt || textPart).trim(),
      sceneSummary: String(parsedJson.sceneSummary || cleanedScript).trim(),
      detectedLanguage: String(parsedJson.detectedLanguage || "auto"),
    });
  } catch (err) {
    return res.status(502).json({
      error: `Failed to enhance prompt: ${err.message}`,
      billingRequired: false,
    });
  }
});

/**
 * Step 2: Start asynchronous Veo 3.1 video generation via :predictLongRunning.
 */
expressApp.post("/api/ai-video/start", async (req, res) => {
  const apiKey = getApiKey();
  if (!apiKey) {
    return res.status(503).json({
      error: "Backend GEMINI_API_KEY is not configured on Cloud Run.",
      billingRequired: false,
    });
  }

  const { prompt, model, aspectRatio, durationSeconds, resolution } = req.body || {};
  const cleanedPrompt = String(prompt || "").trim();
  if (!cleanedPrompt) {
    return res.status(400).json({ error: "Video prompt is required." });
  }

  const chosenModel = ALLOWED_VEO_MODELS.has(model) ? model : "veo-3.1-fast-generate-001";
  const chosenRatio = ALLOWED_ASPECT_RATIOS.has(aspectRatio) ? aspectRatio : "9:16";
  let chosenResolution = ALLOWED_RESOLUTIONS.has(resolution) ? resolution : "720p";
  let chosenDuration = ALLOWED_DURATIONS.has(Number(durationSeconds)) ? Number(durationSeconds) : 8;

  if (chosenModel === "veo-3.1-lite-generate-001") {
    chosenResolution = "720p";
  }
  if (chosenResolution === "1080p" || chosenResolution === "4k") {
    chosenDuration = 8;
  }

  try {
    const response = await fetch(
      `${GEMINI_BASE}/models/${encodeURIComponent(chosenModel)}:predictLongRunning`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          instances: [{ prompt: cleanedPrompt }],
          parameters: {
            aspectRatio: chosenRatio,
            resolution: chosenResolution,
            durationSeconds: chosenDuration,
            sampleCount: 1,
          },
        }),
      }
    );

    const rawText = await response.text();
    if (!response.ok) {
      const info = classifyGoogleError(response.status, rawText);
      return res.status(info.httpStatus).json({
        error: info.message,
        billingRequired: info.billingRequired,
      });
    }

    const op = JSON.parse(rawText);
    if (!op.name) {
      return res.status(502).json({
        error: "Veo API did not return an operation name.",
      });
    }

    return res.status(202).json({
      operationName: op.name,
      model: chosenModel,
      aspectRatio: chosenRatio,
      resolution: chosenResolution,
      durationSeconds: chosenDuration,
      status: "RUNNING",
    });
  } catch (err) {
    return res.status(502).json({
      error: `Failed to start Veo operation: ${err.message}`,
      billingRequired: false,
    });
  }
});

/**
 * Step 3: Poll real Veo 3.1 Long-Running Operation status.
 */
expressApp.get("/api/ai-video/status", async (req, res) => {
  const apiKey = getApiKey();
  if (!apiKey) {
    return res.status(503).json({
      error: "Backend GEMINI_API_KEY is not configured on Cloud Run.",
    });
  }

  const operationName = String(req.query.operationName || "").trim();
  if (!operationName || !operationName.startsWith("models/veo-")) {
    return res.status(400).json({ error: "Invalid Veo operationName." });
  }

  try {
    const response = await fetch(`${GEMINI_BASE}/${operationName}`, {
      method: "GET",
      headers: {
        "x-goog-api-key": apiKey,
      },
    });

    const rawText = await response.text();
    if (!response.ok) {
      const info = classifyGoogleError(response.status, rawText);
      return res.status(info.httpStatus).json({
        error: info.message,
        billingRequired: info.billingRequired,
      });
    }

    const op = JSON.parse(rawText);
    if (!op.done) {
      return res.json({
        operationName: op.name || operationName,
        done: false,
        status: "RUNNING",
      });
    }

    if (op.error) {
      return res.json({
        operationName: op.name || operationName,
        done: true,
        status: "FAILED",
        errorMessage: op.error.message || "Veo video generation failed.",
      });
    }

    const genVideoResp = op?.response?.generateVideoResponse;
    const samples = genVideoResp?.generatedSamples || op?.response?.generatedVideos || [];
    const videoUri = samples?.[0]?.video?.uri || "";
    const raiFilteredCount = Number(genVideoResp?.raiMediaFilteredCount || 0);

    if (!videoUri) {
      const safetyReasons = Array.isArray(genVideoResp?.raiMediaFilteredReasons)
        ? genVideoResp.raiMediaFilteredReasons.join("; ")
        : "";
      return res.json({
        operationName: op.name || operationName,
        done: true,
        status: "FAILED",
        raiFilteredCount,
        errorMessage:
          safetyReasons || "Operation completed but no MP4 video URI was returned.",
      });
    }

    return res.json({
      operationName: op.name || operationName,
      done: true,
      status: "SUCCEEDED",
      videoUri,
      raiFilteredCount,
    });
  } catch (err) {
    return res.status(502).json({
      error: `Failed to poll Veo operation: ${err.message}`,
    });
  }
});

/**
 * Step 4: Stream real MP4 bytes from Google URI using server-side API key.
 */
expressApp.get("/api/ai-video/download", async (req, res) => {
  const apiKey = getApiKey();
  if (!apiKey) {
    return res.status(503).json({
      error: "Backend GEMINI_API_KEY is not configured on Cloud Run.",
    });
  }

  const videoUri = String(req.query.uri || "").trim();
  if (!videoUri.startsWith("https://generativelanguage.googleapis.com/")) {
    return res.status(400).json({ error: "Invalid Google video URI." });
  }

  try {
    const upstream = await fetch(videoUri, {
      method: "GET",
      headers: {
        "x-goog-api-key": apiKey,
      },
      redirect: "follow",
    });

    if (!upstream.ok) {
      const rawText = await upstream.text();
      const info = classifyGoogleError(upstream.status, rawText);
      return res.status(info.httpStatus).json({
        error: info.message,
        billingRequired: info.billingRequired,
      });
    }

    const contentType = upstream.headers.get("content-type") || "video/mp4";
    const contentLength = upstream.headers.get("content-length");
    res.setHeader("Content-Type", contentType);
    res.setHeader("Content-Disposition", 'attachment; filename="masti_maker_ai.mp4"');
    if (contentLength) {
      res.setHeader("Content-Length", contentLength);
    }

    const arrayBuf = await upstream.arrayBuffer();
    return res.send(Buffer.from(arrayBuf));
  } catch (err) {
    return res.status(502).json({
      error: `Failed to download MP4 from Google: ${err.message}`,
    });
  }
});

const port = Number(process.env.PORT || 8080);
expressApp.listen(port, () => {
  console.log(`Masti Maker AI Video Backend listening on port ${port}`);
});
