# Masti Maker AI Video Backend (Google Cloud Run)

This Cloud Run service acts as the secure server-side proxy for:
1. **Prompt Enhancement** (`POST /api/ai-video/enhance-prompt`) using **Gemini** (`gemini-2.5-flash`) to turn Hindi or English story scripts and selected animal characters into cinematic Veo prompts.
2. **Real AI Video Generation** (`POST /api/ai-video/start`, `GET /api/ai-video/status`, `GET /api/ai-video/download`) using official **Veo 3.1** models:
   - `veo-3.1-fast-generate-001`
   - `veo-3.1-generate-001`
   - `veo-3.1-lite-generate-001`

Your `GEMINI_API_KEY` stays strictly in Cloud Run environment variables/Secret Manager and is **never packaged inside the Android APK**.

## Prerequisites
- A Google Cloud Project with **Billing enabled** (Veo 3.1 video generation is a paid API).
- `GEMINI_API_KEY` from a billed project in Google AI Studio / Google Cloud.
- `gcloud` CLI authenticated (`gcloud auth login`).

## Deploy to Cloud Run
```bash
cd backend
gcloud run deploy masti-maker-ai-video \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=YOUR_BILLED_GEMINI_API_KEY
```

After deployment completes, copy the printed Cloud Run service URL (for example: `https://masti-maker-ai-video-xxxxx-uc.a.run.app`) and paste it into **Masti Maker -> Settings -> AI Video Backend URL** (or directly inside the **Real AI Video** screen).
