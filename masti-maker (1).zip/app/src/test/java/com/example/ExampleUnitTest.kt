package com.example

import com.example.audio.AnimalVoiceSynthesizer
import com.example.audio.MusicSynthesizer
import com.example.model.AnimalType
import com.example.model.DanceDuration
import com.example.model.DanceStyle
import com.example.animation.DanceChoreography
import com.example.model.OWNER_EMAIL
import com.example.model.SongTrack
import com.example.model.SoundLevel
import com.example.model.StoryDuration
import com.example.model.UserProfile
import com.example.model.VoiceMode
import com.example.model.isValidEmail
import com.example.video.StoryScriptHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun catalogCountsMatchSpecification() {
        assertEquals(6, AnimalType.entries.size)
        assertEquals(4, DanceStyle.entries.size)
        assertEquals(5, DanceDuration.entries.size)
        assertEquals(4, SongTrack.entries.size)
        assertEquals(2, StoryDuration.entries.size)
        assertEquals(3, SoundLevel.entries.size)
        assertEquals(3, VoiceMode.entries.size)
    }

    @Test
    fun musicSynthesizerRespectsVolumeGain() {
        SongTrack.entries.forEach { song ->
            val loud = MusicSynthesizer.renderChunk(song, 0, 2048, volumeGain = 1.0f)
            val soft = MusicSynthesizer.renderChunk(song, 0, 2048, volumeGain = 0.3f)
            assertEquals(2048, loud.size)
            assertTrue("Expected non-zero PCM signal for ${song.id}", loud.any { it != 0.toShort() })
            val loudPeak = loud.maxOf { kotlin.math.abs(it.toInt()) }
            val softPeak = soft.maxOf { kotlin.math.abs(it.toInt()) }
            assertTrue("Soft gain peak should be lower than loud peak", softPeak < loudPeak)
        }
    }

    @Test
    fun storyScriptHelperSplitsSentencesIntoScenes() {
        val scenes = StoryScriptHelper.splitStoryIntoScenes(
            "Ek din Billi jungle gayi. Waha usko Bandar mila! Dono ne milkar dance kiya.",
            "Fallback"
        )
        assertEquals(3, scenes.size)
    }

    @Test
    fun emailValidationAndOwnerDefaultsWorkCorrectly() {
        assertTrue(isValidEmail(OWNER_EMAIL))
        assertTrue(isValidEmail("priya.dance123@gmail.com"))
        assertFalse(isValidEmail(""))
        assertFalse(isValidEmail("not-an-email"))
        assertFalse(isValidEmail("bad@domain"))
        val defaultProfile = UserProfile()
        assertFalse(defaultProfile.isLoggedIn)
        assertFalse(defaultProfile.isOwner)
    }

    @Test
    fun fullBodyChoreographyAnimatesArmsLegsAndHeadWithMultipleSteps() {
        AnimalType.entries.forEach { animal ->
            DanceChoreography.paletteFor(animal)
        }
        DanceStyle.entries.forEach { dance ->
            val poses = (0..12).map { i ->
                DanceChoreography.computePose(dance, timeSeconds = i * 0.7f, isDancing = true)
            }
            val uniqueSteps = poses.map { it.stepName }.toSet()
            assertTrue("Expected multiple steps for $dance", uniqueSteps.size >= 2)
            assertTrue("Arms should move during $dance", poses.map { it.leftShoulderDeg }.distinct().size > 3)
            assertTrue("Legs should move during $dance", poses.map { it.leftHipDeg }.distinct().size > 3)
            assertTrue("Head should move during $dance", poses.map { it.headTiltDeg }.distinct().size > 3)
        }
        val idle = DanceChoreography.computePose(DanceStyle.DJ_DANCE, 0.2f, isDancing = false)
        val dancing = DanceChoreography.computePose(DanceStyle.DJ_DANCE, 0.2f, isDancing = true)
        assertNotEquals(idle.stepName, dancing.stepName)
    }

    @Test
    fun allAnimalsProduceDistinctVoiceClipsAndMixCleanly() {
        AnimalType.entries.forEach { animal ->
            val clip = AnimalVoiceSynthesizer.renderAnimalClip(animal, volumeGain = 1.0f)
            assertTrue("Animal voice clip should not be empty for $animal", clip.size > 40000)
            assertTrue("Animal voice clip should contain audible signal for $animal", clip.any { it != 0.toShort() })
        }
        val music = MusicSynthesizer.renderChunk(SongTrack.DJ_DHAMAKA, 0, 2048, 1.0f)
        val voice = AnimalVoiceSynthesizer.renderAnimalClip(AnimalType.BILLI, 1.0f)
        val mixed = AnimalVoiceSynthesizer.mixMusicAndVoice(music, voice, startSample = 0)
        assertEquals(music.size, mixed.size)
        assertTrue("Mixed signal should remain non-zero", mixed.any { it != 0.toShort() })
    }

    @Test
    fun veoConfigNormalizationEnforcesApiRules() {
        val norm1080p = com.example.model.normalizeVeoConfig(
            model = com.example.model.VeoModel.VEO_3_1_FAST,
            resolution = com.example.model.VeoResolution.RES_1080P,
            duration = com.example.model.VeoDuration.SEC_4
        )
        assertEquals(com.example.model.VeoDuration.SEC_8, norm1080p.duration)
        assertTrue(norm1080p.adjustmentNote != null)

        val normLite = com.example.model.normalizeVeoConfig(
            model = com.example.model.VeoModel.VEO_3_1_LITE,
            resolution = com.example.model.VeoResolution.RES_4K,
            duration = com.example.model.VeoDuration.SEC_6
        )
        assertEquals(com.example.model.VeoResolution.RES_720P, normLite.resolution)
        assertEquals(com.example.model.VeoDuration.SEC_6, normLite.duration)
    }

    @Test
    fun backendUrlValidationAndErrorParsingWorkCorrectly() {
        assertTrue(com.example.video.VeoBackendClient.isValidBackendUrl("https://masti-maker-uc.a.run.app/"))
        assertTrue(com.example.video.VeoBackendClient.isValidBackendUrl("http://10.0.2.2:8080"))
        assertFalse(com.example.video.VeoBackendClient.isValidBackendUrl(""))
        assertFalse(com.example.video.VeoBackendClient.isValidBackendUrl("http://insecure.example.com"))

        assertEquals(
            "https://masti-maker-uc.a.run.app",
            com.example.video.VeoBackendClient.normalizeBackendUrl(" https://masti-maker-uc.a.run.app/// ")
        )

        val billingErr = com.example.video.VeoBackendClient.parseErrorBody(
            402,
            """{"error":"Cloud Billing must be enabled for Veo.","billingRequired":true}"""
        )
        assertTrue(billingErr.isBillingOrQuota)
        assertEquals(402, billingErr.httpCode)
        assertTrue(billingErr.message!!.contains("Cloud Billing"))

        val pollDone = com.example.video.VeoBackendClient.parsePollJson(
            """{"operationName":"models/veo-3.1-fast-generate-001/operations/op123","done":true,"status":"SUCCEEDED","videoUri":"https://generativelanguage.googleapis.com/v1beta/files/abc:download?alt=media"}"""
        )
        assertTrue(pollDone.done)
        assertEquals("SUCCEEDED", pollDone.status)
        assertTrue(pollDone.videoUri!!.contains("files/abc"))
    }

    @Test
    fun createdVideoAspectRatioHelperMapsSupportedFormats() {
        val portrait = com.example.model.CreatedVideo(
            id = "1",
            filePath = "/tmp/a.mp4",
            animal = AnimalType.BILLI,
            dance = DanceStyle.DJ_DANCE,
            durationSeconds = 8,
            song = SongTrack.DJ_DHAMAKA,
            createdAtMillis = 1L,
            isAiGenerated = true,
            aspectRatio = "9:16"
        )
        val landscape = portrait.copy(aspectRatio = "16:9")
        val square = portrait.copy(aspectRatio = "1:1")
        assertEquals(9f / 16f, portrait.aspectRatioFloat, 0.001f)
        assertEquals(16f / 9f, landscape.aspectRatioFloat, 0.001f)
        assertEquals(1f, square.aspectRatioFloat, 0.001f)
    }

    @Test
    fun mp4HeaderValidationDetectsValidAndInvalidStreams() {
        val validMp4 = byteArrayOf(0x00, 0x00, 0x00, 0x18, 'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(), 'm'.code.toByte(), 'p'.code.toByte(), '4'.code.toByte(), '2'.code.toByte())
        val htmlErr = "<html>403 Forbidden</html>".toByteArray()
        assertTrue(com.example.video.VeoBackendClient.hasValidMp4Header(validMp4))
        assertFalse(com.example.video.VeoBackendClient.hasValidMp4Header(htmlErr))
        assertFalse(com.example.video.VeoBackendClient.hasValidMp4Header(byteArrayOf(1, 2, 3)))
    }
}



