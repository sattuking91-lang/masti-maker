package com.example.model

enum class VeoModel(
    val modelId: String,
    val displayName: String,
    val tagline: String,
    val supports1080p: Boolean,
    val supports4k: Boolean
) {
    VEO_3_1_FAST(
        modelId = "veo-3.1-fast-generate-001",
        displayName = "Veo 3.1 Fast",
        tagline = "Fast cinematic 720p / 1080p / 4K",
        supports1080p = true,
        supports4k = true
    ),
    VEO_3_1_STANDARD(
        modelId = "veo-3.1-generate-001",
        displayName = "Veo 3.1 Standard",
        tagline = "Highest realism & character motion",
        supports1080p = true,
        supports4k = true
    ),
    VEO_3_1_LITE(
        modelId = "veo-3.1-lite-generate-001",
        displayName = "Veo 3.1 Lite",
        tagline = "Lightweight 720p generation",
        supports1080p = false,
        supports4k = false
    )
}

enum class VideoAspectRatio(
    val apiValue: String,
    val label: String,
    val ratioFloat: Float
) {
    PORTRAIT_9_16(
        apiValue = "9:16",
        label = "9:16 Shorts / Reels",
        ratioFloat = 9f / 16f
    ),
    LANDSCAPE_16_9(
        apiValue = "16:9",
        label = "16:9 Wide YouTube",
        ratioFloat = 16f / 9f
    )
}

enum class VeoDuration(
    val seconds: Int,
    val label: String
) {
    SEC_4(4, "4 sec"),
    SEC_6(6, "6 sec"),
    SEC_8(8, "8 sec")
}

enum class VeoResolution(
    val apiValue: String,
    val label: String
) {
    RES_720P("720p", "720p HD"),
    RES_1080P("1080p", "1080p Full HD"),
    RES_4K("4k", "4K Ultra HD")
}

data class NormalizedVeoConfig(
    val model: VeoModel,
    val resolution: VeoResolution,
    val duration: VeoDuration,
    val adjustmentNote: String? = null
)

fun normalizeVeoConfig(
    model: VeoModel,
    resolution: VeoResolution,
    duration: VeoDuration
): NormalizedVeoConfig {
    var finalRes = resolution
    var finalDuration = duration
    val notes = mutableListOf<String>()

    if (model == VeoModel.VEO_3_1_LITE && finalRes != VeoResolution.RES_720P) {
        finalRes = VeoResolution.RES_720P
        notes.add("${model.displayName} supports 720p")
    }
    if ((finalRes == VeoResolution.RES_1080P || finalRes == VeoResolution.RES_4K) &&
        finalDuration != VeoDuration.SEC_8
    ) {
        finalDuration = VeoDuration.SEC_8
        notes.add("${finalRes.label} requires 8 sec duration on Veo 3.1")
    }

    return NormalizedVeoConfig(
        model = model,
        resolution = finalRes,
        duration = finalDuration,
        adjustmentNote = notes.takeIf { it.isNotEmpty() }?.joinToString(" • ")
    )
}

sealed interface AiGenerationPhase {
    data object Idle : AiGenerationPhase
    data class EnhancingPrompt(val script: String) : AiGenerationPhase
    data class SubmittingJob(val prompt: String, val model: VeoModel) : AiGenerationPhase
    data class PollingOperation(
        val operationName: String,
        val serverStatus: String,
        val elapsedSeconds: Int,
        val prompt: String,
        val model: VeoModel
    ) : AiGenerationPhase
    data class DownloadingMp4(
        val operationName: String,
        val bytesDownloaded: Long,
        val totalBytes: Long
    ) : AiGenerationPhase
    data class Completed(val video: CreatedVideo) : AiGenerationPhase
    data class Error(
        val message: String,
        val httpCode: Int? = null,
        val isBillingOrAuthError: Boolean = false,
        val isBackendMissing: Boolean = false
    ) : AiGenerationPhase
}
