package com.example.video

import com.example.model.AnimalType
import com.example.model.VeoDuration
import com.example.model.VeoModel
import com.example.model.VeoResolution
import com.example.model.VideoAspectRatio
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

data class BackendHealth(
    val ok: Boolean,
    val apiKeyConfigured: Boolean,
    val promptModel: String,
    val supportedVeoModels: List<String>
)

data class EnhancedPromptResult(
    val enhancedPrompt: String,
    val sceneSummary: String,
    val detectedLanguage: String
)

data class StartVeoResult(
    val operationName: String,
    val model: String,
    val status: String
)

data class PollVeoResult(
    val operationName: String,
    val done: Boolean,
    val status: String,
    val videoUri: String?,
    val errorMessage: String?
)

class VeoApiException(
    message: String,
    val httpCode: Int? = null,
    val isBillingOrQuota: Boolean = false,
    val isBackendNotConfigured: Boolean = false
) : IOException(message)

object VeoBackendClient {
    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    fun normalizeBackendUrl(rawUrl: String): String {
        return rawUrl.trim().trimEnd('/')
    }

    fun isValidBackendUrl(rawUrl: String): Boolean {
        val cleaned = normalizeBackendUrl(rawUrl)
        if (cleaned.isEmpty()) return false
        val isHttps = cleaned.startsWith("https://", ignoreCase = true) && cleaned.length > 10
        val isLocalEmulator = cleaned.startsWith("http://10.0.2.2", ignoreCase = true) ||
            cleaned.startsWith("http://localhost", ignoreCase = true) ||
            cleaned.startsWith("http://127.0.0.1", ignoreCase = true)
        return (isHttps || isLocalEmulator) && !cleaned.contains(" ")
    }

    internal fun parseErrorBody(httpCode: Int, rawBody: String): VeoApiException {
        val jsonError = runCatching {
            val obj = JSONObject(rawBody)
            obj.optString("error").takeIf { it.isNotBlank() }
                ?: obj.optString("message").takeIf { it.isNotBlank() }
        }.getOrNull() ?: extractJsonString(rawBody, "error") ?: extractJsonString(rawBody, "message")

        val msg = jsonError?.takeIf { it.isNotBlank() }
            ?: rawBody.takeIf { it.isNotBlank() }
            ?: "Server returned HTTP $httpCode"
        val lower = msg.lowercase()

        val billingJsonFlag = runCatching {
            JSONObject(rawBody).optBoolean("billingRequired", false)
        }.getOrNull() ?: (extractJsonBoolean(rawBody, "billingRequired") == true)

        val billingFlag = billingJsonFlag ||
            httpCode == 402 ||
            httpCode == 429 ||
            lower.contains("billing") ||
            lower.contains("paid") ||
            lower.contains("quota") ||
            lower.contains("permission_denied")
        return VeoApiException(
            message = msg,
            httpCode = httpCode,
            isBillingOrQuota = billingFlag
        )
    }

    internal fun parsePollJson(jsonText: String): PollVeoResult {
        val parsed = runCatching {
            val obj = JSONObject(jsonText)
            val done = obj.optBoolean("done", false)
            PollVeoResult(
                operationName = obj.optString("operationName", ""),
                done = done,
                status = obj.optString("status", if (done) "SUCCEEDED" else "RUNNING"),
                videoUri = obj.optString("videoUri", "").takeIf { it.isNotBlank() },
                errorMessage = obj.optString("errorMessage", "").takeIf { it.isNotBlank() }
            )
        }.getOrNull()
        if (parsed != null) return parsed

        val done = extractJsonBoolean(jsonText, "done") ?: false
        return PollVeoResult(
            operationName = extractJsonString(jsonText, "operationName").orEmpty(),
            done = done,
            status = extractJsonString(jsonText, "status") ?: if (done) "SUCCEEDED" else "RUNNING",
            videoUri = extractJsonString(jsonText, "videoUri")?.takeIf { it.isNotBlank() },
            errorMessage = extractJsonString(jsonText, "errorMessage")?.takeIf { it.isNotBlank() }
        )
    }

    private fun extractJsonString(json: String, key: String): String? {
        val regex = Regex(""""${Regex.escape(key)}"\s*:\s*"((?:\\.|[^"\\])*)"""")
        val match = regex.find(json) ?: return null
        return match.groupValues[1]
            .replace("\\\"", "\"")
            .replace("\\n", "\n")
            .replace("\\\\", "\\")
    }

    private fun extractJsonBoolean(json: String, key: String): Boolean? {
        val regex = Regex(""""${Regex.escape(key)}"\s*:\s*(true|false)""")
        val match = regex.find(json) ?: return null
        return match.groupValues[1].toBooleanStrictOrNull()
    }

    suspend fun checkHealth(backendUrl: String): Result<BackendHealth> = withContext(Dispatchers.IO) {
        runApiCall {
            val base = requireValidUrl(backendUrl)
            val req = Request.Builder()
                .url("$base/health")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw parseErrorBody(resp.code, body)
                val obj = JSONObject(body)
                val arr = obj.optJSONArray("supportedVeoModels")
                val models = mutableListOf<String>()
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        models.add(arr.optString(i))
                    }
                }
                BackendHealth(
                    ok = obj.optBoolean("ok", false),
                    apiKeyConfigured = obj.optBoolean("apiKeyConfigured", false),
                    promptModel = obj.optString("promptModel", ""),
                    supportedVeoModels = models
                )
            }
        }
    }

    suspend fun enhancePrompt(
        backendUrl: String,
        script: String,
        animals: List<AnimalType>,
        aspectRatio: VideoAspectRatio,
        duration: VeoDuration
    ): Result<EnhancedPromptResult> = withContext(Dispatchers.IO) {
        runApiCall {
            val base = requireValidUrl(backendUrl)
            val animalNames = JSONArray().apply {
                animals.forEach { put(animalEnglishName(it)) }
            }
            val payload = JSONObject().apply {
                put("script", script.trim())
                put("animals", animalNames)
                put("aspectRatio", aspectRatio.apiValue)
                put("durationSeconds", duration.seconds)
            }
            val req = Request.Builder()
                .url("$base/api/ai-video/enhance-prompt")
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()

            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw parseErrorBody(resp.code, body)
                val obj = JSONObject(body)
                val enhanced = obj.optString("enhancedPrompt", "").trim()
                if (enhanced.isEmpty()) {
                    throw VeoApiException("AI prompt enhancer returned an empty prompt.")
                }
                EnhancedPromptResult(
                    enhancedPrompt = enhanced,
                    sceneSummary = obj.optString("sceneSummary", script.trim()),
                    detectedLanguage = obj.optString("detectedLanguage", "auto")
                )
            }
        }
    }

    suspend fun startVideoGeneration(
        backendUrl: String,
        prompt: String,
        model: VeoModel,
        aspectRatio: VideoAspectRatio,
        duration: VeoDuration,
        resolution: VeoResolution
    ): Result<StartVeoResult> = withContext(Dispatchers.IO) {
        runApiCall {
            val base = requireValidUrl(backendUrl)
            val payload = JSONObject().apply {
                put("prompt", prompt.trim())
                put("model", model.modelId)
                put("aspectRatio", aspectRatio.apiValue)
                put("durationSeconds", duration.seconds)
                put("resolution", resolution.apiValue)
            }
            val req = Request.Builder()
                .url("$base/api/ai-video/start")
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .build()

            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw parseErrorBody(resp.code, body)
                val obj = JSONObject(body)
                val opName = obj.optString("operationName", "").trim()
                if (opName.isEmpty()) {
                    throw VeoApiException("Backend did not return a valid Veo operation name.")
                }
                StartVeoResult(
                    operationName = opName,
                    model = obj.optString("model", model.modelId),
                    status = obj.optString("status", "RUNNING")
                )
            }
        }
    }

    suspend fun pollOperationStatus(
        backendUrl: String,
        operationName: String
    ): Result<PollVeoResult> = withContext(Dispatchers.IO) {
        runApiCall {
            val base = requireValidUrl(backendUrl)
            val encodedOp = URLEncoder.encode(operationName, "UTF-8")
            val req = Request.Builder()
                .url("$base/api/ai-video/status?operationName=$encodedOp")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw parseErrorBody(resp.code, body)
                parsePollJson(body)
            }
        }
    }

    suspend fun downloadMp4ToFile(
        backendUrl: String,
        videoUri: String,
        outFile: File,
        onBytesProgress: (Long, Long) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        runApiCall {
            val base = requireValidUrl(backendUrl)
            val encodedUri = URLEncoder.encode(videoUri, "UTF-8")
            val req = Request.Builder()
                .url("$base/api/ai-video/download?uri=$encodedUri")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val errBody = resp.body?.string().orEmpty()
                    throw parseErrorBody(resp.code, errBody)
                }
                val body = resp.body ?: throw VeoApiException("Empty MP4 response from backend.")
                val contentType = resp.header("Content-Type").orEmpty().lowercase()
                if (contentType.contains("application/json")) {
                    throw parseErrorBody(resp.code, body.string())
                }

                val totalBytes = body.contentLength()
                var totalRead = 0L
                val buffer = ByteArray(16 * 1024)
                val tempFile = File(outFile.parentFile, "${outFile.name}.part")

                body.byteStream().use { input ->
                    FileOutputStream(tempFile).use { output ->
                        while (true) {
                            coroutineContext.ensureActive()
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            totalRead += read
                            onBytesProgress(totalRead, totalBytes)
                        }
                        output.flush()
                    }
                }

                if (totalRead < 4096L || !isValidMp4File(tempFile)) {
                    runCatching { tempFile.delete() }
                    throw VeoApiException("Downloaded file is not a valid MP4 video stream.")
                }

                if (outFile.exists()) outFile.delete()
                if (!tempFile.renameTo(outFile)) {
                    tempFile.copyTo(outFile, overwrite = true)
                    tempFile.delete()
                }
                outFile
            }
        }
    }

    internal fun hasValidMp4Header(headerBytes: ByteArray): Boolean {
        if (headerBytes.size < 8) return false
        return headerBytes[4] == 'f'.code.toByte() &&
            headerBytes[5] == 't'.code.toByte() &&
            headerBytes[6] == 'y'.code.toByte() &&
            headerBytes[7] == 'p'.code.toByte()
    }

    private fun isValidMp4File(file: File): Boolean {
        return runCatching {
            file.inputStream().use { input ->
                val header = ByteArray(12)
                val read = input.read(header)
                read >= 8 && hasValidMp4Header(header)
            }
        }.getOrDefault(false)
    }

    fun animalEnglishName(animal: AnimalType): String = when (animal) {
        AnimalType.BILLI -> "cute animated cat"
        AnimalType.KUTTA -> "playful puppy dog"
        AnimalType.BANDAR -> "energetic little monkey"
        AnimalType.HATHI -> "cheerful baby elephant"
        AnimalType.MURGA -> "colorful dancing rooster"
        AnimalType.SHER -> "friendly cartoon lion cub"
    }

    private fun requireValidUrl(rawUrl: String): String {
        val normalized = normalizeBackendUrl(rawUrl)
        if (!isValidBackendUrl(normalized)) {
            throw VeoApiException(
                message = "Cloud Run Backend URL set nahi hai! Settings ya Backend Setup me valid https://... Cloud Run URL dalo.",
                isBackendNotConfigured = true
            )
        }
        return normalized
    }

    private suspend inline fun <T> runApiCall(crossinline block: suspend () -> T): Result<T> {
        return try {
            Result.success(block())
        } catch (ce: CancellationException) {
            throw ce
        } catch (ve: VeoApiException) {
            Result.failure(ve)
        } catch (e: Exception) {
            Result.failure(
                VeoApiException(
                    message = e.localizedMessage ?: "Network error while contacting Cloud Run backend"
                )
            )
        }
    }
}
