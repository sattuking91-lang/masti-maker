package com.example.video

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.example.animation.DanceChoreography
import com.example.model.AnimalType
import com.example.model.DanceStyle
import com.example.model.SongTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

class DanceStageRenderer(
    private val context: Context,
    private val animal: AnimalType,
    private val dance: DanceStyle,
    private val song: SongTrack,
    private val showWatermark: Boolean = true,
    private val width: Int = 480,
    private val height: Int = 480
) : StageFrameRenderer {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spotlightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val floorPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val eqPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 22f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(175, 25, 20, 50)
    }

    private val confettiColors = intArrayOf(
        Color.parseColor("#FF6B35"),
        Color.parseColor("#FF3E8A"),
        Color.parseColor("#00E5FF"),
        Color.parseColor("#FFD13B"),
        Color.parseColor("#4CD964"),
        Color.parseColor("#A77BFF")
    )

    override fun drawFrame(canvas: Canvas, timeSeconds: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val beatHz = song.bpm / 60f
        val beatPhase = timeSeconds * beatHz * 2f * PI.toFloat()
        val beatPulse = abs(sin(beatPhase / 2f))

        // 1. Vibrant 3D stage background
        val primary = (0xFF000000L or dance.primaryHex).toInt()
        val secondary = (0xFF000000L or dance.secondaryHex).toInt()
        val bgTop = blendColors(primary, Color.parseColor("#1D1147"), 0.45f)
        val bgBottom = blendColors(secondary, Color.parseColor("#2E1760"), 0.55f)
        bgPaint.shader = LinearGradient(0f, 0f, w, h, bgTop, bgBottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // 2. Sweeping stage spotlights
        drawSpotlights(canvas, w, h, timeSeconds, beatPulse)

        // 3. Background beat equalizer bars for club/stage vibe
        drawEqualizerBars(canvas, w, h, timeSeconds, beatHz)

        // 4. Illuminated 3D stage floor
        val floorRect = RectF(-w * 0.1f, h * 0.72f, w * 1.1f, h * 1.15f)
        floorPaint.shader = RadialGradient(
            w / 2f, h * 0.80f, w * 0.55f,
            intArrayOf(
                blendColors(secondary, Color.WHITE, 0.25f),
                primary,
                Color.parseColor("#1A103D")
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawOval(floorRect, floorPaint)

        // Glowing neon floor ring under the dancer
        ringPaint.color = confettiColors[(timeSeconds * 2).toInt() % confettiColors.size]
        ringPaint.alpha = 185
        canvas.drawOval(
            RectF(
                w * 0.22f - beatPulse * 10f,
                h * 0.75f - beatPulse * 3f,
                w * 0.78f + beatPulse * 10f,
                h * 0.85f + beatPulse * 3f
            ),
            ringPaint
        )

        // 5. Compute full-body articulated dance choreography & draw 3D character
        val pose = DanceChoreography.computePose(
            dance = dance,
            timeSeconds = timeSeconds,
            bpm = song.bpm,
            isDancing = true
        )
        AnimalCharacterCanvasDrawer.drawCharacter(
            canvas = canvas,
            animal = animal,
            dance = dance,
            pose = pose,
            centerX = w / 2f,
            groundY = h * 0.80f,
            characterHeight = h * 0.56f,
            isDancing = true
        )

        // 6. Confetti & musical party particles in foreground
        drawConfettiAndNotes(canvas, w, h, timeSeconds)

        // 7. Top Watermark (Free mode only) & Bottom Dance Step Pill
        if (showWatermark) {
            val topPill = RectF(w * 0.22f, 16f, w * 0.78f, 52f)
            canvas.drawRoundRect(topPill, 20f, 20f, badgeBgPaint)
            textPaint.textSize = 20f
            canvas.drawText("MASTI MAKER", w / 2f, 41f, textPaint)
        }

        val bottomPill = RectF(w * 0.10f, h - 52f, w * 0.90f, h - 14f)
        canvas.drawRoundRect(bottomPill, 20f, 20f, badgeBgPaint)
        textPaint.textSize = 18f
        val animalName = context.getString(animal.labelRes)
        val danceName = context.getString(dance.labelRes)
        canvas.drawText("$animalName • $danceName • ${pose.stepName}", w / 2f, h - 27f, textPaint)
    }

    private fun drawSpotlights(
        canvas: Canvas,
        w: Float,
        h: Float,
        timeSeconds: Float,
        beatPulse: Float
    ) {
        val sweep = sin(timeSeconds * 2.2f) * w * 0.25f
        spotlightPaint.shader = LinearGradient(
            w * 0.2f, 0f, w * 0.5f + sweep, h * 0.85f,
            Color.argb((70 + beatPulse * 55).toInt(), 255, 255, 255),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        val path1 = Path().apply {
            moveTo(w * 0.18f, 0f)
            lineTo(w * 0.26f, 0f)
            lineTo(w * 0.65f + sweep, h * 0.85f)
            lineTo(w * 0.35f + sweep, h * 0.85f)
            close()
        }
        canvas.drawPath(path1, spotlightPaint)

        spotlightPaint.shader = LinearGradient(
            w * 0.8f, 0f, w * 0.5f - sweep, h * 0.85f,
            Color.argb((65 + beatPulse * 50).toInt(), 255, 230, 120),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        val path2 = Path().apply {
            moveTo(w * 0.74f, 0f)
            lineTo(w * 0.82f, 0f)
            lineTo(w * 0.65f - sweep, h * 0.85f)
            lineTo(w * 0.35f - sweep, h * 0.85f)
            close()
        }
        canvas.drawPath(path2, spotlightPaint)
    }

    private fun drawEqualizerBars(
        canvas: Canvas,
        w: Float,
        h: Float,
        timeSeconds: Float,
        beatHz: Float
    ) {
        val bars = 10
        val barWidth = w / (bars * 1.5f)
        val startX = (w - bars * barWidth * 1.35f) / 2f
        val baseY = h * 0.75f
        for (i in 0 until bars) {
            val mag = abs(sin(timeSeconds * beatHz * PI.toFloat() + i * 0.65f))
            val barH = 26f + mag * 90f
            val left = startX + i * barWidth * 1.35f
            eqPaint.color = confettiColors[i % confettiColors.size]
            eqPaint.alpha = 52
            canvas.drawRoundRect(
                RectF(left, baseY - barH, left + barWidth, baseY),
                8f, 8f, eqPaint
            )
        }
    }

    private fun drawConfettiAndNotes(canvas: Canvas, w: Float, h: Float, timeSeconds: Float) {
        for (i in 0 until 14) {
            val seed = i * 47.3f
            val x = ((seed * 19f + sin(timeSeconds * 1.8f + i) * 35f) % w + w) % w
            val y = ((seed * 11f + timeSeconds * (95f + (i % 4) * 25f)) % h)
            particlePaint.color = confettiColors[i % confettiColors.size]
            particlePaint.alpha = 215
            if (i % 3 == 0) {
                canvas.drawCircle(x, y, 6.5f, particlePaint)
            } else {
                canvas.save()
                canvas.translate(x, y)
                canvas.rotate(timeSeconds * 140f + i * 35f)
                canvas.drawRect(-6.5f, -3.5f, 6.5f, 3.5f, particlePaint)
                canvas.restore()
            }
        }
    }

    private fun blendColors(c1: Int, c2: Int, ratio: Float): Int {
        val inv = 1f - ratio
        val r = (Color.red(c1) * inv + Color.red(c2) * ratio).toInt()
        val g = (Color.green(c1) * inv + Color.green(c2) * ratio).toInt()
        val b = (Color.blue(c1) * inv + Color.blue(c2) * ratio).toInt()
        return Color.rgb(r, g, b)
    }

    override fun release() = Unit
}
