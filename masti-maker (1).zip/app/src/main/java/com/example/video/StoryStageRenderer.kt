package com.example.video

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.animation.DanceChoreography
import com.example.model.AnimalType
import com.example.model.DanceStyle
import kotlin.math.abs
import kotlin.math.sin

interface StageFrameRenderer {
    fun drawFrame(canvas: Canvas, timeSeconds: Float)
    fun release()
}

object StoryScriptHelper {
    fun splitStoryIntoScenes(storyText: String, fallbackTitle: String): List<String> {
        val cleaned = storyText.trim()
        if (cleaned.isEmpty()) return listOf(fallbackTitle)

        val rawParts = cleaned
            .split(Regex("[.!?\n।]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val scenes = mutableListOf<String>()
        for (part in rawParts) {
            if (part.length <= 68) {
                scenes.add(part)
            } else {
                val words = part.split(Regex("\\s+"))
                val buf = StringBuilder()
                for (w in words) {
                    if (buf.length + w.length + 1 > 64 && buf.isNotEmpty()) {
                        scenes.add(buf.toString().trim())
                        buf.clear()
                    }
                    if (buf.isNotEmpty()) buf.append(' ')
                    buf.append(w)
                }
                if (buf.isNotEmpty()) scenes.add(buf.toString().trim())
            }
        }
        return if (scenes.isEmpty()) listOf(fallbackTitle) else scenes
    }
}

class StoryStageRenderer(
    private val context: Context,
    private val animal: AnimalType,
    storyText: String,
    private val totalDurationSeconds: Int,
    private val showWatermark: Boolean = true,
    private val width: Int = 480,
    private val height: Int = 480
) : StageFrameRenderer {

    private val scenes: List<String> = StoryScriptHelper.splitStoryIntoScenes(
        storyText = storyText,
        fallbackTitle = "${context.getString(animal.labelRes)} Ki Pyari Kahani"
    )

    private val skyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cloudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 255, 255, 255)
    }
    private val hillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD13B")
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.WHITE
    }
    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(242, 255, 251, 242)
    }
    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(185, 31, 26, 56)
    }
    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 18f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val storyTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F1A38")
        textSize = 22f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private val skyThemes = arrayOf(
        intArrayOf(Color.parseColor("#3B82F6"), Color.parseColor("#93C5FD")),
        intArrayOf(Color.parseColor("#7C3AED"), Color.parseColor("#F472B6")),
        intArrayOf(Color.parseColor("#0D9488"), Color.parseColor("#6EE7B7")),
        intArrayOf(Color.parseColor("#F97316"), Color.parseColor("#FDE047"))
    )

    override fun drawFrame(canvas: Canvas, timeSeconds: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val sceneIndex = ((timeSeconds / totalDurationSeconds.coerceAtLeast(1)) * scenes.size)
            .toInt()
            .coerceIn(0, scenes.lastIndex)

        // 1. Animated storybook sky
        val theme = skyThemes[sceneIndex % skyThemes.size]
        skyPaint.shader = LinearGradient(0f, 0f, 0f, h * 0.78f, theme[0], theme[1], Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, skyPaint)

        // 2. Drifting clouds & twinkling stars
        val cloudOffset = (timeSeconds * 22f) % (w + 140f) - 70f
        drawCloud(canvas, cloudOffset, 82f, 1.0f)
        drawCloud(canvas, ((cloudOffset + w * 0.55f) % (w + 140f)) - 70f, 118f, 0.78f)

        for (i in 0 until 8) {
            val sx = ((i * 67f + 35f) % w)
            val sy = 56f + (i % 3) * 26f
            val pulse = 3.5f + abs(sin(timeSeconds * 3f + i)) * 3.5f
            starPaint.alpha = (160 + abs(sin(timeSeconds * 2.5f + i)) * 95).toInt()
            canvas.drawCircle(sx, sy, pulse, starPaint)
        }

        // 3. Rolling cartoon hills
        hillPaint.color = Color.parseColor("#34D399")
        canvas.drawOval(RectF(-w * 0.25f, h * 0.54f, w * 0.75f, h * 0.96f), hillPaint)
        hillPaint.color = Color.parseColor("#10B981")
        canvas.drawOval(RectF(w * 0.25f, h * 0.57f, w * 1.25f, h * 0.98f), hillPaint)

        // 4. Full-body Articulated 3D Storybook Animal dancing & telling the story!
        val storyDance = when (sceneIndex % 3) {
            0 -> DanceStyle.GAON_WALA
            1 -> DanceStyle.FUNNY_DANCE
            else -> DanceStyle.HIP_HOP
        }
        val pose = DanceChoreography.computePose(
            dance = storyDance,
            timeSeconds = timeSeconds,
            bpm = 104,
            isDancing = true
        )
        AnimalCharacterCanvasDrawer.drawCharacter(
            canvas = canvas,
            animal = animal,
            dance = storyDance,
            pose = pose,
            centerX = w / 2f,
            groundY = h * 0.65f,
            characterHeight = h * 0.45f,
            isDancing = true
        )

        // 5. Top Badge: includes MASTI MAKER watermark only in Free mode
        val topPill = RectF(18f, 16f, w - 18f, 52f)
        canvas.drawRoundRect(topPill, 18f, 18f, badgeBgPaint)
        badgeTextPaint.textSize = 18f
        val headerLabel = if (showWatermark) {
            "MASTI MAKER • KAHANI (${sceneIndex + 1}/${scenes.size})"
        } else {
            "KAHANI (${sceneIndex + 1}/${scenes.size})"
        }
        canvas.drawText(headerLabel, w / 2f, 40f, badgeTextPaint)

        // 6. Storybook Caption Box at Bottom
        val boxRect = RectF(20f, h * 0.69f, w - 20f, h - 16f)
        canvas.drawRoundRect(boxRect, 24f, 24f, cardBgPaint)
        borderPaint.color = (0xFF000000L or animal.accentHex).toInt()
        borderPaint.strokeWidth = 5f
        canvas.drawRoundRect(boxRect, 24f, 24f, borderPaint)

        val caption = scenes[sceneIndex]
        val textWidth = (boxRect.width() - 32f).toInt().coerceAtLeast(100)
        val layout = StaticLayout.Builder
            .obtain(caption, 0, caption.length, storyTextPaint, textWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setMaxLines(4)
            .build()

        canvas.save()
        val textY = boxRect.centerY() - layout.height / 2f
        canvas.translate(boxRect.left + 16f, textY.coerceAtLeast(boxRect.top + 8f))
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawCloud(canvas: Canvas, cx: Float, cy: Float, scale: Float) {
        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(scale, scale)
        canvas.drawCircle(0f, 0f, 22f, cloudPaint)
        canvas.drawCircle(-20f, 6f, 16f, cloudPaint)
        canvas.drawCircle(20f, 6f, 16f, cloudPaint)
        canvas.restore()
    }

    override fun release() = Unit
}
