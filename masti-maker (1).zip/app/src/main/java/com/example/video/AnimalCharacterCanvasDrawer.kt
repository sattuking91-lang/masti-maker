package com.example.video

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.example.animation.AnimalPalette
import com.example.animation.CharacterPose
import com.example.animation.DanceChoreography
import com.example.model.AnimalType
import com.example.model.DanceStyle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object AnimalCharacterCanvasDrawer {

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(105, 10, 6, 30)
    }

    fun drawCharacter(
        canvas: Canvas,
        animal: AnimalType,
        dance: DanceStyle,
        pose: CharacterPose,
        centerX: Float,
        groundY: Float,
        characterHeight: Float,
        isDancing: Boolean
    ) {
        val u = characterHeight / 215f
        val palette = DanceChoreography.paletteFor(animal)

        val rootX = centerX + pose.hipOffsetX * u * 0.85f
        val rootY = groundY - 72f * u + pose.hipOffsetY * u * 0.65f

        // Floor shadow stays anchored to groundY directly under rootX
        val heightOffGround = (groundY - 72f * u - rootY).coerceAtLeast(0f)
        val shadowScale = (1f - heightOffGround / (120f * u)).coerceIn(0.55f, 1.05f)
        shadowPaint.color = Color.argb((125 * shadowScale).toInt(), 8, 5, 24)
        canvas.drawOval(
            rootX - 42f * u * shadowScale,
            groundY - 8f * u * shadowScale,
            rootX + 42f * u * shadowScale,
            groundY + 10f * u * shadowScale,
            shadowPaint
        )

        canvas.save()
        canvas.translate(rootX, rootY)
        canvas.scale(pose.squashX, pose.squashY)

        // 1. Tail behind torso
        drawTail(canvas, animal, palette, pose, u)

        // 2. Legs (attached to hip at y = +4u)
        drawLeg(
            canvas = canvas,
            palette = palette,
            hipX = -15f * u + pose.bodyTurn * 3f * u,
            hipY = 4f * u,
            hipDeg = pose.leftHipDeg,
            kneeDeg = pose.leftKneeDeg,
            isLeft = true,
            u = u
        )
        drawLeg(
            canvas = canvas,
            palette = palette,
            hipX = 15f * u + pose.bodyTurn * 3f * u,
            hipY = 4f * u,
            hipDeg = pose.rightHipDeg,
            kneeDeg = pose.rightKneeDeg,
            isLeft = false,
            u = u
        )

        // 3. Upper Body (Torso + Arms + Head) leaning from Hip
        canvas.save()
        canvas.rotate(pose.torsoLeanDeg)

        val shoulderLeftX = -26f * u + pose.bodyTurn * 5f * u
        val shoulderRightX = 26f * u + pose.bodyTurn * 5f * u
        val shoulderY = -44f * u

        // Draw back arm first based on bodyTurn for genuine 3D depth sorting
        if (pose.bodyTurn >= 0f) {
            drawArm(canvas, animal, palette, shoulderRightX, shoulderY, pose.rightShoulderDeg, pose.rightElbowDeg, u)
        } else {
            drawArm(canvas, animal, palette, shoulderLeftX, shoulderY, pose.leftShoulderDeg, pose.leftElbowDeg, u)
        }

        // Torso
        drawTorso(canvas, animal, dance, palette, pose, u)

        // Draw front arm
        if (pose.bodyTurn >= 0f) {
            drawArm(canvas, animal, palette, shoulderLeftX, shoulderY, pose.leftShoulderDeg, pose.leftElbowDeg, u)
        } else {
            drawArm(canvas, animal, palette, shoulderRightX, shoulderY, pose.rightShoulderDeg, pose.rightElbowDeg, u)
        }

        // 4. Head + Face + Ears + Dance Accessories
        canvas.save()
        canvas.translate(pose.bodyTurn * 5f * u, -78f * u + pose.headBobY * 0.45f * u + pose.headNod * 4f * u)
        canvas.rotate(pose.headTiltDeg)
        drawHead(canvas, animal, dance, palette, pose, u, isDancing)
        canvas.restore()

        canvas.restore() // end torsoLean
        canvas.restore() // end root
    }

    private fun drawTorso(
        canvas: Canvas,
        animal: AnimalType,
        dance: DanceStyle,
        palette: AnimalPalette,
        pose: CharacterPose,
        u: Float
    ) {
        val torsoRect = RectF(-29f * u, -56f * u, 29f * u, 10f * u)
        fillPaint.shader = RadialGradient(
            -10f * u, -36f * u, 48f * u,
            intArrayOf(
                argb(palette.highlightFur),
                argb(palette.primaryFur),
                argb(palette.shadowFur)
            ),
            floatArrayOf(0f, 0.62f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawOval(torsoRect, fillPaint)
        fillPaint.shader = null

        // Cute belly patch
        val bellyShift = pose.bodyTurn * 6f * u
        val bellyRect = RectF(-18f * u + bellyShift, -44f * u, 18f * u + bellyShift, 4f * u)
        fillPaint.shader = LinearGradient(
            0f, -44f * u, 0f, 4f * u,
            argb(palette.bellyColor),
            blend(argb(palette.bellyColor), argb(palette.shadowFur), 0.25f),
            Shader.TileMode.CLAMP
        )
        canvas.drawOval(bellyRect, fillPaint)
        fillPaint.shader = null

        // Subtle torso outline
        strokePaint.color = Color.argb(80, 35, 18, 55)
        strokePaint.strokeWidth = 2.2f * u
        canvas.drawOval(torsoRect, strokePaint)

        // Dance-specific chest accessory
        when (dance) {
            DanceStyle.HIP_HOP -> {
                // Cool Gold Bling Chain
                strokePaint.color = Color.parseColor("#FFD13B")
                strokePaint.strokeWidth = 3.8f * u
                val chainRect = RectF(-16f * u + bellyShift, -58f * u, 16f * u + bellyShift, -32f * u)
                canvas.drawArc(chainRect, 15f, 150f, false, strokePaint)
                fillPaint.color = Color.parseColor("#FFE566")
                canvas.drawCircle(bellyShift, -30f * u, 5.5f * u, fillPaint)
                fillPaint.color = Color.parseColor("#FF8C00")
                canvas.drawCircle(bellyShift, -30f * u, 2.5f * u, fillPaint)
            }
            DanceStyle.GAON_WALA -> {
                // Festive colorful scarf/gamcha collar
                fillPaint.color = argb(palette.outfitAccent)
                canvas.drawRoundRect(
                    RectF(-19f * u + bellyShift, -54f * u, 19f * u + bellyShift, -43f * u),
                    6f * u, 6f * u, fillPaint
                )
            }
            else -> {
                if (animal == AnimalType.KUTTA || animal == AnimalType.BILLI) {
                    // Cute collar + golden bell
                    fillPaint.color = argb(palette.outfitAccent)
                    canvas.drawRoundRect(
                        RectF(-18f * u + bellyShift, -53f * u, 18f * u + bellyShift, -45f * u),
                        5f * u, 5f * u, fillPaint
                    )
                    fillPaint.color = Color.parseColor("#FFD13B")
                    canvas.drawCircle(bellyShift, -43f * u, 4.5f * u, fillPaint)
                }
            }
        }
    }

    private fun drawArm(
        canvas: Canvas,
        animal: AnimalType,
        palette: AnimalPalette,
        shoulderX: Float,
        shoulderY: Float,
        shoulderDeg: Float,
        elbowDeg: Float,
        u: Float
    ) {
        val upperLen = 26f * u
        val foreLen = 23f * u

        canvas.save()
        canvas.translate(shoulderX, shoulderY)
        canvas.rotate(shoulderDeg)

        if (animal == AnimalType.MURGA) {
            // Feathered wing shape for Rooster
            fillPaint.shader = LinearGradient(
                -10f * u, 0f, 10f * u, upperLen + foreLen,
                argb(palette.highlightFur), argb(palette.shadowFur), Shader.TileMode.CLAMP
            )
            val wingRect = RectF(-9.5f * u, -4f * u, 9.5f * u, upperLen + 6f * u)
            canvas.drawRoundRect(wingRect, 9f * u, 9f * u, fillPaint)
            fillPaint.shader = null

            canvas.translate(0f, upperLen)
            canvas.rotate(elbowDeg)
            fillPaint.color = argb(palette.primaryFur)
            val tipPath = Path().apply {
                moveTo(-8f * u, 0f)
                quadTo(-11f * u, foreLen * 0.7f, 0f, foreLen + 5f * u)
                quadTo(11f * u, foreLen * 0.7f, 8f * u, 0f)
                close()
            }
            canvas.drawPath(tipPath, fillPaint)
            fillPaint.color = Color.parseColor("#FFD13B")
            canvas.drawCircle(0f, foreLen * 0.65f, 4f * u, fillPaint)
        } else {
            // Upper arm 3D capsule
            drawLimbCapsule(canvas, 8.2f * u, upperLen, palette)

            // Forearm + Paw
            canvas.translate(0f, upperLen)
            canvas.rotate(elbowDeg)
            drawLimbCapsule(canvas, 7.2f * u, foreLen, palette)

            // Cute 3D Paw / Hand
            canvas.translate(0f, foreLen)
            fillPaint.shader = RadialGradient(
                -3f * u, -3f * u, 12f * u,
                intArrayOf(Color.WHITE, argb(palette.bellyColor), argb(palette.primaryFur)),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, 9.5f * u, fillPaint)
            fillPaint.shader = null
            strokePaint.color = Color.argb(75, 35, 18, 55)
            strokePaint.strokeWidth = 2f * u
            canvas.drawCircle(0f, 0f, 9.5f * u, strokePaint)
        }

        canvas.restore()
    }

    private fun drawLeg(
        canvas: Canvas,
        palette: AnimalPalette,
        hipX: Float,
        hipY: Float,
        hipDeg: Float,
        kneeDeg: Float,
        isLeft: Boolean,
        u: Float
    ) {
        val thighLen = 30f * u
        val shinLen = 28f * u

        canvas.save()
        canvas.translate(hipX, hipY)
        canvas.rotate(hipDeg)

        // Thigh 3D capsule
        drawLimbCapsule(canvas, 9.5f * u, thighLen, palette)

        // Shin
        canvas.translate(0f, thighLen)
        canvas.rotate(kneeDeg)
        drawLimbCapsule(canvas, 8.2f * u, shinLen, palette)

        // 3D Dancing Sneaker
        canvas.translate(0f, shinLen)
        val dir = if (isLeft) -1f else 1f
        val shoeRect = if (isLeft) {
            RectF(-17f * u, -4f * u, 10f * u, 12f * u)
        } else {
            RectF(-10f * u, -4f * u, 17f * u, 12f * u)
        }
        fillPaint.shader = LinearGradient(
            0f, -4f * u, 0f, 12f * u,
            blend(argb(palette.shoeColor), Color.WHITE, 0.3f),
            argb(palette.shoeColor),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(shoeRect, 8f * u, 8f * u, fillPaint)
        fillPaint.shader = null

        // White sneaker sole
        fillPaint.color = Color.WHITE
        val soleRect = RectF(shoeRect.left, 7f * u, shoeRect.right, 12.5f * u)
        canvas.drawRoundRect(soleRect, 4f * u, 4f * u, fillPaint)

        // Cute sneaker highlight stripe
        fillPaint.color = Color.argb(190, 255, 255, 255)
        canvas.drawCircle(dir * 6f * u, 2f * u, 2.5f * u, fillPaint)

        canvas.restore()
    }

    private fun drawLimbCapsule(
        canvas: Canvas,
        radius: Float,
        length: Float,
        palette: AnimalPalette
    ) {
        val rect = RectF(-radius, -radius * 0.4f, radius, length + radius * 0.4f)
        fillPaint.shader = LinearGradient(
            -radius, 0f, radius, 0f,
            intArrayOf(argb(palette.highlightFur), argb(palette.primaryFur), argb(palette.shadowFur)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, radius, radius, fillPaint)
        fillPaint.shader = null

        strokePaint.color = Color.argb(70, 35, 18, 55)
        strokePaint.strokeWidth = (radius * 0.22f)
        canvas.drawRoundRect(rect, radius, radius, strokePaint)
    }

    private fun drawTail(
        canvas: Canvas,
        animal: AnimalType,
        palette: AnimalPalette,
        pose: CharacterPose,
        u: Float
    ) {
        canvas.save()
        canvas.translate(-16f * u, -2f * u)
        canvas.rotate(pose.tailSwingDeg)

        when (animal) {
            AnimalType.HATHI -> {
                // Short cute elephant tail
                strokePaint.color = argb(palette.shadowFur)
                strokePaint.strokeWidth = 4.5f * u
                canvas.drawLine(0f, 0f, -18f * u, 14f * u, strokePaint)
                fillPaint.color = argb(palette.innerEarColor)
                canvas.drawCircle(-19f * u, 15f * u, 4.5f * u, fillPaint)
            }
            AnimalType.MURGA -> {
                // Colorful rooster tail feathers
                val featherColors = intArrayOf(
                    Color.parseColor("#FF2E4C"),
                    Color.parseColor("#FFD13B"),
                    Color.parseColor("#2ECC71")
                )
                for (i in 0..2) {
                    canvas.save()
                    canvas.rotate(-15f + i * 16f)
                    fillPaint.color = featherColors[i]
                    val fPath = Path().apply {
                        moveTo(0f, 0f)
                        quadTo(-26f * u, -20f * u, -34f * u, -4f * u)
                        quadTo(-18f * u, 8f * u, 0f, 4f * u)
                        close()
                    }
                    canvas.drawPath(fPath, fillPaint)
                    canvas.restore()
                }
            }
            AnimalType.BANDAR, AnimalType.BILLI -> {
                // Long playful S-curve tail
                strokePaint.color = argb(palette.shadowFur)
                strokePaint.strokeWidth = 7.5f * u
                val tailPath = Path().apply {
                    moveTo(0f, 0f)
                    cubicTo(-28f * u, -6f * u, -42f * u, -34f * u, -26f * u, -48f * u)
                }
                canvas.drawPath(tailPath, strokePaint)
                strokePaint.color = argb(palette.primaryFur)
                strokePaint.strokeWidth = 4.5f * u
                canvas.drawPath(tailPath, strokePaint)
            }
            AnimalType.SHER -> {
                // Lion tail with fluffy dark tuft
                strokePaint.color = argb(palette.primaryFur)
                strokePaint.strokeWidth = 5.5f * u
                val tailPath = Path().apply {
                    moveTo(0f, 0f)
                    quadTo(-28f * u, -8f * u, -34f * u, -30f * u)
                }
                canvas.drawPath(tailPath, strokePaint)
                fillPaint.color = Color.parseColor("#B84A00")
                canvas.drawCircle(-34f * u, -32f * u, 8f * u, fillPaint)
            }
            AnimalType.KUTTA -> {
                // Wagging puffy puppy tail
                strokePaint.color = argb(palette.primaryFur)
                strokePaint.strokeWidth = 9f * u
                canvas.drawLine(0f, 0f, -24f * u, -22f * u, strokePaint)
                fillPaint.color = argb(palette.bellyColor)
                canvas.drawCircle(-25f * u, -23f * u, 6f * u, fillPaint)
            }
        }
        canvas.restore()
    }

    private fun drawHead(
        canvas: Canvas,
        animal: AnimalType,
        dance: DanceStyle,
        palette: AnimalPalette,
        pose: CharacterPose,
        u: Float,
        isDancing: Boolean
    ) {
        // 1. Lion Mane behind head if SHER
        if (animal == AnimalType.SHER) {
            val petalCount = 12
            val maneColor = Color.parseColor("#D96B00")
            val maneHighlight = Color.parseColor("#FF9900")
            for (i in 0 until petalCount) {
                val angle = (i * 2.0 * PI / petalCount).toFloat()
                val px = cos(angle) * 35f * u
                val py = sin(angle) * 33f * u
                fillPaint.shader = RadialGradient(
                    px - 4f * u, py - 4f * u, 22f * u,
                    maneHighlight, maneColor, Shader.TileMode.CLAMP
                )
                canvas.drawCircle(px, py, 16f * u, fillPaint)
            }
            fillPaint.shader = null
        }

        // 2. Ears behind/around head
        drawEars(canvas, animal, palette, pose, u)

        // 3. Rooster Comb on top of head
        if (animal == AnimalType.MURGA) {
            fillPaint.color = Color.parseColor("#FF2E4C")
            val bounce = pose.earBounceDeg * 0.15f * u
            canvas.drawCircle(-9f * u, -34f * u - bounce, 8.5f * u, fillPaint)
            canvas.drawCircle(0f, -38f * u - bounce, 10f * u, fillPaint)
            canvas.drawCircle(10f * u, -33f * u - bounce, 8f * u, fillPaint)
        }

        // 4. Main 3D Head Sphere/Oval
        val headRect = RectF(-36f * u, -33f * u, 36f * u, 31f * u)
        fillPaint.shader = RadialGradient(
            -12f * u, -14f * u, 52f * u,
            intArrayOf(argb(palette.highlightFur), argb(palette.primaryFur), argb(palette.shadowFur)),
            floatArrayOf(0f, 0.62f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawOval(headRect, fillPaint)
        fillPaint.shader = null

        strokePaint.color = Color.argb(80, 35, 18, 55)
        strokePaint.strokeWidth = 2.2f * u
        canvas.drawOval(headRect, strokePaint)

        // 5. Face inner mask (Monkey / Cat / Lion muzzle / Elephant cheeks)
        val faceShiftX = pose.bodyTurn * 6f * u
        if (animal == AnimalType.BANDAR) {
            fillPaint.color = argb(palette.bellyColor)
            canvas.drawCircle(-11f * u + faceShiftX, -4f * u, 16f * u, fillPaint)
            canvas.drawCircle(11f * u + faceShiftX, -4f * u, 16f * u, fillPaint)
            canvas.drawOval(RectF(-24f * u + faceShiftX, -2f * u, 24f * u + faceShiftX, 27f * u), fillPaint)
        } else if (animal == AnimalType.KUTTA || animal == AnimalType.SHER || animal == AnimalType.BILLI) {
            fillPaint.color = argb(palette.bellyColor)
            canvas.drawOval(RectF(-18f * u + faceShiftX, 2f * u, 18f * u + faceShiftX, 25f * u), fillPaint)
        }

        // Rosy glowing cheeks
        fillPaint.color = Color.argb(120, 255, 105, 145)
        canvas.drawOval(RectF(-28f * u + faceShiftX, 2f * u, -14f * u + faceShiftX, 12f * u), fillPaint)
        canvas.drawOval(RectF(14f * u + faceShiftX, 2f * u, 28f * u + faceShiftX, 12f * u), fillPaint)

        // 6. Expressive Cartoon Eyes with catchlights & blink
        drawEye(canvas, -13f * u + faceShiftX, -6f * u, pose.blinkAmount, u)
        drawEye(canvas, 13f * u + faceShiftX, -6f * u, pose.blinkAmount, u)

        // 7. Nose / Beak / Trunk & Happy Mouth
        drawSnoutAndMouth(canvas, animal, palette, pose, faceShiftX, u)

        // 8. Dance Style Headgear (DJ Headphones / Hip-Hop Cap / Party Hat)
        drawDanceHeadgear(canvas, dance, u, isDancing)
    }

    private fun drawEars(
        canvas: Canvas,
        animal: AnimalType,
        palette: AnimalPalette,
        pose: CharacterPose,
        u: Float
    ) {
        val earAngle = pose.earBounceDeg
        when (animal) {
            AnimalType.BILLI -> {
                for (dir in listOf(-1f, 1f)) {
                    canvas.save()
                    canvas.translate(dir * 22f * u, -24f * u)
                    canvas.rotate(dir * (18f + earAngle * 0.5f))
                    val outer = Path().apply {
                        moveTo(-11f * u, 6f * u)
                        lineTo(0f, -20f * u)
                        lineTo(11f * u, 6f * u)
                        close()
                    }
                    fillPaint.color = argb(palette.primaryFur)
                    canvas.drawPath(outer, fillPaint)
                    val inner = Path().apply {
                        moveTo(-6f * u, 3f * u)
                        lineTo(0f, -13f * u)
                        lineTo(6f * u, 3f * u)
                        close()
                    }
                    fillPaint.color = argb(palette.innerEarColor)
                    canvas.drawPath(inner, fillPaint)
                    canvas.restore()
                }
            }
            AnimalType.KUTTA -> {
                for (dir in listOf(-1f, 1f)) {
                    canvas.save()
                    canvas.translate(dir * 30f * u, -10f * u)
                    canvas.rotate(dir * (18f + earAngle * 0.9f))
                    fillPaint.color = argb(palette.innerEarColor)
                    canvas.drawOval(RectF(-9f * u, -4f * u, 9f * u, 28f * u), fillPaint)
                    canvas.restore()
                }
            }
            AnimalType.BANDAR, AnimalType.SHER -> {
                for (dir in listOf(-1f, 1f)) {
                    canvas.save()
                    canvas.translate(dir * 33f * u, -14f * u)
                    fillPaint.color = argb(palette.primaryFur)
                    canvas.drawCircle(0f, 0f, 13f * u, fillPaint)
                    fillPaint.color = argb(palette.innerEarColor)
                    canvas.drawCircle(0f, 0f, 8f * u, fillPaint)
                    canvas.restore()
                }
            }
            AnimalType.HATHI -> {
                for (dir in listOf(-1f, 1f)) {
                    canvas.save()
                    canvas.translate(dir * 28f * u, -8f * u)
                    canvas.rotate(dir * (-12f - earAngle * 0.9f))
                    fillPaint.color = argb(palette.primaryFur)
                    canvas.drawOval(RectF(-16f * u, -22f * u, 16f * u, 24f * u), fillPaint)
                    fillPaint.color = argb(palette.innerEarColor)
                    canvas.drawOval(RectF(-10f * u, -15f * u, 10f * u, 16f * u), fillPaint)
                    canvas.restore()
                }
            }
            AnimalType.MURGA -> Unit
        }
    }

    private fun drawEye(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        blinkAmount: Float,
        u: Float
    ) {
        if (blinkAmount > 0.55f) {
            strokePaint.color = Color.parseColor("#1F1A38")
            strokePaint.strokeWidth = 3f * u
            canvas.drawArc(
                RectF(cx - 7f * u, cy - 3f * u, cx + 7f * u, cy + 5f * u),
                190f, 160f, false, strokePaint
            )
            return
        }

        // White sclera
        fillPaint.color = Color.WHITE
        canvas.drawOval(RectF(cx - 7.5f * u, cy - 8.5f * u, cx + 7.5f * u, cy + 8.5f * u), fillPaint)

        // Dark expressive pupil
        fillPaint.color = Color.parseColor("#1E1738")
        canvas.drawCircle(cx, cy + 0.5f * u, 5.2f * u, fillPaint)

        // Glossy specular catchlights
        fillPaint.color = Color.WHITE
        canvas.drawCircle(cx - 2f * u, cy - 2f * u, 2.2f * u, fillPaint)
        canvas.drawCircle(cx + 2.2f * u, cy + 2f * u, 1.1f * u, fillPaint)
    }

    private fun drawSnoutAndMouth(
        canvas: Canvas,
        animal: AnimalType,
        palette: AnimalPalette,
        pose: CharacterPose,
        faceShiftX: Float,
        u: Float
    ) {
        when (animal) {
            AnimalType.HATHI -> {
                // Cute mini tusks
                fillPaint.color = Color.parseColor("#FFF9E6")
                canvas.drawArc(
                    RectF(-16f * u + faceShiftX, 8f * u, -4f * u + faceShiftX, 22f * u),
                    20f, 140f, false, fillPaint
                )
                canvas.drawArc(
                    RectF(4f * u + faceShiftX, 8f * u, 16f * u + faceShiftX, 22f * u),
                    20f, 140f, false, fillPaint
                )
                // Animated curling 3D trunk!
                val curl = pose.trunkCurl
                strokePaint.color = argb(palette.primaryFur)
                strokePaint.strokeWidth = 10.5f * u
                val trunkPath = Path().apply {
                    moveTo(faceShiftX, 4f * u)
                    cubicTo(
                        faceShiftX + curl * 14f * u, 18f * u,
                        faceShiftX + curl * 26f * u, 26f * u - absFloat(curl) * 10f * u,
                        faceShiftX + curl * 18f * u, 32f * u - absFloat(curl) * 14f * u
                    )
                }
                canvas.drawPath(trunkPath, strokePaint)
                strokePaint.color = argb(palette.highlightFur)
                strokePaint.strokeWidth = 4f * u
                canvas.drawPath(trunkPath, strokePaint)
            }
            AnimalType.MURGA -> {
                // Bright yellow-orange beak opening on beat
                val open = pose.mouthOpen * 6f * u
                fillPaint.color = Color.parseColor("#FFD13B")
                val topBeak = Path().apply {
                    moveTo(-9f * u + faceShiftX, 5f * u)
                    lineTo(9f * u + faceShiftX, 5f * u)
                    lineTo(faceShiftX, 14f * u)
                    close()
                }
                canvas.drawPath(topBeak, fillPaint)
                fillPaint.color = Color.parseColor("#FF8C00")
                val bottomBeak = Path().apply {
                    moveTo(-7f * u + faceShiftX, 11f * u + open * 0.4f)
                    lineTo(7f * u + faceShiftX, 11f * u + open * 0.4f)
                    lineTo(faceShiftX, 18f * u + open)
                    close()
                }
                canvas.drawPath(bottomBeak, fillPaint)
                // Red wattle
                fillPaint.color = Color.parseColor("#FF2E4C")
                canvas.drawCircle(faceShiftX, 21f * u + open * 0.5f, 4.5f * u, fillPaint)
            }
            else -> {
                // Nose
                fillPaint.color = argb(palette.noseColor)
                canvas.drawOval(
                    RectF(-6.5f * u + faceShiftX, 2f * u, 6.5f * u + faceShiftX, 10f * u),
                    fillPaint
                )
                fillPaint.color = Color.argb(170, 255, 255, 255)
                canvas.drawCircle(-2f * u + faceShiftX, 4.5f * u, 1.6f * u, fillPaint)

                // Happy singing/smiling mouth
                val mouthH = (5f + pose.mouthOpen * 8f) * u
                fillPaint.color = Color.parseColor("#C2185B")
                canvas.drawArc(
                    RectF(-10f * u + faceShiftX, 11f * u, 10f * u + faceShiftX, 11f * u + mouthH),
                    0f, 180f, true, fillPaint
                )
                // Pink tongue
                fillPaint.color = Color.parseColor("#FF77A9")
                canvas.drawOval(
                    RectF(-5f * u + faceShiftX, 13f * u + mouthH * 0.25f, 5f * u + faceShiftX, 11f * u + mouthH),
                    fillPaint
                )

                // Whiskers for Billi
                if (animal == AnimalType.BILLI) {
                    strokePaint.color = Color.argb(180, 75, 45, 75)
                    strokePaint.strokeWidth = 1.8f * u
                    for (dir in listOf(-1f, 1f)) {
                        canvas.drawLine(dir * 12f * u + faceShiftX, 7f * u, dir * 32f * u + faceShiftX, 3f * u, strokePaint)
                        canvas.drawLine(dir * 12f * u + faceShiftX, 11f * u, dir * 33f * u + faceShiftX, 11f * u, strokePaint)
                        canvas.drawLine(dir * 12f * u + faceShiftX, 15f * u, dir * 30f * u + faceShiftX, 19f * u, strokePaint)
                    }
                }
            }
        }
    }

    private fun drawDanceHeadgear(
        canvas: Canvas,
        dance: DanceStyle,
        u: Float,
        isDancing: Boolean
    ) {
        when (dance) {
            DanceStyle.DJ_DANCE -> {
                // Sleek Glowing DJ Headphones!
                strokePaint.color = Color.parseColor("#1F1A38")
                strokePaint.strokeWidth = 6f * u
                canvas.drawArc(
                    RectF(-38f * u, -38f * u, 38f * u, 28f * u),
                    192f, 156f, false, strokePaint
                )
                for (dir in listOf(-1f, 1f)) {
                    fillPaint.color = Color.parseColor("#1F1A38")
                    canvas.drawOval(RectF(dir * 36f * u - 8f * u, -18f * u, dir * 36f * u + 8f * u, 6f * u), fillPaint)
                    fillPaint.color = Color.parseColor("#00E5FF")
                    canvas.drawOval(RectF(dir * 36f * u - 5f * u, -13f * u, dir * 36f * u + 5f * u, 1f * u), fillPaint)
                }
            }
            DanceStyle.HIP_HOP -> {
                // Cool Tilted Hip-Hop Snapback Cap
                canvas.save()
                canvas.translate(2f * u, -24f * u)
                canvas.rotate(-12f)
                fillPaint.shader = LinearGradient(
                    -22f * u, -14f * u, 22f * u, 4f * u,
                    Color.parseColor("#FF3E8A"), Color.parseColor("#6C4BFF"), Shader.TileMode.CLAMP
                )
                canvas.drawArc(RectF(-22f * u, -16f * u, 22f * u, 10f * u), 180f, 180f, true, fillPaint)
                fillPaint.shader = null
                // Cap visor
                fillPaint.color = Color.parseColor("#FFD13B")
                canvas.drawRoundRect(RectF(-2f * u, -4f * u, 30f * u, 4f * u), 4f * u, 4f * u, fillPaint)
                canvas.restore()
            }
            DanceStyle.FUNNY_DANCE -> {
                if (isDancing) {
                    // Silly colorful party crown
                    fillPaint.color = Color.parseColor("#FFD13B")
                    val crown = Path().apply {
                        moveTo(-14f * u, -30f * u)
                        lineTo(-10f * u, -46f * u)
                        lineTo(-2f * u, -34f * u)
                        lineTo(5f * u, -48f * u)
                        lineTo(13f * u, -30f * u)
                        close()
                    }
                    canvas.drawPath(crown, fillPaint)
                }
            }
            DanceStyle.GAON_WALA -> Unit
        }
    }

    private fun argb(hex: Long): Int = (0xFF000000L or hex).toInt()

    private fun blend(c1: Int, c2: Int, ratio: Float): Int {
        val inv = 1f - ratio
        return Color.rgb(
            (Color.red(c1) * inv + Color.red(c2) * ratio).toInt(),
            (Color.green(c1) * inv + Color.green(c2) * ratio).toInt(),
            (Color.blue(c1) * inv + Color.blue(c2) * ratio).toInt()
        )
    }

    private fun absFloat(v: Float): Float = if (v < 0f) -v else v
}
