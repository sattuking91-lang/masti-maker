package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.SongTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AudioPreviewPlayer(private val scope: CoroutineScope) {
    private var playJob: Job? = null
    private var audioTrack: AudioTrack? = null

    @Volatile
    private var currentGain: Float = 1.0f

    fun setVolumeGain(gain: Float) {
        currentGain = gain.coerceIn(0.05f, 1.0f)
    }

    fun playLoop(song: SongTrack, volumeGain: Float = currentGain) {
        currentGain = volumeGain.coerceIn(0.05f, 1.0f)
        stop()
        playJob = scope.launch(Dispatchers.Default) {
            val sampleRate = MusicSynthesizer.SAMPLE_RATE
            val minBufBytes = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(4096)

            val track = runCatching {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufBytes * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            }.getOrNull() ?: return@launch

            audioTrack = track
            runCatching { track.play() }

            val chunkSamples = minBufBytes / 2
            var sampleOffset = 0
            try {
                while (isActive) {
                    val pcm = MusicSynthesizer.renderChunk(
                        song = song,
                        startSample = sampleOffset,
                        numSamples = chunkSamples,
                        volumeGain = currentGain
                    )
                    sampleOffset += chunkSamples
                    val written = track.write(pcm, 0, pcm.size)
                    if (written < 0) break
                }
            } finally {
                runCatching {
                    track.pause()
                    track.flush()
                    track.release()
                }
                if (audioTrack === track) {
                    audioTrack = null
                }
            }
        }
    }

    fun playPcmOnce(
        samples: ShortArray,
        volumeGain: Float = currentGain,
        onComplete: () -> Unit = {}
    ) {
        if (samples.isEmpty()) {
            onComplete()
            return
        }
        val clampedGain = volumeGain.coerceIn(0.05f, 1.0f)
        stop()
        playJob = scope.launch(Dispatchers.Default) {
            val sampleRate = MusicSynthesizer.SAMPLE_RATE
            val minBufBytes = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(4096)

            val track = runCatching {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufBytes * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            }.getOrNull()

            if (track == null) {
                onComplete()
                return@launch
            }

            audioTrack = track
            runCatching { track.play() }

            val chunkSize = minBufBytes / 2
            var cursor = 0
            try {
                while (isActive && cursor < samples.size) {
                    val count = minOf(chunkSize, samples.size - cursor)
                    val scaled = ShortArray(count) { idx ->
                        (samples[cursor + idx] * clampedGain).toInt().coerceIn(-32767, 32767).toShort()
                    }
                    val written = track.write(scaled, 0, count)
                    if (written < 0) break
                    cursor += count
                }
            } finally {
                runCatching {
                    track.pause()
                    track.flush()
                    track.release()
                }
                if (audioTrack === track) {
                    audioTrack = null
                }
                onComplete()
            }
        }
    }

    fun stop() {
        playJob?.cancel()
        playJob = null
        runCatching {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.release()
        }
        audioTrack = null
    }
}

