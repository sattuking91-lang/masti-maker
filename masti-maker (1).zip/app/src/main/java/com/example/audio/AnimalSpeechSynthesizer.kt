package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.model.AnimalType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.UUID

class AnimalSpeechSynthesizer(private val context: Context) {
    private var tts: TextToSpeech? = null
    private val readyDeferred = CompletableDeferred<Boolean>()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val ok = status == TextToSpeech.SUCCESS
            if (ok) {
                val hindi = Locale("hi", "IN")
                val res = tts?.setLanguage(hindi)
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
            }
            if (!readyDeferred.isCompleted) {
                readyDeferred.complete(ok)
            }
        }
    }

    fun pitchForAnimal(animal: AnimalType): Float = when (animal) {
        AnimalType.BILLI -> 1.42f
        AnimalType.KUTTA -> 1.12f
        AnimalType.BANDAR -> 1.48f
        AnimalType.HATHI -> 0.78f
        AnimalType.MURGA -> 1.36f
        AnimalType.SHER -> 0.72f
    }

    fun animalCatchphrase(animal: AnimalType): String = when (animal) {
        AnimalType.BILLI -> "Meow meow! Main hoon Billi, chalo dance karte hain!"
        AnimalType.KUTTA -> "Bhow bhow! Main hoon Kutta, DJ chalao!"
        AnimalType.BANDAR -> "Kho kho! Main hoon Bandar, masti ka time hai!"
        AnimalType.HATHI -> "Pawoo! Main hoon Hathi, dhamaka dance dekho!"
        AnimalType.MURGA -> "Kukdu koo! Main hoon Murga, sabko nacha dunga!"
        AnimalType.SHER -> "Roar! Main hoon Sher, jungle me party hai!"
    }

    fun storySamplePhrase(animal: AnimalType): String = when (animal) {
        AnimalType.BILLI -> "Ek din pyari Billi jungle me naach rahi thi, sab taali baja rahe the!"
        AnimalType.KUTTA -> "Ek din sher-dil Kutta gaane gaate hue doston se mila aur party shuru hui!"
        AnimalType.BANDAR -> "Ek din natkhat Bandar ped se kooda aur sabke saath masti me jhoomne laga!"
        AnimalType.HATHI -> "Ek din bada Hathi apni soond hila kar sabko pyari kahani sunane laga!"
        AnimalType.MURGA -> "Subah hote hi Murga bola kukdu koo, chalo sab milkar dance karte hain!"
        AnimalType.SHER -> "Jungle ka raja Sher bola, aaj sab milkar khushi se kahani sunenge aur nachenge!"
    }

    suspend fun speakLive(text: String, animal: AnimalType, speechRate: Float) {
        val ready = withTimeoutOrNull(1800L) { readyDeferred.await() } ?: false
        if (!ready) return
        val engine = tts ?: return
        withContext(Dispatchers.Main) {
            runCatching {
                engine.setPitch(pitchForAnimal(animal))
                engine.setSpeechRate(speechRate)
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), UUID.randomUUID().toString())
            }
        }
    }

    fun stopSpeaking() {
        runCatching { tts?.stop() }
    }

    suspend fun synthesizeTextToPcm(
        text: String,
        animal: AnimalType,
        speechRate: Float = 1.0f
    ): ShortArray? {
        val ready = withTimeoutOrNull(2200L) { readyDeferred.await() } ?: false
        if (!ready) return null
        val engine = tts ?: return null
        val tmpDir = File(context.cacheDir, "tts_tmp").apply { mkdirs() }
        val outFile = File(tmpDir, "tts_${UUID.randomUUID()}.wav")
        val uttId = UUID.randomUUID().toString()
        val done = CompletableDeferred<Boolean>()

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                if (utteranceId == uttId && !done.isCompleted) {
                    done.complete(true)
                }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == uttId && !done.isCompleted) {
                    done.complete(false)
                }
            }
            override fun onError(utteranceId: String?, errorCode: Int) {
                if (utteranceId == uttId && !done.isCompleted) {
                    done.complete(false)
                }
            }
        })

        withContext(Dispatchers.Main) {
            engine.setPitch(pitchForAnimal(animal))
            engine.setSpeechRate(speechRate)
            val res = engine.synthesizeToFile(text, Bundle(), outFile, uttId)
            if (res != TextToSpeech.SUCCESS && !done.isCompleted) {
                done.complete(false)
            }
        }

        val ok = withTimeoutOrNull(3500L) { done.await() } ?: false
        val pcm = if (ok) AnimalVoiceSynthesizer.readWavAs44100Mono(outFile) else null
        runCatching { outFile.delete() }
        return pcm
    }

    fun release() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }
}
