package com.example.audio

import com.example.model.AnimalType
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh

object AnimalVoiceSynthesizer {
    const val SAMPLE_RATE = MusicSynthesizer.SAMPLE_RATE

    /**
     * Generates a ~1.2s authentic expressive vocalization PCM clip for any of the 6 animals.
     */
    fun renderAnimalClip(animal: AnimalType, volumeGain: Float = 1.0f): ShortArray {
        val durationSec = when (animal) {
            AnimalType.MURGA -> 1.45f
            AnimalType.SHER -> 1.35f
            AnimalType.HATHI -> 1.25f
            else -> 1.15f
        }
        val numSamples = (SAMPLE_RATE * durationSec).toInt()
        val out = ShortArray(numSamples)
        val gain = volumeGain.coerceIn(0.1f, 1.0f)

        var phase = 0.0
        for (i in 0 until numSamples) {
            val t = i.toFloat() / SAMPLE_RATE
            val progress = i.toFloat() / numSamples

            val sample: Float
            when (animal) {
                AnimalType.BILLI -> {
                    // Two cute "Mee-oww!" meows
                    val localT = (t % 0.58f) / 0.58f
                    val env = sin(PI * localT).toFloat().coerceAtLeast(0f)
                    val freq = if (localT < 0.35f) {
                        520f + 340f * (localT / 0.35f)
                    } else {
                        860f - 440f * ((localT - 0.35f) / 0.65f)
                    }
                    phase += 2.0 * PI * freq / SAMPLE_RATE
                    val meow = sin(phase).toFloat() + 0.45f * sin(2.0 * phase).toFloat() + 0.18f * sin(3.0 * phase).toFloat()
                    sample = meow * env * 0.62f
                }
                AnimalType.KUTTA -> {
                    // Energetic double bark "Bhow! Bhow!"
                    val barkIdx = if (t < 0.55f) t else (t - 0.55f)
                    val env = if (barkIdx in 0.02f..0.24f) {
                        val b = (barkIdx - 0.02f) / 0.22f
                        sin(PI * b).toFloat() * exp(-b * 2.5f) * 1.4f
                    } else 0f
                    val barkProgress = ((barkIdx - 0.02f) / 0.22f).coerceIn(0f, 1f)
                    val freq = 390f - 180f * barkProgress
                    phase += 2.0 * PI * freq / SAMPLE_RATE
                    val growl = (sin(phase).toFloat() + 0.6f * sin(2.0 * phase).toFloat() + 0.3f * pseudoNoise(i))
                    sample = growl * env * 0.65f
                }
                AnimalType.BANDAR -> {
                    // Rapid cheerful "Kho-Kho-Hoo-Haa!" monkey chatter
                    val pulse = (t * 5.2f) % 1f
                    val env = sin(PI * pulse).toFloat().coerceAtLeast(0f)
                    val pitchStep = ((t * 5.2f).toInt() % 4)
                    val baseF = when (pitchStep) {
                        0 -> 660f
                        1 -> 820f
                        2 -> 720f
                        else -> 940f
                    }
                    val freq = baseF + 160f * sin(PI * pulse).toFloat()
                    phase += 2.0 * PI * freq / SAMPLE_RATE
                    val hoot = sin(phase).toFloat() + 0.35f * sin(2.0 * phase).toFloat()
                    sample = hoot * env * 0.58f
                }
                AnimalType.HATHI -> {
                    // Mighty brassy elephant trumpet "Paa-Woooo!"
                    val env = sin(PI * progress).toFloat().coerceAtLeast(0f)
                    val vibrato = 1f + 0.035f * sin(2.0 * PI * 14.0 * t).toFloat()
                    val freq = (if (progress < 0.3f) {
                        260f + 330f * (progress / 0.3f)
                    } else {
                        590f - 190f * ((progress - 0.3f) / 0.7f)
                    }) * vibrato
                    phase += 2.0 * PI * freq / SAMPLE_RATE
                    val brass = sin(phase).toFloat() +
                        0.65f * sin(2.0 * phase).toFloat() +
                        0.45f * sin(3.0 * phase).toFloat() +
                        0.25f * sin(4.0 * phase).toFloat()
                    sample = brass * env * 0.52f
                }
                AnimalType.MURGA -> {
                    // Classic 4-part "Kuk-du-koo-ooo!"
                    val syll = when {
                        t < 0.22f -> 0
                        t < 0.44f -> 1
                        t < 0.68f -> 2
                        else -> 3
                    }
                    val localEnv = when (syll) {
                        0 -> sin(PI * (t / 0.22f)).toFloat()
                        1 -> sin(PI * ((t - 0.22f) / 0.22f)).toFloat()
                        2 -> sin(PI * ((t - 0.44f) / 0.24f)).toFloat()
                        else -> sin(PI * ((t - 0.68f) / 0.77f)).toFloat()
                    }.coerceAtLeast(0f)
                    val freq = when (syll) {
                        0 -> 540f
                        1 -> 660f
                        2 -> 500f
                        else -> 780f - 220f * ((t - 0.68f) / 0.77f).coerceIn(0f, 1f)
                    }
                    phase += 2.0 * PI * freq / SAMPLE_RATE
                    val crow = sin(phase).toFloat() + 0.55f * sin(2.0 * phase).toFloat() + 0.28f * sin(3.0 * phase).toFloat()
                    sample = crow * localEnv * 0.56f
                }
                AnimalType.SHER -> {
                    // Deep chesty lion roar "Roooaaar!"
                    val env = sin(PI * progress).toFloat().coerceAtLeast(0f)
                    val freq = 115f + 55f * sin(PI * progress).toFloat() - 35f * progress
                    phase += 2.0 * PI * freq / SAMPLE_RATE
                    val rumble = sin(phase).toFloat() +
                        0.7f * sin(2.0 * phase).toFloat() +
                        0.4f * sin(3.0 * phase).toFloat() +
                        0.32f * pseudoNoise(i)
                    sample = rumble * env * 0.65f
                }
            }

            val clipped = tanh(sample * 1.1f) * gain
            out[i] = (clipped * 30000f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return out
    }

    /**
     * Mixes a chunk of background music with an optional full-video voice track,
     * ducking the music whenever voice energy is present so the voice stays crystal clear.
     */
    fun mixMusicAndVoice(
        musicChunk: ShortArray,
        voiceTrack: ShortArray?,
        startSample: Int,
        loopVoice: Boolean = false
    ): ShortArray {
        if (voiceTrack == null || voiceTrack.isEmpty()) return musicChunk
        val out = ShortArray(musicChunk.size)
        for (i in musicChunk.indices) {
            val globalIdx = startSample + i
            val voiceIdx = if (loopVoice) globalIdx % voiceTrack.size else globalIdx
            val vSample = if (voiceIdx in voiceTrack.indices) voiceTrack[voiceIdx].toInt() else 0
            val musicDuck = if (abs(vSample) > 220) 0.36f else 1.0f
            val mixed = musicChunk[i] * musicDuck + vSample * 1.15f
            out[i] = mixed.toInt().coerceIn(-32767, 32767).toShort()
        }
        return out
    }

    /**
     * Reads any PCM 16-bit WAV file (recorded mic or Android TTS output) and resamples to 44.1kHz mono.
     */
    fun readWavAs44100Mono(file: File): ShortArray? {
        if (!file.exists() || file.length() < 44) return null
        return runCatching {
            val bytes = file.readBytes()
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            if (bytes.size < 44) return null
            if (String(bytes, 0, 4) != "RIFF" || String(bytes, 8, 4) != "WAVE") return null

            var channels = 1
            var srcSampleRate = SAMPLE_RATE
            var bitsPerSample = 16
            var dataOffset = -1
            var dataSize = 0

            var pos = 12
            while (pos + 8 <= bytes.size) {
                val chunkId = String(bytes, pos, 4)
                val chunkSize = buf.getInt(pos + 4)
                val payloadPos = pos + 8
                if (chunkId == "fmt " && payloadPos + 16 <= bytes.size) {
                    channels = buf.getShort(payloadPos + 2).toInt().coerceAtLeast(1)
                    srcSampleRate = buf.getInt(payloadPos + 4).coerceAtLeast(8000)
                    bitsPerSample = buf.getShort(payloadPos + 14).toInt()
                } else if (chunkId == "data") {
                    dataOffset = payloadPos
                    dataSize = chunkSize.coerceAtMost(bytes.size - payloadPos).coerceAtLeast(0)
                    break
                }
                val advance = 8 + chunkSize + (chunkSize and 1)
                if (advance <= 8) break
                pos += advance
            }

            if (dataOffset < 0 || dataSize <= 0 || bitsPerSample != 16) return null

            val totalFrames = dataSize / (2 * channels)
            if (totalFrames <= 0) return null
            val monoSrc = ShortArray(totalFrames)
            for (f in 0 until totalFrames) {
                var sum = 0
                val frameBytePos = dataOffset + f * 2 * channels
                for (c in 0 until channels) {
                    sum += buf.getShort(frameBytePos + c * 2).toInt()
                }
                monoSrc[f] = (sum / channels).toShort()
            }

            if (srcSampleRate == SAMPLE_RATE) return monoSrc

            val targetLen = ((totalFrames.toLong() * SAMPLE_RATE) / srcSampleRate).toInt().coerceAtLeast(1)
            val resampled = ShortArray(targetLen)
            val ratio = srcSampleRate.toDouble() / SAMPLE_RATE.toDouble()
            for (i in 0 until targetLen) {
                val srcPos = i * ratio
                val idx0 = srcPos.toInt().coerceIn(0, monoSrc.lastIndex)
                val idx1 = (idx0 + 1).coerceIn(0, monoSrc.lastIndex)
                val frac = (srcPos - idx0).toFloat()
                val s = monoSrc[idx0] * (1f - frac) + monoSrc[idx1] * frac
                resampled[i] = s.toInt().coerceIn(-32767, 32767).toShort()
            }
            resampled
        }.getOrNull()
    }

    private fun pseudoNoise(seed: Int): Float {
        var x = seed * 747796405 + 2891336453.toInt()
        x = ((x ushr ((x ushr 28) + 4)) xor x) * 277803737
        x = (x ushr 22) xor x
        return (x and 0xFFFF) / 32768f - 1f
    }
}
