package com.example.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

class VoiceRecorder(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private var recordJob: Job? = null
    private var activeFile: File? = null

    fun hasRecordPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

    fun startRecording(
        onAmplitudeAndTime: (amplitude: Float, seconds: Int) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!hasRecordPermission()) {
            onError("Mic permission nahi mili!")
            return
        }
        stopRecording()

        val recDir = File(context.filesDir, "recordings").apply { mkdirs() }
        val outFile = File(recDir, "user_voice.wav")
        activeFile = outFile

        recordJob = scope.launch(Dispatchers.IO) {
            val sampleRate = AnimalVoiceSynthesizer.SAMPLE_RATE
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(4096)

            val recorder = runCatching {
                @Suppress("MissingPermission")
                AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf * 2
                )
            }.getOrNull()

            if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                runCatching { recorder?.release() }
                onError("Microphone shuru nahi ho saka!")
                return@launch
            }

            val pcmStream = ByteArrayOutputStream()
            val shortBuf = ShortArray(minBuf / 2)
            val byteBuf = ByteArray(shortBuf.size * 2)
            var totalSamples = 0L
            val startMs = System.currentTimeMillis()

            try {
                recorder.startRecording()
                while (isActive) {
                    val readCount = recorder.read(shortBuf, 0, shortBuf.size)
                    if (readCount > 0) {
                        var peak = 0
                        for (i in 0 until readCount) {
                            val s = shortBuf[i]
                            val a = abs(s.toInt())
                            if (a > peak) peak = a
                            byteBuf[i * 2] = (s.toInt() and 0xFF).toByte()
                            byteBuf[i * 2 + 1] = ((s.toInt() shr 8) and 0xFF).toByte()
                        }
                        pcmStream.write(byteBuf, 0, readCount * 2)
                        totalSamples += readCount
                        val sec = ((System.currentTimeMillis() - startMs) / 1000L).toInt()
                        val normAmp = (peak / 20000f).coerceIn(0.05f, 1f)
                        onAmplitudeAndTime(normAmp, sec)
                        if (sec >= 60) break // Max 60s single recording safety cap
                    }
                }
            } catch (e: SecurityException) {
                onError("Microphone permission nahi hai!")
            } finally {
                runCatching { recorder.stop() }
                runCatching { recorder.release() }
                val pcmBytes = pcmStream.toByteArray()
                if (pcmBytes.isNotEmpty()) {
                    writeWavFile(outFile, pcmBytes, sampleRate, channels = 1, bitsPerSample = 16)
                }
            }
        }
    }

    fun stopRecording(): File? {
        recordJob?.cancel()
        recordJob = null
        return activeFile?.takeIf { it.exists() && it.length() > 44 }
    }

    fun getExistingRecording(): File? {
        val file = File(File(context.filesDir, "recordings"), "user_voice.wav")
        return file.takeIf { it.exists() && it.length() > 44 }
    }

    fun clearRecording() {
        stopRecording()
        val file = File(File(context.filesDir, "recordings"), "user_voice.wav")
        if (file.exists()) file.delete()
    }

    private fun writeWavFile(
        outFile: File,
        pcmData: ByteArray,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val totalDataLen = pcmData.size + 36

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // PCM subchunk size
            putShort(1.toShort()) // PCM format
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign.toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()

        FileOutputStream(outFile).use { fos ->
            fos.write(header)
            fos.write(pcmData)
        }
    }
}
