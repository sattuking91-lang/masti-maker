package com.example.animation

import com.example.model.AnimalType
import com.example.model.DanceStyle
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class CharacterPose(
    val hipOffsetX: Float = 0f,
    val hipOffsetY: Float = 0f,
    val squashX: Float = 1f,
    val squashY: Float = 1f,
    val torsoLeanDeg: Float = 0f,
    val bodyTurn: Float = 0f, // -1f..1f 3D depth foreshortening
    val headBobY: Float = 0f,
    val headTiltDeg: Float = 0f,
    val headNod: Float = 0f, // -1..1 vertical head nod shift
    val leftShoulderDeg: Float = 24f,
    val leftElbowDeg: Float = 18f,
    val rightShoulderDeg: Float = -24f,
    val rightElbowDeg: Float = -18f,
    val leftHipDeg: Float = 8f,
    val leftKneeDeg: Float = -6f,
    val rightHipDeg: Float = -8f,
    val rightKneeDeg: Float = 6f,
    val tailSwingDeg: Float = 0f,
    val earBounceDeg: Float = 0f,
    val trunkCurl: Float = 0f,
    val blinkAmount: Float = 0f, // 0 = open, 1 = closed
    val mouthOpen: Float = 0.25f,
    val stepName: String = ""
)

data class AnimalPalette(
    val primaryFur: Long,
    val highlightFur: Long,
    val shadowFur: Long,
    val bellyColor: Long,
    val innerEarColor: Long,
    val noseColor: Long,
    val shoeColor: Long,
    val outfitAccent: Long
)

object DanceChoreography {

    fun paletteFor(animal: AnimalType): AnimalPalette = when (animal) {
        AnimalType.BILLI -> AnimalPalette(
            primaryFur = 0xFFFFB7CE,
            highlightFur = 0xFFFFE3EE,
            shadowFur = 0xFFE27AA0,
            bellyColor = 0xFFFFF7FA,
            innerEarColor = 0xFFFF5C93,
            noseColor = 0xFFFF4081,
            shoeColor = 0xFF0099FF,
            outfitAccent = 0xFF00D2FF
        )
        AnimalType.KUTTA -> AnimalPalette(
            primaryFur = 0xFFF4A24E,
            highlightFur = 0xFFFFD39B,
            shadowFur = 0xFFC56E1D,
            bellyColor = 0xFFFFF1D6,
            innerEarColor = 0xFF8C4415,
            noseColor = 0xFF2B1D16,
            shoeColor = 0xFF00B87C,
            outfitAccent = 0xFFFF3B5C
        )
        AnimalType.BANDAR -> AnimalPalette(
            primaryFur = 0xFFA6602E,
            highlightFur = 0xFFD48D56,
            shadowFur = 0xFF6B3713,
            bellyColor = 0xFFFFDFBA,
            innerEarColor = 0xFFFFC196,
            noseColor = 0xFF4A2511,
            shoeColor = 0xFFFF8C00,
            outfitAccent = 0xFFFFD13B
        )
        AnimalType.HATHI -> AnimalPalette(
            primaryFur = 0xFF8E9EFF,
            highlightFur = 0xFFC7D0FF,
            shadowFur = 0xFF5A68CC,
            bellyColor = 0xFFE5EAFF,
            innerEarColor = 0xFFFF9EC4,
            noseColor = 0xFF7A8BFF,
            shoeColor = 0xFF7A3EFF,
            outfitAccent = 0xFF00E5FF
        )
        AnimalType.MURGA -> AnimalPalette(
            primaryFur = 0xFFFF8A3D,
            highlightFur = 0xFFFFC470,
            shadowFur = 0xFFD9531E,
            bellyColor = 0xFFFFF4D6,
            innerEarColor = 0xFFFF2E4C,
            noseColor = 0xFFFFC928,
            shoeColor = 0xFFFF5722,
            outfitAccent = 0xFF2ECC71
        )
        AnimalType.SHER -> AnimalPalette(
            primaryFur = 0xFFFFB830,
            highlightFur = 0xFFFFE17D,
            shadowFur = 0xFFD98200,
            bellyColor = 0xFFFFF3C4,
            innerEarColor = 0xFFB84A00,
            noseColor = 0xFF3E1F0D,
            shoeColor = 0xFFFF2D78,
            outfitAccent = 0xFF7A3EFF
        )
    }

    fun computePose(
        dance: DanceStyle,
        timeSeconds: Float,
        bpm: Int = dance.bpm,
        isDancing: Boolean = true
    ): CharacterPose {
        val blinkCycle = timeSeconds % 3.4f
        val blink = if (blinkCycle in 3.15f..3.32f) {
            sin(((blinkCycle - 3.15f) / 0.17f) * PI.toFloat()).coerceIn(0f, 1f)
        } else 0f

        if (!isDancing) {
            val idleWave = sin(timeSeconds * 2.2f)
            val breath = sin(timeSeconds * 3.1f)
            return CharacterPose(
                hipOffsetX = 0f,
                hipOffsetY = breath * 3.5f,
                squashX = 1f + breath * 0.015f,
                squashY = 1f - breath * 0.015f,
                torsoLeanDeg = idleWave * 3f,
                bodyTurn = idleWave * 0.15f,
                headBobY = breath * 2f,
                headTiltDeg = sin(timeSeconds * 1.6f) * 5f,
                headNod = 0f,
                leftShoulderDeg = 24f + idleWave * 6f,
                leftElbowDeg = 22f + breath * 5f,
                rightShoulderDeg = -24f + idleWave * 6f,
                rightElbowDeg = -22f - breath * 5f,
                leftHipDeg = 10f,
                leftKneeDeg = -8f,
                rightHipDeg = -10f,
                rightKneeDeg = 8f,
                tailSwingDeg = sin(timeSeconds * 4.5f) * 20f,
                earBounceDeg = breath * 5f,
                trunkCurl = idleWave * 0.25f,
                blinkAmount = blink,
                mouthOpen = 0.2f,
                stepName = "Ready to Dance!"
            )
        }

        val beat = timeSeconds * (bpm / 60f)
        val beatRad = beat * 2f * PI.toFloat()
        val halfBeatRad = beat * PI.toFloat()
        val beatBounce = abs(sin(beatRad * 0.5f)) // 1 bounce per beat

        return when (dance) {
            DanceStyle.DJ_DANCE -> computeDjDance(beat, beatRad, halfBeatRad, beatBounce, blink)
            DanceStyle.HIP_HOP -> computeHipHopDance(beat, beatRad, halfBeatRad, beatBounce, blink)
            DanceStyle.GAON_WALA -> computeGaonWalaDance(beat, beatRad, halfBeatRad, beatBounce, blink)
            DanceStyle.FUNNY_DANCE -> computeFunnyDance(beat, beatRad, halfBeatRad, beatBounce, blink)
        }
    }

    private fun computeDjDance(
        beat: Float,
        beatRad: Float,
        halfBeatRad: Float,
        beatBounce: Float,
        blink: Float
    ): CharacterPose {
        val barIndex = (beat / 4f).toInt() % 4
        val barProgress = (beat % 4f) / 4f
        val groove = sin(halfBeatRad)
        val scratchFast = sin(beatRad * 2f)

        val basePose = when (barIndex) {
            0 -> CharacterPose(
                // Step 1: DJ Turntable Scratch + Headphone Hand
                hipOffsetX = groove * 12f,
                hipOffsetY = beatBounce * 12f,
                squashX = 1f + beatBounce * 0.05f,
                squashY = 1f - beatBounce * 0.05f,
                torsoLeanDeg = 6f + groove * 6f,
                bodyTurn = -0.25f + groove * 0.15f,
                headBobY = beatBounce * 8f,
                headTiltDeg = -8f + sin(beatRad) * 8f,
                headNod = sin(beatRad) * 0.65f,
                leftShoulderDeg = 42f + scratchFast * 16f,
                leftElbowDeg = 72f + scratchFast * 22f,
                rightShoulderDeg = -118f,
                rightElbowDeg = -88f,
                leftHipDeg = 22f + beatBounce * 8f,
                leftKneeDeg = -24f - beatBounce * 10f,
                rightHipDeg = -18f,
                rightKneeDeg = 16f,
                tailSwingDeg = sin(beatRad) * 28f,
                earBounceDeg = beatBounce * 12f,
                trunkCurl = 0.5f + scratchFast * 0.35f,
                stepName = "DJ Deck Scratch"
            )
            1 -> CharacterPose(
                // Step 2: Both Hands Up Disco Pump + Alternating Knee Hops
                hipOffsetX = groove * 16f,
                hipOffsetY = -abs(sin(beatRad)) * 22f + 4f,
                squashX = 1f - abs(sin(beatRad)) * 0.04f,
                squashY = 1f + abs(sin(beatRad)) * 0.05f,
                torsoLeanDeg = groove * 8f,
                bodyTurn = groove * 0.25f,
                headBobY = -abs(sin(beatRad)) * 5f,
                headTiltDeg = groove * 10f,
                headNod = cos(beatRad) * 0.45f,
                leftShoulderDeg = 132f + sin(beatRad) * 24f,
                leftElbowDeg = -28f - cos(beatRad) * 18f,
                rightShoulderDeg = -132f + sin(beatRad) * 24f,
                rightElbowDeg = 28f - cos(beatRad) * 18f,
                leftHipDeg = if (groove > 0) 56f * groove + 12f else 12f,
                leftKneeDeg = if (groove > 0) -66f * groove - 10f else -10f,
                rightHipDeg = if (groove < 0) 56f * groove - 12f else -12f,
                rightKneeDeg = if (groove < 0) -66f * groove + 10f else 10f,
                tailSwingDeg = sin(beatRad * 1.5f) * 35f,
                earBounceDeg = abs(sin(beatRad)) * 16f,
                trunkCurl = 0.85f * sin(beatRad * 0.5f),
                stepName = "DJ Hands Up!"
            )
            2 -> {
                // Step 3: Disco Saturday Night Fever Diagonal Point (switches half-bar)
                val dir = if (barProgress < 0.5f) 1f else -1f
                CharacterPose(
                    hipOffsetX = dir * 20f + groove * 8f,
                    hipOffsetY = beatBounce * 14f,
                    squashX = 1f + beatBounce * 0.04f,
                    squashY = 1f - beatBounce * 0.04f,
                    torsoLeanDeg = -dir * 12f,
                    bodyTurn = dir * 0.32f,
                    headBobY = beatBounce * 6f,
                    headTiltDeg = dir * 10f,
                    headNod = sin(beatRad) * 0.5f,
                    leftShoulderDeg = if (dir > 0) 144f + sin(beatRad) * 14f else 28f,
                    leftElbowDeg = if (dir > 0) 8f else 35f,
                    rightShoulderDeg = if (dir < 0) -144f - sin(beatRad) * 14f else -28f,
                    rightElbowDeg = if (dir < 0) -8f else -35f,
                    leftHipDeg = 26f + dir * 10f,
                    leftKneeDeg = -22f,
                    rightHipDeg = -26f + dir * 10f,
                    rightKneeDeg = 22f,
                    tailSwingDeg = -dir * 32f + sin(beatRad) * 15f,
                    earBounceDeg = beatBounce * 10f,
                    trunkCurl = dir * 0.7f,
                    stepName = "Disco Point"
                )
            }
            else -> CharacterPose(
                // Step 4: Fist Pump Bounce
                hipOffsetX = groove * 14f,
                hipOffsetY = beatBounce * 16f - 6f,
                squashX = 1f + beatBounce * 0.06f,
                squashY = 1f - beatBounce * 0.05f,
                torsoLeanDeg = groove * 10f,
                bodyTurn = groove * 0.28f,
                headBobY = beatBounce * 7f,
                headTiltDeg = sin(beatRad) * 9f,
                headNod = sin(beatRad) * 0.6f,
                leftShoulderDeg = 102f + sin(beatRad) * 28f,
                leftElbowDeg = 55f,
                rightShoulderDeg = -102f - sin(beatRad) * 28f,
                rightElbowDeg = -55f,
                leftHipDeg = 28f,
                leftKneeDeg = -32f * beatBounce - 8f,
                rightHipDeg = -28f,
                rightKneeDeg = 32f * beatBounce + 8f,
                tailSwingDeg = sin(beatRad * 2f) * 32f,
                earBounceDeg = beatBounce * 14f,
                trunkCurl = 0.6f * cos(beatRad),
                stepName = "Party Fist Pump"
            )
        }
        return basePose.copy(blinkAmount = blink, mouthOpen = 0.5f + 0.4f * beatBounce)
    }

    private fun computeHipHopDance(
        beat: Float,
        beatRad: Float,
        halfBeatRad: Float,
        beatBounce: Float,
        blink: Float
    ): CharacterPose {
        val barIndex = (beat / 4f).toInt() % 4
        val barProgress = (beat % 4f) / 4f
        val groove = sin(halfBeatRad)
        val snap = sin(beatRad)

        val basePose = when (barIndex) {
            0 -> CharacterPose(
                // Step 1: Deep Squat Hip-Hop Groove & Chest Pump
                hipOffsetX = groove * 22f,
                hipOffsetY = 12f + beatBounce * 14f,
                squashX = 1f + beatBounce * 0.06f,
                squashY = 1f - beatBounce * 0.05f,
                torsoLeanDeg = groove * 12f,
                bodyTurn = groove * 0.30f,
                headBobY = beatBounce * 9f,
                headTiltDeg = -groove * 10f,
                headNod = snap * 0.75f,
                leftShoulderDeg = 56f + snap * 28f,
                leftElbowDeg = 82f + snap * 18f,
                rightShoulderDeg = -56f + snap * 28f,
                rightElbowDeg = -82f + snap * 18f,
                leftHipDeg = 32f + groove * 8f,
                leftKneeDeg = -34f - beatBounce * 12f,
                rightHipDeg = -32f + groove * 8f,
                rightKneeDeg = 34f + beatBounce * 12f,
                tailSwingDeg = groove * 30f,
                earBounceDeg = beatBounce * 12f,
                trunkCurl = groove * 0.6f,
                stepName = "Hip-Hop Groove"
            )
            1 -> {
                // Step 2: The Dab Swag Pose (switches side cleanly)
                val dir = if (barProgress < 0.5f) 1f else -1f
                val dabEase = sin((barProgress * 2f % 1f) * PI.toFloat()).coerceIn(0.35f, 1f)
                CharacterPose(
                    hipOffsetX = dir * 18f * dabEase,
                    hipOffsetY = 14f * dabEase,
                    squashX = 1.04f,
                    squashY = 0.96f,
                    torsoLeanDeg = -dir * 16f * dabEase,
                    bodyTurn = dir * 0.35f,
                    headBobY = 8f * dabEase,
                    headTiltDeg = dir * 18f * dabEase,
                    headNod = 0.8f * dabEase,
                    leftShoulderDeg = if (dir > 0) 128f * dabEase else 88f * dabEase,
                    leftElbowDeg = if (dir > 0) -6f else 108f * dabEase,
                    rightShoulderDeg = if (dir < 0) -128f * dabEase else -88f * dabEase,
                    rightElbowDeg = if (dir < 0) 6f else -108f * dabEase,
                    leftHipDeg = 30f,
                    leftKneeDeg = -30f,
                    rightHipDeg = -30f,
                    rightKneeDeg = 30f,
                    tailSwingDeg = -dir * 35f,
                    earBounceDeg = 10f * dabEase,
                    trunkCurl = dir * 0.8f,
                    stepName = "Hip-Hop Dab!"
                )
            }
            2 -> {
                // Step 3: Pop & Lock Crisp Robot Isolation
                val tick = (beat * 2f).toInt() % 4
                val armPose = when (tick) {
                    0 -> floatArrayOf(88f, 92f, -32f, -92f)
                    1 -> floatArrayOf(32f, 92f, -88f, -92f)
                    2 -> floatArrayOf(125f, 82f, -125f, -82f)
                    else -> floatArrayOf(65f, -80f, -65f, 80f)
                }
                CharacterPose(
                    hipOffsetX = if (tick % 2 == 0) -14f else 14f,
                    hipOffsetY = if (tick % 2 == 0) 8f else 0f,
                    squashX = 1f,
                    squashY = 1f,
                    torsoLeanDeg = if (tick % 2 == 0) -8f else 8f,
                    bodyTurn = if (tick % 2 == 0) -0.22f else 0.22f,
                    headBobY = if (tick % 2 == 0) 4f else 0f,
                    headTiltDeg = if (tick == 2) 10f else -8f,
                    headNod = if (tick % 2 == 1) 0.5f else -0.2f,
                    leftShoulderDeg = armPose[0],
                    leftElbowDeg = armPose[1],
                    rightShoulderDeg = armPose[2],
                    rightElbowDeg = armPose[3],
                    leftHipDeg = if (tick == 0) 42f else 20f,
                    leftKneeDeg = if (tick == 0) -48f else -18f,
                    rightHipDeg = if (tick == 2) -42f else -20f,
                    rightKneeDeg = if (tick == 2) 48f else 18f,
                    tailSwingDeg = (tick - 1.5f) * 18f,
                    earBounceDeg = 6f,
                    trunkCurl = if (tick % 2 == 0) 0.5f else -0.5f,
                    stepName = "Pop & Lock"
                )
            }
            else -> CharacterPose(
                // Step 4: Moonwalk / Side Glide + Cross Step
                hipOffsetX = sin(halfBeatRad) * 42f,
                hipOffsetY = -abs(sin(beatRad)) * 12f + 6f,
                squashX = 1f,
                squashY = 1f,
                torsoLeanDeg = -cos(halfBeatRad) * 14f,
                bodyTurn = cos(halfBeatRad) * 0.42f,
                headBobY = beatBounce * 5f,
                headTiltDeg = cos(halfBeatRad) * 8f,
                headNod = snap * 0.4f,
                leftShoulderDeg = 46f + groove * 55f,
                leftElbowDeg = 54f,
                rightShoulderDeg = -46f + groove * 55f,
                rightElbowDeg = -54f,
                leftHipDeg = 22f + groove * 34f,
                leftKneeDeg = -18f - abs(groove) * 32f,
                rightHipDeg = -22f + groove * 34f,
                rightKneeDeg = 18f + abs(groove) * 32f,
                tailSwingDeg = -groove * 34f,
                earBounceDeg = beatBounce * 10f,
                trunkCurl = groove * 0.7f,
                stepName = "Side Glide Shuffle"
            )
        }
        return basePose.copy(blinkAmount = blink, mouthOpen = 0.35f + 0.3f * beatBounce)
    }

    private fun computeGaonWalaDance(
        beat: Float,
        beatRad: Float,
        halfBeatRad: Float,
        beatBounce: Float,
        blink: Float
    ): CharacterPose {
        val barIndex = (beat / 4f).toInt() % 3
        val groove = sin(halfBeatRad)
        val hop = abs(sin(beatRad))

        val basePose = when (barIndex) {
            0 -> CharacterPose(
                // Step 1: Classic Bhangra Arms Up + High Knee Hop
                hipOffsetX = groove * 16f,
                hipOffsetY = -hop * 28f + 4f,
                squashX = 1f - hop * 0.06f,
                squashY = 1f + hop * 0.08f,
                torsoLeanDeg = groove * 10f,
                bodyTurn = groove * 0.2f,
                headBobY = -hop * 6f,
                headTiltDeg = sin(beatRad) * 12f,
                headNod = cos(beatRad) * 0.5f,
                leftShoulderDeg = 128f + sin(beatRad) * 16f,
                leftElbowDeg = 32f + cos(beatRad) * 14f,
                rightShoulderDeg = -128f - sin(beatRad) * 16f,
                rightElbowDeg = -32f - cos(beatRad) * 14f,
                leftHipDeg = if (groove >= 0) 68f * groove + 12f else 12f,
                leftKneeDeg = if (groove >= 0) -76f * groove - 10f else -10f,
                rightHipDeg = if (groove < 0) 68f * groove - 12f else -12f,
                rightKneeDeg = if (groove < 0) -76f * groove + 10f else 10f,
                tailSwingDeg = sin(beatRad * 1.5f) * 35f,
                earBounceDeg = hop * 18f,
                trunkCurl = 0.85f,
                stepName = "Bhangra Hop!"
            )
            1 -> CharacterPose(
                // Step 2: Desi Shoulder Shake + Dhol Clap
                hipOffsetX = groove * 12f,
                hipOffsetY = beatBounce * 14f - 4f,
                squashX = 1f + beatBounce * 0.05f,
                squashY = 1f - beatBounce * 0.04f,
                torsoLeanDeg = sin(beatRad * 2f) * 8f,
                bodyTurn = groove * 0.25f,
                headBobY = sin(beatRad * 2f) * 5f,
                headTiltDeg = sin(beatRad) * 11f,
                headNod = sin(beatRad * 2f) * 0.5f,
                leftShoulderDeg = 52f + abs(sin(beatRad)) * 22f,
                leftElbowDeg = 88f - abs(sin(beatRad)) * 26f,
                rightShoulderDeg = -52f - abs(sin(beatRad)) * 22f,
                rightElbowDeg = -88f + abs(sin(beatRad)) * 26f,
                leftHipDeg = 28f,
                leftKneeDeg = -28f,
                rightHipDeg = -28f,
                rightKneeDeg = 28f,
                tailSwingDeg = sin(beatRad * 2f) * 32f,
                earBounceDeg = abs(sin(beatRad * 2f)) * 15f,
                trunkCurl = sin(beatRad) * 0.6f,
                stepName = "Dhol Shoulder Shake"
            )
            else -> CharacterPose(
                // Step 3: Jumping Jack Joy!
                hipOffsetX = 0f,
                hipOffsetY = -hop * 32f + 6f,
                squashX = 1f - hop * 0.07f,
                squashY = 1f + hop * 0.09f,
                torsoLeanDeg = sin(halfBeatRad) * 8f,
                bodyTurn = 0f,
                headBobY = -hop * 6f,
                headTiltDeg = sin(halfBeatRad) * 10f,
                headNod = 0f,
                leftShoulderDeg = 40f + hop * 112f,
                leftElbowDeg = 18f,
                rightShoulderDeg = -40f - hop * 112f,
                rightElbowDeg = -18f,
                leftHipDeg = 12f + hop * 36f,
                leftKneeDeg = -10f - hop * 24f,
                rightHipDeg = -12f - hop * 36f,
                rightKneeDeg = 10f + hop * 24f,
                tailSwingDeg = sin(beatRad * 2f) * 38f,
                earBounceDeg = hop * 20f,
                trunkCurl = hop * 0.9f,
                stepName = "Gaon Jumping Joy"
            )
        }
        return basePose.copy(blinkAmount = blink, mouthOpen = 0.6f + 0.35f * hop)
    }

    private fun computeFunnyDance(
        beat: Float,
        beatRad: Float,
        halfBeatRad: Float,
        beatBounce: Float,
        blink: Float
    ): CharacterPose {
        val barIndex = (beat / 4f).toInt() % 3
        val groove = sin(halfBeatRad)
        val flap = sin(beatRad * 2f)

        val basePose = when (barIndex) {
            0 -> CharacterPose(
                // Step 1: Chicken Wing Flap + Waddle
                hipOffsetX = groove * 18f,
                hipOffsetY = -abs(flap) * 12f + 6f,
                squashX = 1f + flap * 0.07f,
                squashY = 1f - flap * 0.06f,
                torsoLeanDeg = groove * 14f,
                bodyTurn = groove * 0.28f,
                headBobY = flap * 7f,
                headTiltDeg = groove * 18f,
                headNod = flap * 0.8f,
                leftShoulderDeg = 86f + flap * 36f,
                leftElbowDeg = 112f,
                rightShoulderDeg = -86f - flap * 36f,
                rightElbowDeg = -112f,
                leftHipDeg = 22f + abs(groove) * 28f,
                leftKneeDeg = -28f,
                rightHipDeg = -22f - abs(groove) * 28f,
                rightKneeDeg = 28f,
                tailSwingDeg = flap * 42f,
                earBounceDeg = flap * 24f,
                trunkCurl = flap * 0.9f,
                stepName = "Funny Chicken Flap"
            )
            1 -> CharacterPose(
                // Step 2: Wobbly Jelly Noodle Arms & Silly Kicks
                hipOffsetX = sin(beatRad) * 26f,
                hipOffsetY = beatBounce * 10f,
                squashX = 1f + sin(beatRad * 2f) * 0.10f,
                squashY = 1f - sin(beatRad * 2f) * 0.09f,
                torsoLeanDeg = sin(beatRad) * 18f,
                bodyTurn = sin(halfBeatRad) * 0.45f,
                headBobY = cos(beatRad) * 7f,
                headTiltDeg = -sin(beatRad) * 20f,
                headNod = cos(beatRad) * 0.6f,
                leftShoulderDeg = 95f + sin(beatRad) * 45f,
                leftElbowDeg = cos(beatRad) * 65f,
                rightShoulderDeg = -95f + sin(beatRad) * 45f,
                rightElbowDeg = -cos(beatRad) * 65f,
                leftHipDeg = 16f + maxOf(0f, sin(beatRad)) * 58f,
                leftKneeDeg = -14f - maxOf(0f, sin(beatRad)) * 24f,
                rightHipDeg = -16f - maxOf(0f, -sin(beatRad)) * 58f,
                rightKneeDeg = 14f + maxOf(0f, -sin(beatRad)) * 24f,
                tailSwingDeg = sin(beatRad * 2f) * 45f,
                earBounceDeg = abs(sin(beatRad)) * 22f,
                trunkCurl = sin(beatRad) * 1.0f,
                stepName = "Jelly Wobble"
            )
            else -> CharacterPose(
                // Step 3: Silly Airplane Spin Jump
                hipOffsetX = groove * 24f,
                hipOffsetY = -abs(sin(beatRad)) * 30f + 4f,
                squashX = 1f - abs(sin(beatRad)) * 0.06f,
                squashY = 1f + abs(sin(beatRad)) * 0.08f,
                torsoLeanDeg = groove * 16f,
                bodyTurn = sin(halfBeatRad) * 0.55f,
                headBobY = -abs(sin(beatRad)) * 6f,
                headTiltDeg = groove * 15f,
                headNod = sin(beatRad) * 0.5f,
                leftShoulderDeg = 96f + flap * 18f,
                leftElbowDeg = 14f,
                rightShoulderDeg = -96f - flap * 18f,
                rightElbowDeg = -14f,
                leftHipDeg = 35f,
                leftKneeDeg = -55f * abs(sin(beatRad)) - 15f,
                rightHipDeg = -35f,
                rightKneeDeg = 55f * abs(sin(beatRad)) + 15f,
                tailSwingDeg = flap * 40f,
                earBounceDeg = abs(sin(beatRad)) * 22f,
                trunkCurl = cos(beatRad) * 0.8f,
                stepName = "Masti Airplane Hop"
            )
        }
        return basePose.copy(blinkAmount = blink, mouthOpen = 0.7f + 0.25f * abs(flap))
    }
}
