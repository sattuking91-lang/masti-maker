package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.WorkspacePremium
import com.example.R
import com.example.model.CreatedVideo
import com.example.ui.GenerationState
import com.example.ui.MastiMakerUiState
import com.example.ui.components.DancingAnimalStage3D
import com.example.ui.components.PostVideoAdCard
import com.example.ui.components.ShareDownloadSection
import com.example.ui.components.VideoPlayerCard
import com.example.ui.theme.CandyOrange
import com.example.ui.theme.CandyPink
import com.example.ui.theme.CandyPurple
import com.example.ui.theme.CandyYellow

@Composable
fun DanceStageScreen(
    uiState: MastiMakerUiState,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onDismissAd: () -> Unit,
    onOpenPro: () -> Unit,
    onDownload: (CreatedVideo) -> Unit,
    onShare: (CreatedVideo, String?, String) -> Unit,
    onMakeAnother: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Bar with Back Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("stage_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = when (uiState.generationState) {
                        is GenerationState.Completed -> stringResource(R.string.video_ready_title)
                        is GenerationState.Error -> "Oops!"
                        else -> if (uiState.isGeneratingStory) {
                            stringResource(R.string.creating_story_title)
                        } else {
                            stringResource(R.string.creating_title)
                        }
                    },
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
            }

            when (val gen = uiState.generationState) {
                is GenerationState.Idle,
                is GenerationState.Generating -> {
                    val progress = (gen as? GenerationState.Generating)?.progress ?: 0.05f
                    val statusText = (gen as? GenerationState.Generating)?.statusText
                        ?: "Janwar dance kar raha hai..."
                    val animatedProgress by animateFloatAsState(
                        targetValue = progress.coerceIn(0f, 1f),
                        label = "gen_progress"
                    )

                    // Live 3D Animated Dancing Animal Stage!
                    DancingAnimalStage3D(
                        animal = uiState.selectedAnimal,
                        dance = uiState.selectedDance,
                        isDancing = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(350.dp)
                            .testTag("live_3d_dance_stage")
                    )

                    // Progress Card Below ("Neeche Progress dikhe")
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(26.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        CandyPurple.copy(alpha = 0.14f),
                                        CandyPink.copy(alpha = 0.14f)
                                    )
                                )
                            )
                            .border(2.dp, CandyPink.copy(alpha = 0.45f), RoundedCornerShape(26.dp))
                            .padding(18.dp)
                            .testTag("generation_progress_card")
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = CandyOrange
                                ) {
                                    Text(
                                        text = "${(animatedProgress * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(18.dp)
                                    .clip(CircleShape)
                                    .testTag("generation_progress_bar"),
                                color = CandyPink,
                                trackColor = Color.White,
                                strokeCap = StrokeCap.Round
                            )

                            Text(
                                text = if (uiState.isGeneratingStory) {
                                    "${stringResource(uiState.storyAnimal.labelRes)} • Kahani • ${uiState.storyDuration.seconds / 60} Minute"
                                } else {
                                    "${stringResource(uiState.selectedAnimal.labelRes)} • " +
                                        "${stringResource(uiState.selectedDance.labelRes)} • " +
                                        "${uiState.selectedDuration.seconds}s • " +
                                        stringResource(uiState.selectedSong.labelRes)
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onBack,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("cancel_generation_button"),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = "Cancel",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                is GenerationState.Completed -> {
                    val video = gen.video

                    if (uiState.showPostVideoAd) {
                        PostVideoAdCard(
                            onSkipAd = onDismissAd,
                            onUpgradePro = onOpenPro
                        )
                    } else {
                        // Celebration Banner
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(22.dp))
                                .background(
                                    Brush.horizontalGradient(listOf(CandyOrange, CandyPink))
                                )
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Celebration,
                                contentDescription = null,
                                tint = CandyYellow,
                                modifier = Modifier.size(28.dp)
                            )
                            Text(
                                text = if (video.isStory) {
                                    "${stringResource(video.animal.labelRes)} Ki Kahani Video Ready!"
                                } else {
                                    "${stringResource(video.animal.labelRes)} ka ${stringResource(video.dance.labelRes)} Video Ready!"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Video Player
                        VideoPlayerCard(
                            videoPath = video.filePath,
                            aspectRatio = video.aspectRatioFloat,
                            modifier = Modifier.testTag("generated_video_player")
                        )

                        // Watermark removal prompt if video has Masti Maker watermark
                        if (video.hasWatermark && !uiState.isPro) {
                            Surface(
                                onClick = onOpenPro,
                                shape = RoundedCornerShape(18.dp),
                                color = CandyYellow.copy(alpha = 0.25f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.5.dp, CandyOrange, RoundedCornerShape(18.dp))
                                    .testTag("remove_watermark_pro_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.WorkspacePremium,
                                        contentDescription = null,
                                        tint = CandyOrange
                                    )
                                    Text(
                                        text = stringResource(R.string.pro_free_note),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Download + Share (WhatsApp, YouTube, Instagram)
                        ShareDownloadSection(
                            video = video,
                            onDownload = { onDownload(video) },
                            onShare = { pkg, label -> onShare(video, pkg, label) }
                        )

                        // Make Another Video Button
                        Button(
                            onClick = onMakeAnother,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(58.dp)
                                .testTag("make_another_button"),
                            shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CandyOrange,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.btn_make_another),
                                style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                is GenerationState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.errorContainer)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = gen.message,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Button(onClick = onRetry) {
                                Text("Dobara Try Karo")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
