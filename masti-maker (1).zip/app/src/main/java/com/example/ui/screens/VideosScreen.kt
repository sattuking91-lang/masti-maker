package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.CreatedVideo
import com.example.ui.components.ShareDownloadSection
import com.example.ui.components.VideoPlayerCard
import com.example.ui.theme.CandyOrange
import com.example.ui.theme.CandyPink
import com.example.ui.theme.CandyPurple
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VideosScreen(
    videos: List<CreatedVideo>,
    onGoToStudio: () -> Unit,
    onDownload: (CreatedVideo) -> Unit,
    onShare: (CreatedVideo, String?, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeVideo by remember { mutableStateOf<CreatedVideo?>(null) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        if (videos.isEmpty()) {
            Column(
                modifier = Modifier
                    .widthIn(max = 500.dp)
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = CircleShape,
                    color = CandyPurple.copy(alpha = 0.14f),
                    modifier = Modifier.size(110.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.VideoLibrary,
                            contentDescription = null,
                            tint = CandyPurple,
                            modifier = Modifier.size(56.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = stringResource(R.string.empty_videos_title),
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.empty_videos_desc),
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(22.dp))
                Button(
                    onClick = onGoToStudio,
                    modifier = Modifier
                        .height(58.dp)
                        .testTag("empty_videos_create_button"),
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CandyOrange,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Filled.MovieCreation,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.home_option_banao_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 620.dp)
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = stringResource(R.string.nav_videos),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(videos, key = { it.id }) { video ->
                    SavedVideoItemCard(
                        video = video,
                        onPlayClick = { activeVideo = video }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }

    activeVideo?.let { video ->
        val updatedVideo = videos.firstOrNull { it.id == video.id } ?: video
        Dialog(
            onDismissRequest = { activeVideo = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(30.dp),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val dialogTypeLabel = when {
                            updatedVideo.isAiGenerated -> "AI Video (${updatedVideo.aspectRatio})"
                            updatedVideo.isStory -> "Kahani"
                            else -> stringResource(updatedVideo.dance.labelRes)
                        }
                        Text(
                            text = "${stringResource(updatedVideo.animal.labelRes)} • $dialogTypeLabel",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(
                            onClick = { activeVideo = null },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close player"
                            )
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        VideoPlayerCard(
                            videoPath = updatedVideo.filePath,
                            aspectRatio = updatedVideo.aspectRatioFloat
                        )
                    }

                    ShareDownloadSection(
                        video = updatedVideo,
                        onDownload = { onDownload(updatedVideo) },
                        onShare = { pkg, label -> onShare(updatedVideo, pkg, label) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedVideoItemCard(
    video: CreatedVideo,
    onPlayClick: () -> Unit
) {
    val accent = Color(video.animal.accentHex)
    val dateLabel = remember(video.createdAtMillis) {
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(video.createdAtMillis))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(Color(video.animal.cardBgHex))
            .border(2.5.dp, Color.White, RoundedCornerShape(24.dp))
            .clickable(onClick = onPlayClick)
            .testTag("saved_video_card_${video.id}")
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = video.animal.imageRes),
            contentDescription = stringResource(video.animal.labelRes),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(78.dp)
                .clip(RoundedCornerShape(18.dp))
                .border(2.dp, Color.White, RoundedCornerShape(18.dp))
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            val typeLabel = when {
                video.isAiGenerated -> "AI Video"
                video.isStory -> "Kahani"
                else -> stringResource(video.dance.labelRes)
            }
            Text(
                text = "${stringResource(video.animal.labelRes)} • $typeLabel",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF1F1A38),
                fontWeight = FontWeight.Bold
            )
            Text(
                text = when {
                    video.isAiGenerated -> "${video.durationSeconds}s • ${video.aspectRatio} • ${video.resolution}"
                    video.isStory -> "${video.durationSeconds / 60} Minute Kahani"
                    else -> "${video.durationSeconds}s • ${stringResource(video.song.labelRes)}"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF473F6B)
            )
            Text(
                text = dateLabel,
                style = MaterialTheme.typography.labelMedium,
                color = accent
            )
        }

        Surface(
            shape = CircleShape,
            color = CandyPink
        ) {
            IconButton(
                onClick = onPlayClick,
                modifier = Modifier.size(50.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Watch video",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}
