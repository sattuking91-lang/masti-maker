package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.animation.DanceChoreography
import com.example.model.AnimalType
import com.example.model.DanceStyle
import com.example.video.AnimalCharacterCanvasDrawer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun DancingAnimalStage3D(
    animal: AnimalType,
    dance: DanceStyle,
    isDancing: Boolean,
    modifier: Modifier = Modifier
) {
    var timeSeconds by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(dance, isDancing) {
        val startNanos = withFrameNanos { it }
        while (true) {
            withFrameNanos { frameNanos ->
                timeSeconds = (frameNanos - startNanos) / 1_000_000_000f
            }
        }
    }

    val pose = DanceChoreography.computePose(
        dance = dance,
        timeSeconds = timeSeconds,
        bpm = dance.bpm,
        isDancing = isDancing
    )

    val primaryColor = Color(dance.primaryHex)
    val secondaryColor = Color(dance.secondaryHex)
    val phase = timeSeconds * (dance.bpm / 60f) * PI.toFloat()
    val confettiPalette = listOf(
        Color(0xFFFF6B35),
        Color(0xFFFF3E8A),
        Color(0xFF00E5FF),
        Color(0xFFFFD13B),
        Color(0xFF4CD964),
        Color(0xFFB388FF)
    )

    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.92f),
                        Color(0xFF23154F),
                        secondaryColor.copy(alpha = 0.85f)
                    )
                )
            )
            .border(3.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(28.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val sweep = sin(phase * 0.8f) * w * 0.22f

            // Spotlight beams
            val beam1 = Path().apply {
                moveTo(w * 0.22f, 0f)
                lineTo(w * 0.30f, 0f)
                lineTo(w * 0.65f + sweep, h * 0.88f)
                lineTo(w * 0.35f + sweep, h * 0.88f)
                close()
            }
            drawPath(
                path = beam1,
                brush = Brush.verticalGradient(
                    colors = listOf(Color.White.copy(alpha = 0.32f), Color.Transparent)
                )
            )

            val beam2 = Path().apply {
                moveTo(w * 0.70f, 0f)
                lineTo(w * 0.78f, 0f)
                lineTo(w * 0.65f - sweep, h * 0.88f)
                lineTo(w * 0.35f - sweep, h * 0.88f)
                close()
            }
            drawPath(
                path = beam2,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFFEA70).copy(alpha = 0.28f), Color.Transparent)
                )
            )

            // Beat equalizer bars in background when dancing
            if (isDancing) {
                val bars = 9
                val barW = w / (bars * 1.6f)
                val startX = (w - bars * barW * 1.35f) / 2f
                val floorTop = h * 0.78f
                for (i in 0 until bars) {
                    val mag = abs(sin(phase * 1.4f + i * 0.7f))
                    val barH = 18f + mag * (h * 0.24f)
                    drawRoundRect(
                        color = confettiPalette[i % confettiPalette.size].copy(alpha = 0.22f),
                        topLeft = Offset(startX + i * barW * 1.35f, floorTop - barH),
                        size = Size(barW, barH),
                        cornerRadius = CornerRadius(8f, 8f)
                    )
                }
            }

            // Glowing stage floor
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(
                        secondaryColor.copy(alpha = 0.7f),
                        primaryColor.copy(alpha = 0.5f),
                        Color.Transparent
                    ),
                    center = Offset(w / 2f, h * 0.86f),
                    radius = w * 0.55f
                ),
                topLeft = Offset(w * 0.05f, h * 0.72f),
                size = Size(w * 0.9f, h * 0.32f)
            )

            // Articulated full-body 3D dancing animal!
            drawIntoCanvas { canvas ->
                AnimalCharacterCanvasDrawer.drawCharacter(
                    canvas = canvas.nativeCanvas,
                    animal = animal,
                    dance = dance,
                    pose = pose,
                    centerX = w / 2f,
                    groundY = h * 0.83f,
                    characterHeight = minOf(w, h) * 0.68f,
                    isDancing = isDancing
                )
            }

            // Confetti particles when dancing
            if (isDancing) {
                val spin = (timeSeconds * 160f) % 360f
                for (i in 0 until 12) {
                    val cx = ((i * 89f + sin(phase + i) * 40f) % w + w) % w
                    val cy = ((i * 63f + (timeSeconds * 0.45f) * h) % h)
                    val pColor = confettiPalette[i % confettiPalette.size]
                    rotate(degrees = spin + i * 30f, pivot = Offset(cx, cy)) {
                        drawCircle(color = pColor, radius = 6.5f, center = Offset(cx, cy))
                    }
                }
            }
        }

        // Top Stage Tag Pill
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp),
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f)
        ) {
            Text(
                text = "${stringResource(animal.labelRes)} • ${stringResource(dance.labelRes)}",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        // Live Step & Sound Bubble when dancing
        if (isDancing) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .offset(y = (-abs(sin(phase)) * 5).dp),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFFFD13B)
            ) {
                Text(
                    text = "${animal.funSound} • ${pose.stepName}",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFF1F1A38),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}
