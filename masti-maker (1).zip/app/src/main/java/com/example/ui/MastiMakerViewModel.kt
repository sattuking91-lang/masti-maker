package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AnimalSpeechSynthesizer
import com.example.audio.AnimalVoiceSynthesizer
import com.example.audio.AudioPreviewPlayer
import com.example.audio.VoiceRecorder
import com.example.model.AiGenerationPhase
import com.example.model.AnimalType
import com.example.model.CreatedVideo
import com.example.model.DanceDuration
import com.example.model.DanceStyle
import com.example.model.OWNER_DEFAULT_NAME
import com.example.model.OWNER_EMAIL
import com.example.model.SongTrack
import com.example.model.StoryDuration
import com.example.model.UserProfile
import com.example.model.VeoDuration
import com.example.model.VeoModel
import com.example.model.VeoResolution
import com.example.model.VideoAspectRatio
import com.example.model.VoiceMode
import com.example.model.normalizeVeoConfig
import com.example.video.VeoApiException
import com.example.video.VeoBackendClient
import com.example.video.VideoGenerator
import com.example.video.VideoShareHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface GenerationState {
    data object Idle : GenerationState
    data class Generating(val progress: Float, val statusText: String) : GenerationState
    data class Completed(val video: CreatedVideo) : GenerationState
    data class Error(val message: String) : GenerationState
}

data class MastiMakerUiState(
    val selectedAnimal: AnimalType = AnimalType.BILLI,
    val selectedDance: DanceStyle = DanceStyle.DJ_DANCE,
    val selectedDuration: DanceDuration = DanceDuration.SEC_10,
    val selectedSong: SongTrack = SongTrack.DJ_DHAMAKA,
    val previewingSong: SongTrack? = null,
    val generationState: GenerationState = GenerationState.Idle,
    val isGeneratingStory: Boolean = false,
    val activeStoryText: String = "",
    val storyAnimal: AnimalType = AnimalType.BILLI,
    val storyDuration: StoryDuration = StoryDuration.MIN_1,
    val soundGain: Float = 1.0f,
    val isPro: Boolean = false,
    val showPostVideoAd: Boolean = false,
    val selectedVoiceMode: VoiceMode = VoiceMode.JANWAR,
    val recordedVoicePath: String? = null,
    val recordedDurationSec: Int = 0,
    val isRecordingVoice: Boolean = false,
    val recordingAmplitude: Float = 0f,
    val isPreviewingVoice: Boolean = false,
    val userProfile: UserProfile = UserProfile(),
    val totalVideosCreated: Int = 0,
    val savedVideos: List<CreatedVideo> = emptyList(),
    val snackbarMessage: String? = null,
    val aiScript: String = "",
    val aiSelectedAnimals: List<AnimalType> = listOf(AnimalType.BILLI, AnimalType.KUTTA),
    val aiAspectRatio: VideoAspectRatio = VideoAspectRatio.PORTRAIT_9_16,
    val aiDuration: VeoDuration = VeoDuration.SEC_8,
    val aiResolution: VeoResolution = VeoResolution.RES_720P,
    val aiModel: VeoModel = VeoModel.VEO_3_1_FAST,
    val aiConfigNote: String? = null,
    val aiEnhancedPrompt: String = "",
    val aiPhase: AiGenerationPhase = AiGenerationPhase.Idle,
    val cloudRunBackendUrl: String = "",
    val isCheckingBackend: Boolean = false,
    val backendStatusMessage: String? = null,
    val showAiBillingDialog: Boolean = false
)

class MastiMakerViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val prefs = appContext.getSharedPreferences("masti_prefs", Context.MODE_PRIVATE)
    private val audioPlayer = AudioPreviewPlayer(viewModelScope)
    private val voiceRecorder = VoiceRecorder(appContext, viewModelScope)
    private val speechSynthesizer = AnimalSpeechSynthesizer(appContext)
    private var generationJob: Job? = null
    private var aiGenerationJob: Job? = null

    private val _uiState = MutableStateFlow(
        MastiMakerUiState(
            soundGain = prefs.getFloat("sound_gain", 1.0f).coerceIn(0.2f, 1.0f),
            isPro = prefs.getBoolean("is_pro", false),
            recordedVoicePath = voiceRecorder.getExistingRecording()?.absolutePath,
            recordedDurationSec = prefs.getInt("recorded_voice_sec", 0),
            userProfile = UserProfile(
                name = prefs.getString("user_name", "") ?: "",
                email = prefs.getString("user_email", "") ?: "",
                isLoggedIn = prefs.getBoolean("user_logged_in", false),
                isOwner = prefs.getBoolean("user_is_owner", false)
            ),
            totalVideosCreated = prefs.getInt("total_videos_created", 0),
            cloudRunBackendUrl = VeoBackendClient.normalizeBackendUrl(
                prefs.getString("cloud_run_backend_url", "") ?: ""
            )
        )
    )
    val uiState: StateFlow<MastiMakerUiState> = _uiState.asStateFlow()

    init {
        audioPlayer.setVolumeGain(_uiState.value.soundGain)
        refreshSavedVideos()
    }

    fun refreshSavedVideos() {
        val list = VideoGenerator.loadSavedVideos(appContext)
        val mergedTotal = maxOf(_uiState.value.totalVideosCreated, list.size)
        if (mergedTotal != _uiState.value.totalVideosCreated) {
            prefs.edit().putInt("total_videos_created", mergedTotal).apply()
        }
        _uiState.update { it.copy(savedVideos = list, totalVideosCreated = mergedTotal) }
    }

    fun loginWithEmail(name: String, email: String) {
        val cleanedName = name.trim().ifEmpty { "Masti Star" }
        val cleanedEmail = email.trim()
        val isOwner = cleanedEmail.equals(OWNER_EMAIL, ignoreCase = true)
        val profile = UserProfile(
            name = cleanedName,
            email = cleanedEmail,
            isLoggedIn = true,
            isOwner = isOwner
        )
        prefs.edit()
            .putBoolean("user_logged_in", true)
            .putString("user_name", profile.name)
            .putString("user_email", profile.email)
            .putBoolean("user_is_owner", profile.isOwner)
            .apply()
        _uiState.update {
            it.copy(
                userProfile = profile,
                snackbarMessage = if (isOwner) {
                    "Swagat hai Owner ${profile.name}!"
                } else {
                    "Swagat hai ${profile.name}! Login save ho gaya."
                }
            )
        }
    }

    fun enterOwnerMode() {
        val profile = UserProfile(
            name = OWNER_DEFAULT_NAME,
            email = OWNER_EMAIL,
            isLoggedIn = true,
            isOwner = true
        )
        prefs.edit()
            .putBoolean("user_logged_in", true)
            .putString("user_name", profile.name)
            .putString("user_email", profile.email)
            .putBoolean("user_is_owner", true)
            .apply()
        _uiState.update {
            it.copy(
                userProfile = profile,
                snackbarMessage = "Owner Mode Active — No Login!"
            )
        }
    }

    fun updateUserName(newName: String) {
        val cleaned = newName.trim()
        if (cleaned.isEmpty()) return
        prefs.edit().putString("user_name", cleaned).apply()
        _uiState.update { state ->
            state.copy(
                userProfile = state.userProfile.copy(name = cleaned),
                snackbarMessage = "Naam update ho gaya!"
            )
        }
    }

    fun logout() {
        stopAudio()
        prefs.edit()
            .putBoolean("user_logged_in", false)
            .putString("user_name", "")
            .putString("user_email", "")
            .putBoolean("user_is_owner", false)
            .apply()
        _uiState.update {
            it.copy(
                userProfile = UserProfile(),
                snackbarMessage = "Account logout ho gaya"
            )
        }
    }

    fun setSoundGain(gain: Float) {
        val clamped = gain.coerceIn(0.2f, 1.0f)
        prefs.edit().putFloat("sound_gain", clamped).apply()
        audioPlayer.setVolumeGain(clamped)
        _uiState.update { it.copy(soundGain = clamped) }
    }

    fun unlockPro() {
        prefs.edit().putBoolean("is_pro", true).apply()
        _uiState.update {
            it.copy(
                isPro = true,
                showPostVideoAd = false,
                snackbarMessage = "Pro Active! Ab bina 'Masti Maker' naam aur bina Ad ke video milega!"
            )
        }
    }

    fun resetToFreePlan() {
        prefs.edit().putBoolean("is_pro", false).apply()
        _uiState.update {
            it.copy(
                isPro = false,
                snackbarMessage = "Free Plan active: Video par watermark aur Ad dikhega"
            )
        }
    }

    fun dismissPostVideoAd() {
        _uiState.update { it.copy(showPostVideoAd = false) }
    }

    fun selectAnimal(animal: AnimalType) {
        _uiState.update { it.copy(selectedAnimal = animal) }
    }

    fun selectDance(dance: DanceStyle) {
        _uiState.update { it.copy(selectedDance = dance) }
    }

    fun selectDuration(duration: DanceDuration) {
        _uiState.update { it.copy(selectedDuration = duration) }
    }

    fun selectSong(song: SongTrack) {
        _uiState.update { it.copy(selectedSong = song) }
    }

    fun selectVoiceMode(mode: VoiceMode) {
        _uiState.update { it.copy(selectedVoiceMode = mode) }
    }

    fun previewVoice(
        mode: VoiceMode,
        animal: AnimalType = _uiState.value.selectedAnimal,
        storyText: String? = null
    ) {
        stopAudio()
        val gain = _uiState.value.soundGain
        when (mode) {
            VoiceMode.JANWAR -> {
                _uiState.update { it.copy(isPreviewingVoice = true) }
                val clip = AnimalVoiceSynthesizer.renderAnimalClip(animal, gain)
                audioPlayer.playPcmOnce(clip, gain) {
                    _uiState.update { it.copy(isPreviewingVoice = false) }
                }
                viewModelScope.launch {
                    speechSynthesizer.speakLive(
                        text = speechSynthesizer.animalCatchphrase(animal),
                        animal = animal,
                        speechRate = 1.04f
                    )
                }
            }
            VoiceMode.KAHANI -> {
                _uiState.update { it.copy(isPreviewingVoice = true) }
                val clip = AnimalVoiceSynthesizer.renderAnimalClip(animal, gain * 0.8f)
                audioPlayer.playPcmOnce(clip, gain) {
                    _uiState.update { it.copy(isPreviewingVoice = false) }
                }
                val text = storyText?.trim()?.takeIf { it.isNotEmpty() }
                    ?: speechSynthesizer.storySamplePhrase(animal)
                viewModelScope.launch {
                    speechSynthesizer.speakLive(text = text, animal = animal, speechRate = 0.90f)
                }
            }
            VoiceMode.KHUD_KA -> {
                playRecordedVoice()
            }
        }
    }

    fun startVoiceRecording() {
        stopAudio()
        if (!voiceRecorder.hasRecordPermission()) {
            _uiState.update {
                it.copy(snackbarMessage = "Mic permission zaruri hai awaz record karne ke liye!")
            }
            return
        }
        _uiState.update {
            it.copy(
                selectedVoiceMode = VoiceMode.KHUD_KA,
                isRecordingVoice = true,
                recordingAmplitude = 0.1f,
                recordedDurationSec = 0
            )
        }
        voiceRecorder.startRecording(
            onAmplitudeAndTime = { amp, sec ->
                _uiState.update {
                    it.copy(recordingAmplitude = amp, recordedDurationSec = sec)
                }
            },
            onError = { msg ->
                _uiState.update {
                    it.copy(isRecordingVoice = false, recordingAmplitude = 0f, snackbarMessage = msg)
                }
            }
        )
    }

    fun stopVoiceRecording() {
        val file = voiceRecorder.stopRecording()
        val sec = _uiState.value.recordedDurationSec.coerceAtLeast(if (file != null) 1 else 0)
        prefs.edit().putInt("recorded_voice_sec", sec).apply()
        _uiState.update {
            it.copy(
                isRecordingVoice = false,
                recordingAmplitude = 0f,
                recordedVoicePath = file?.absolutePath,
                recordedDurationSec = sec,
                snackbarMessage = if (file != null) {
                    "Aapki awaz record ho gayi (${sec}s)! Ab BANAO dabao."
                } else {
                    "Awaz record nahi ho saki, dobara try karo"
                }
            )
        }
    }

    fun playRecordedVoice() {
        val path = _uiState.value.recordedVoicePath ?: return
        stopAudio()
        _uiState.update { it.copy(isPreviewingVoice = true) }
        viewModelScope.launch {
            val pcm = withContext(Dispatchers.IO) {
                AnimalVoiceSynthesizer.readWavAs44100Mono(File(path))
            }
            if (pcm != null && pcm.isNotEmpty()) {
                audioPlayer.playPcmOnce(pcm, _uiState.value.soundGain) {
                    _uiState.update { it.copy(isPreviewingVoice = false) }
                }
            } else {
                _uiState.update {
                    it.copy(isPreviewingVoice = false, snackbarMessage = "Recorded awaz nahi mili")
                }
            }
        }
    }

    fun clearRecordedVoice() {
        stopAudio()
        voiceRecorder.clearRecording()
        prefs.edit().putInt("recorded_voice_sec", 0).apply()
        _uiState.update {
            it.copy(
                recordedVoicePath = null,
                recordedDurationSec = 0,
                snackbarMessage = "Recorded awaz hata di gayi"
            )
        }
    }

    fun notifyMicPermissionDenied() {
        _uiState.update {
            it.copy(snackbarMessage = "Awaz record karne ke liye Mic permission allow karein")
        }
    }

    fun toggleSongPreview(song: SongTrack) {
        val current = _uiState.value.previewingSong
        if (current == song) {
            stopAudio()
        } else {
            audioPlayer.playLoop(song, _uiState.value.soundGain)
            _uiState.update { it.copy(selectedSong = song, previewingSong = song) }
        }
    }

    fun stopAudio() {
        audioPlayer.stop()
        speechSynthesizer.stopSpeaking()
        _uiState.update { it.copy(previewingSong = null, isPreviewingVoice = false) }
    }

    fun randomizeAndStartBanao() {
        val randomAnimal = AnimalType.entries.random()
        val randomDance = DanceStyle.entries.random()
        val randomSong = SongTrack.entries.random()
        _uiState.update {
            it.copy(
                selectedAnimal = randomAnimal,
                selectedDance = randomDance,
                selectedDuration = DanceDuration.SEC_10,
                selectedSong = randomSong
            )
        }
        startBanao()
    }

    fun startBanao() {
        generationJob?.cancel()
        if (_uiState.value.isRecordingVoice) {
            stopVoiceRecording()
        }
        val state = _uiState.value
        audioPlayer.playLoop(state.selectedSong, state.soundGain)
        _uiState.update {
            it.copy(
                isGeneratingStory = false,
                activeStoryText = "",
                showPostVideoAd = false,
                previewingSong = state.selectedSong,
                generationState = GenerationState.Generating(0.02f, "Stage saj raha hai...")
            )
        }

        generationJob = viewModelScope.launch {
            runCatching {
                VideoGenerator.generateDanceVideo(
                    context = appContext,
                    animal = state.selectedAnimal,
                    dance = state.selectedDance,
                    durationSeconds = state.selectedDuration.seconds,
                    song = state.selectedSong,
                    volumeGain = state.soundGain,
                    isPro = state.isPro,
                    voiceMode = state.selectedVoiceMode,
                    recordedVoicePath = state.recordedVoicePath,
                    onProgress = { progress, status ->
                        _uiState.update {
                            it.copy(
                                generationState = GenerationState.Generating(progress, status)
                            )
                        }
                    }
                )
            }.onSuccess { createdVideo ->
                stopAudio()
                incrementTotalVideosCreated()
                refreshSavedVideos()
                _uiState.update {
                    it.copy(
                        showPostVideoAd = !it.isPro,
                        generationState = GenerationState.Completed(createdVideo)
                    )
                }
            }.onFailure { err ->
                stopAudio()
                _uiState.update {
                    it.copy(
                        generationState = GenerationState.Error(
                            err.localizedMessage ?: "Video banane me dikkat aayi, dobara try karo!"
                        )
                    )
                }
            }
        }
    }

    fun startStoryBanao(
        storyText: String,
        animal: AnimalType,
        duration: StoryDuration,
        voiceMode: VoiceMode = VoiceMode.KAHANI
    ) {
        generationJob?.cancel()
        if (_uiState.value.isRecordingVoice) {
            stopVoiceRecording()
        }
        val state = _uiState.value
        val cleanedStory = storyText.trim()
        audioPlayer.playLoop(SongTrack.FUNNY_BOING, state.soundGain)

        _uiState.update {
            it.copy(
                selectedAnimal = animal,
                selectedDance = DanceStyle.FUNNY_DANCE,
                storyAnimal = animal,
                storyDuration = duration,
                selectedVoiceMode = voiceMode,
                isGeneratingStory = true,
                activeStoryText = cleanedStory,
                showPostVideoAd = false,
                previewingSong = SongTrack.FUNNY_BOING,
                generationState = GenerationState.Generating(0.02f, "Kahani ka stage saj raha hai...")
            )
        }

        generationJob = viewModelScope.launch {
            runCatching {
                VideoGenerator.generateStoryVideo(
                    context = appContext,
                    animal = animal,
                    storyText = cleanedStory,
                    durationSeconds = duration.seconds,
                    volumeGain = state.soundGain,
                    isPro = state.isPro,
                    voiceMode = voiceMode,
                    recordedVoicePath = state.recordedVoicePath,
                    onProgress = { progress, status ->
                        _uiState.update {
                            it.copy(
                                generationState = GenerationState.Generating(progress, status)
                            )
                        }
                    }
                )
            }.onSuccess { createdVideo ->
                stopAudio()
                incrementTotalVideosCreated()
                refreshSavedVideos()
                _uiState.update {
                    it.copy(
                        showPostVideoAd = !it.isPro,
                        generationState = GenerationState.Completed(createdVideo)
                    )
                }
            }.onFailure { err ->
                stopAudio()
                _uiState.update {
                    it.copy(
                        generationState = GenerationState.Error(
                            err.localizedMessage ?: "Kahani video banane me dikkat aayi!"
                        )
                    )
                }
            }
        }
    }

    private fun incrementTotalVideosCreated() {
        val nextCount = _uiState.value.totalVideosCreated + 1
        prefs.edit().putInt("total_videos_created", nextCount).apply()
        _uiState.update { it.copy(totalVideosCreated = nextCount) }
    }

    fun retryCurrentGeneration() {
        val state = _uiState.value
        if (state.isGeneratingStory) {
            startStoryBanao(state.activeStoryText, state.storyAnimal, state.storyDuration)
        } else {
            startBanao()
        }
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        generationJob = null
        stopAudio()
        _uiState.update { it.copy(generationState = GenerationState.Idle) }
    }

    fun resetGenerationToIdle() {
        stopAudio()
        _uiState.update { it.copy(generationState = GenerationState.Idle) }
    }

    fun updateAiScript(text: String) {
        _uiState.update { it.copy(aiScript = text) }
    }

    fun toggleAiAnimal(animal: AnimalType) {
        _uiState.update { state ->
            val current = state.aiSelectedAnimals
            val updated = if (animal in current) {
                if (current.size > 1) current - animal else current
            } else {
                (current + animal).take(3)
            }
            state.copy(aiSelectedAnimals = updated)
        }
    }

    fun selectAiAspectRatio(ratio: VideoAspectRatio) {
        _uiState.update { it.copy(aiAspectRatio = ratio) }
    }

    fun selectAiDuration(duration: VeoDuration) {
        _uiState.update { state ->
            val norm = normalizeVeoConfig(state.aiModel, state.aiResolution, duration)
            state.copy(
                aiModel = norm.model,
                aiResolution = norm.resolution,
                aiDuration = norm.duration,
                aiConfigNote = norm.adjustmentNote
            )
        }
    }

    fun selectAiResolution(resolution: VeoResolution) {
        _uiState.update { state ->
            val norm = normalizeVeoConfig(state.aiModel, resolution, state.aiDuration)
            state.copy(
                aiModel = norm.model,
                aiResolution = norm.resolution,
                aiDuration = norm.duration,
                aiConfigNote = norm.adjustmentNote
            )
        }
    }

    fun selectAiModel(model: VeoModel) {
        _uiState.update { state ->
            val norm = normalizeVeoConfig(model, state.aiResolution, state.aiDuration)
            state.copy(
                aiModel = norm.model,
                aiResolution = norm.resolution,
                aiDuration = norm.duration,
                aiConfigNote = norm.adjustmentNote
            )
        }
    }

    fun updateAiEnhancedPrompt(prompt: String) {
        _uiState.update { it.copy(aiEnhancedPrompt = prompt) }
    }

    fun saveCloudRunBackendUrl(rawUrl: String) {
        val normalized = VeoBackendClient.normalizeBackendUrl(rawUrl)
        prefs.edit().putString("cloud_run_backend_url", normalized).apply()
        _uiState.update {
            it.copy(
                cloudRunBackendUrl = normalized,
                backendStatusMessage = null,
                snackbarMessage = if (VeoBackendClient.isValidBackendUrl(normalized)) {
                    "Cloud Run Backend URL save ho gaya!"
                } else {
                    "Valid https://... Cloud Run URL dalein"
                }
            )
        }
    }

    fun testCloudRunConnection(rawUrl: String = _uiState.value.cloudRunBackendUrl) {
        val normalized = VeoBackendClient.normalizeBackendUrl(rawUrl)
        prefs.edit().putString("cloud_run_backend_url", normalized).apply()
        _uiState.update {
            it.copy(
                cloudRunBackendUrl = normalized,
                isCheckingBackend = true,
                backendStatusMessage = "Checking Cloud Run server..."
            )
        }
        viewModelScope.launch {
            VeoBackendClient.checkHealth(normalized)
                .onSuccess { health ->
                    val status = if (health.ok && health.apiKeyConfigured) {
                        "Connected! Veo 3.1 & Gemini Prompt ready (${health.promptModel})"
                    } else if (health.ok) {
                        "Server reachable, but GEMINI_API_KEY env var is missing on Cloud Run."
                    } else {
                        "Backend returned not-ready status."
                    }
                    _uiState.update {
                        it.copy(isCheckingBackend = false, backendStatusMessage = status)
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(
                            isCheckingBackend = false,
                            backendStatusMessage = "Connection failed: ${err.localizedMessage}"
                        )
                    }
                }
        }
    }

    fun enhanceAiPrompt() {
        val state = _uiState.value
        val script = state.aiScript.trim()
        if (script.isEmpty()) {
            _uiState.update { it.copy(snackbarMessage = "Pehle Hindi ya English me story/script likho!") }
            return
        }
        if (!VeoBackendClient.isValidBackendUrl(state.cloudRunBackendUrl)) {
            _uiState.update {
                it.copy(
                    aiPhase = AiGenerationPhase.Error(
                        message = "Cloud Run Backend URL configured nahi hai. Neeche Backend URL set karein.",
                        isBackendMissing = true
                    )
                )
            }
            return
        }

        aiGenerationJob?.cancel()
        _uiState.update { it.copy(aiPhase = AiGenerationPhase.EnhancingPrompt(script)) }
        aiGenerationJob = viewModelScope.launch {
            VeoBackendClient.enhancePrompt(
                backendUrl = state.cloudRunBackendUrl,
                script = script,
                animals = state.aiSelectedAnimals,
                aspectRatio = state.aiAspectRatio,
                duration = state.aiDuration
            ).onSuccess { result ->
                _uiState.update {
                    it.copy(
                        aiEnhancedPrompt = result.enhancedPrompt,
                        aiPhase = AiGenerationPhase.Idle,
                        snackbarMessage = "AI cinematic prompt taiyar ho gaya!"
                    )
                }
            }.onFailure { err ->
                val veoErr = err as? VeoApiException
                _uiState.update {
                    it.copy(
                        aiPhase = AiGenerationPhase.Error(
                            message = err.localizedMessage ?: "Prompt enhance karne me error aaya",
                            httpCode = veoErr?.httpCode,
                            isBillingOrAuthError = veoErr?.isBillingOrQuota == true,
                            isBackendMissing = veoErr?.isBackendNotConfigured == true
                        )
                    )
                }
            }
        }
    }

    fun requestStartAiVideo() {
        val state = _uiState.value
        if (state.aiScript.trim().isEmpty() && state.aiEnhancedPrompt.trim().isEmpty()) {
            _uiState.update { it.copy(snackbarMessage = "Pehle apni story ya prompt likho!") }
            return
        }
        if (!VeoBackendClient.isValidBackendUrl(state.cloudRunBackendUrl)) {
            _uiState.update {
                it.copy(
                    aiPhase = AiGenerationPhase.Error(
                        message = "Real AI Video (Veo 3.1) ke liye Cloud Run Backend URL zaruri hai. Settings me ya upar Backend section me URL save karein.",
                        isBackendMissing = true
                    )
                )
            }
            return
        }
        _uiState.update { it.copy(showAiBillingDialog = true) }
    }

    fun dismissAiBillingDialog() {
        _uiState.update { it.copy(showAiBillingDialog = false) }
    }

    fun confirmAndStartAiVideo() {
        val state = _uiState.value
        aiGenerationJob?.cancel()
        stopAudio()
        _uiState.update {
            it.copy(
                showAiBillingDialog = false,
                showPostVideoAd = false,
                aiPhase = AiGenerationPhase.SubmittingJob(
                    prompt = state.aiEnhancedPrompt.ifBlank { state.aiScript },
                    model = state.aiModel
                )
            )
        }

        aiGenerationJob = viewModelScope.launch {
            runCatching {
                VideoGenerator.generateRealAiVideo(
                    context = appContext,
                    backendUrl = state.cloudRunBackendUrl,
                    script = state.aiScript,
                    initialPrompt = state.aiEnhancedPrompt,
                    selectedAnimals = state.aiSelectedAnimals,
                    model = state.aiModel,
                    aspectRatio = state.aiAspectRatio,
                    duration = state.aiDuration,
                    resolution = state.aiResolution,
                    isPro = state.isPro,
                    onPhaseChanged = { phase ->
                        _uiState.update { cur ->
                            val updatedPrompt = when (phase) {
                                is AiGenerationPhase.SubmittingJob -> phase.prompt
                                is AiGenerationPhase.PollingOperation -> phase.prompt
                                else -> cur.aiEnhancedPrompt
                            }
                            cur.copy(aiPhase = phase, aiEnhancedPrompt = updatedPrompt)
                        }
                    }
                )
            }.onSuccess { createdVideo ->
                incrementTotalVideosCreated()
                refreshSavedVideos()
                _uiState.update {
                    it.copy(
                        showPostVideoAd = !it.isPro,
                        aiPhase = AiGenerationPhase.Completed(createdVideo)
                    )
                }
            }.onFailure { err ->
                val veoErr = err as? VeoApiException
                _uiState.update {
                    it.copy(
                        aiPhase = AiGenerationPhase.Error(
                            message = err.localizedMessage ?: "AI Video generation failed.",
                            httpCode = veoErr?.httpCode,
                            isBillingOrAuthError = veoErr?.isBillingOrQuota == true,
                            isBackendMissing = veoErr?.isBackendNotConfigured == true
                        )
                    )
                }
            }
        }
    }

    fun cancelAiGeneration() {
        aiGenerationJob?.cancel()
        aiGenerationJob = null
        _uiState.update { it.copy(aiPhase = AiGenerationPhase.Idle) }
    }

    fun resetAiPhase() {
        aiGenerationJob?.cancel()
        aiGenerationJob = null
        _uiState.update { it.copy(aiPhase = AiGenerationPhase.Idle) }
    }

    fun downloadVideo(video: CreatedVideo) {
        viewModelScope.launch {
            val result = VideoShareHelper.saveVideoToGallery(appContext, File(video.filePath))
            result.onSuccess { msg ->
                VideoGenerator.markSavedToGallery(appContext, video.id)
                refreshSavedVideos()
                _uiState.update { state ->
                    val updatedGen = (state.generationState as? GenerationState.Completed)?.let {
                        if (it.video.id == video.id) {
                            GenerationState.Completed(it.video.copy(savedToGallery = true))
                        } else it
                    } ?: state.generationState
                    val updatedAi = (state.aiPhase as? AiGenerationPhase.Completed)?.let {
                        if (it.video.id == video.id) {
                            AiGenerationPhase.Completed(it.video.copy(savedToGallery = true))
                        } else it
                    } ?: state.aiPhase
                    state.copy(
                        generationState = updatedGen,
                        aiPhase = updatedAi,
                        snackbarMessage = msg
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(snackbarMessage = err.localizedMessage ?: "Download nahi ho saka")
                }
            }
        }
    }

    fun deleteVideo(video: CreatedVideo) {
        val remaining = VideoGenerator.deleteVideo(appContext, video.id)
        _uiState.update {
            it.copy(
                savedVideos = remaining,
                snackbarMessage = "Purana video delete ho gaya!"
            )
        }
    }

    fun deleteAllVideos() {
        val remaining = VideoGenerator.deleteAllVideos(appContext)
        _uiState.update {
            it.copy(
                savedVideos = remaining,
                snackbarMessage = "Saare purane videos delete ho gaye!"
            )
        }
    }

    fun shareVideo(video: CreatedVideo, targetPackage: String?, appLabel: String) {
        stopAudio()
        val msg = VideoShareHelper.shareVideo(
            context = appContext,
            file = File(video.filePath),
            targetPackage = targetPackage,
            appLabel = appLabel
        )
        _uiState.update { it.copy(snackbarMessage = msg) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        voiceRecorder.stopRecording()
        audioPlayer.stop()
        speechSynthesizer.release()
    }
}
