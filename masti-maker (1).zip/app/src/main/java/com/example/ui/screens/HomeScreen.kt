package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.MastiMakerUiState
import com.example.ui.components.DancingAnimalStage3D
import com.example.ui.theme.CandyGreen
import com.example.ui.theme.CandyOrange
import com.example.ui.theme.CandyPink
import com.example.ui.theme.CandyPurple
import com.example.ui.theme.CandyTeal
import com.example.ui.theme.CandyYellow

@Composable
fun HomeScreen(
    uiState: MastiMakerUiState,
    onOpenAiVideo: () -> Unit,
    onOpenStudio: () -> Unit,
    onQuickDance: () -> Unit,
    onOpenVideos: () -> Unit,
    onOpenKahani: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPro: () -> Unit,
    onOpenProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Header: MASTI MAKER + Top Setting Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(10.dp, RoundedCornerShape(30.dp))
                    .clip(RoundedCornerShape(30.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(CandyOrange, CandyPink, CandyPurple)
                        )
                    )
                    .border(3.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(30.dp))
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = CandyYellow,
                                modifier = Modifier.size(30.dp)
                            )
                            Text(
                                text = stringResource(R.string.header_title),
                                style = MaterialTheme.typography.displayLarge.copy(fontSize = 30.sp),
                                color = Color.White,
                                modifier = Modifier.testTag("home_header_title")
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = stringResource(R.string.header_subtitle),
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White.copy(alpha = 0.92f)
                        )
                        if (uiState.userProfile.isLoggedIn) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                onClick = onOpenProfile,
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.22f),
                                modifier = Modifier.testTag("home_greeting_pill")
                            ) {
                                Text(
                                    text = if (uiState.userProfile.isOwner) {
                                        "Namaste, ${uiState.userProfile.name} (Owner)"
                                    } else {
                                        "Namaste, ${uiState.userProfile.name}"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Pro ₹50 Button
                        Surface(
                            onClick = onOpenPro,
                            shape = CircleShape,
                            color = if (uiState.isPro) CandyGreen else CandyYellow,
                            shadowElevation = 4.dp,
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("home_pro_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.WorkspacePremium,
                                    contentDescription = stringResource(R.string.pro_title),
                                    tint = if (uiState.isPro) Color.White else Color(0xFF1F1A38),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (uiState.isPro) {
                                        stringResource(R.string.pro_badge_active)
                                    } else {
                                        stringResource(R.string.pro_badge_short)
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (uiState.isPro) Color.White else Color(0xFF1F1A38),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Top Setting Button
                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            shadowElevation = 4.dp
                        ) {
                            IconButton(
                                onClick = onOpenSettings,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Settings,
                                    contentDescription = stringResource(R.string.settings_title),
                                    tint = Color(0xFF1F1A38),
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Cute 3D Animal Stage Preview
            DancingAnimalStage3D(
                animal = uiState.selectedAnimal,
                dance = uiState.selectedDance,
                isDancing = false,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            )

            // Real AI Video Studio (Google Veo 3.1) Card
            HomeOptionCard(
                title = stringResource(R.string.home_ai_video_title),
                subtitle = stringResource(R.string.home_ai_video_subtitle),
                icon = Icons.Filled.AutoAwesome,
                gradientColors = listOf(Color(0xFF1A237E), CandyPurple, CandyPink),
                badgeText = stringResource(R.string.home_ai_video_badge),
                testTag = "home_option_ai_video",
                onClick = onOpenAiVideo
            )

            // Alag Bada Button: KAHANI BANAO
            HomeOptionCard(
                title = stringResource(R.string.home_kahani_title),
                subtitle = stringResource(R.string.home_kahani_subtitle),
                icon = Icons.Filled.AutoStories,
                gradientColors = listOf(Color(0xFF8E2DE2), Color(0xFFFF3E8A)),
                badgeText = "1m / 2m Story",
                testTag = "home_option_kahani",
                onClick = onOpenKahani
            )

            // 3 Existing Home Options
            HomeOptionCard(
                title = stringResource(R.string.home_option_banao_title),
                subtitle = stringResource(R.string.home_option_banao_desc),
                icon = Icons.Filled.MovieCreation,
                gradientColors = listOf(Color(0xFFFF6B35), Color(0xFFFF3E8A)),
                badgeText = "4 Steps",
                testTag = "home_option_banao",
                onClick = onOpenStudio
            )

            HomeOptionCard(
                title = stringResource(R.string.home_option_jhatpat_title),
                subtitle = stringResource(R.string.home_option_jhatpat_desc),
                icon = Icons.Filled.Bolt,
                gradientColors = listOf(CandyTeal, Color(0xFF2ECC71)),
                badgeText = "Instant",
                testTag = "home_option_jhatpat",
                onClick = onQuickDance
            )

            HomeOptionCard(
                title = stringResource(R.string.home_option_videos_title),
                subtitle = stringResource(R.string.home_option_videos_desc),
                icon = Icons.Filled.VideoLibrary,
                gradientColors = listOf(CandyPurple, Color(0xFF2D9CFF)),
                badgeText = "${uiState.savedVideos.size} Videos",
                testTag = "home_option_videos",
                onClick = onOpenVideos
            )

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun HomeOptionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    gradientColors: List<Color>,
    badgeText: String,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(26.dp))
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.horizontalGradient(gradientColors))
            .border(2.5.dp, Color.White.copy(alpha = 0.65f), RoundedCornerShape(26.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
            .padding(horizontal = 18.dp, vertical = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.White.copy(alpha = 0.25f),
                modifier = Modifier.size(62.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Surface(
                    shape = CircleShape,
                    color = CandyYellow
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFF1F1A38),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.92f)
                )
            }

            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.25f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
