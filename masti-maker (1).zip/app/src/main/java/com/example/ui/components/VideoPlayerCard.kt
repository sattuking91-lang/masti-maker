package com.example.ui.components

import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

import androidx.compose.foundation.layout.widthIn

@Composable
fun VideoPlayerCard(
    videoPath: String,
    aspectRatio: Float = 1f,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember(videoPath) { mutableStateOf(true) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    DisposableEffect(videoPath) {
        onDispose {
            runCatching { videoViewRef?.stopPlayback() }
        }
    }

    val safeRatio = aspectRatio.coerceIn(0.45f, 2.2f)

    Box(
        modifier = modifier
            .then(
                if (safeRatio < 0.8f) {
                    Modifier.widthIn(max = 320.dp).fillMaxWidth()
                } else {
                    Modifier.fillMaxWidth()
                }
            )
            .aspectRatio(safeRatio)
            .clip(RoundedCornerShape(28.dp))
            .background(Color(0xFF1A103D))
            .border(4.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(28.dp))
    ) {
        AndroidView(
            factory = { ctx ->
                VideoView(ctx).apply {
                    setVideoURI(Uri.fromFile(File(videoPath)))
                    setOnPreparedListener { mp ->
                        mp.isLooping = true
                        start()
                        isPlaying = true
                    }
                    setOnCompletionListener {
                        isPlaying = false
                    }
                    videoViewRef = this
                }
            },
            update = { view ->
                videoViewRef = view
            },
            modifier = Modifier
                .fillMaxSize()
                .clickable {
                    val vv = videoViewRef ?: return@clickable
                    if (vv.isPlaying) {
                        vv.pause()
                        isPlaying = false
                    } else {
                        vv.start()
                        isPlaying = true
                    }
                }
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f)
            ) {
                IconButton(
                    onClick = {
                        val vv = videoViewRef ?: return@IconButton
                        if (vv.isPlaying) {
                            vv.pause()
                            isPlaying = false
                        } else {
                            vv.start()
                            isPlaying = true
                        }
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("video_play_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pause video" else "Play video",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f)
            ) {
                IconButton(
                    onClick = {
                        val vv = videoViewRef ?: return@IconButton
                        vv.seekTo(0)
                        vv.start()
                        isPlaying = true
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("video_replay_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Replay,
                        contentDescription = "Replay video",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}
