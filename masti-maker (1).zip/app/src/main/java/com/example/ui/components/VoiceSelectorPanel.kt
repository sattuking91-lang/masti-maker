package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.model.VoiceMode
import com.example.ui.theme.CandyGreen
import com.example.ui.theme.CandyPink
import com.example.ui.theme.CandyYellow

@Composable
fun VoiceSelectorPanel(
    selectedVoiceMode: VoiceMode,
    recordedVoicePath: String?,
    recordedDurationSec: Int,
    isRecordingVoice: Boolean,
    recordingAmplitude: Float,
    isPreviewingVoice: Boolean,
    onSelectVoiceMode: (VoiceMode) -> Unit,
    onPreviewVoice: (VoiceMode) -> Unit,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onPlayRecorded: () -> Unit,
    onClearRecorded: () -> Unit,
    onMicPermissionDenied: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onStartRecording()
        } else {
            onMicPermissionDenied()
        }
    }

    fun handleRecordClick() {
        if (isRecordingVoice) {
            onStopRecording()
        } else {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                onStartRecording()
            } else {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 3 Voice Options: 1. Janwar Bolega, 2. Kahani Voice, 3. Khud ka Voice
        VoiceMode.entries.forEach { mode ->
            val selected = selectedVoiceMode == mode
            val accent = Color(mode.colorHex)
            val icon: ImageVector = when (mode) {
                VoiceMode.JANWAR -> Icons.Filled.RecordVoiceOver
                VoiceMode.KAHANI -> Icons.Filled.AutoStories
                VoiceMode.KHUD_KA -> Icons.Filled.Mic
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(if (selected) 8.dp else 2.dp, RoundedCornerShape(22.dp))
                    .clip(RoundedCornerShape(22.dp))
                    .background(if (selected) accent else accent.copy(alpha = 0.12f))
                    .border(
                        width = if (selected) 3.dp else 1.5.dp,
                        color = if (selected) Color.White else accent.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .clickable {
                        onSelectVoiceMode(mode)
                        if (mode != VoiceMode.KHUD_KA) {
                            onPreviewVoice(mode)
                        }
                    }
                    .testTag("voice_card_${mode.id}")
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (selected) Color.White.copy(alpha = 0.25f) else accent.copy(alpha = 0.2f),
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = stringResource(mode.labelRes),
                            tint = if (selected) Color.White else accent,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = stringResource(mode.labelRes),
                            style = MaterialTheme.typography.titleMedium,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        if (selected) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Selected",
                                tint = CandyYellow,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Text(
                        text = stringResource(mode.descRes),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (selected) {
                            Color.White.copy(alpha = 0.92f)
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                if (mode != VoiceMode.KHUD_KA) {
                    Surface(
                        shape = CircleShape,
                        color = if (selected) Color.White else accent
                    ) {
                        IconButton(
                            onClick = {
                                onSelectVoiceMode(mode)
                                onPreviewVoice(mode)
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("voice_preview_${mode.id}")
                        ) {
                            Icon(
                                imageVector = if (isPreviewingVoice && selected) {
                                    Icons.Filled.GraphicEq
                                } else {
                                    Icons.Filled.PlayArrow
                                },
                                contentDescription = stringResource(R.string.voice_preview_btn),
                                tint = if (selected) accent else Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }
        }

        // Neeche Khud Ka Voice Record Control Box
        val recBgColor by animateColorAsState(
            targetValue = if (isRecordingVoice) {
                CandyPink.copy(alpha = 0.16f)
            } else {
                CandyGreen.copy(alpha = 0.13f)
            },
            label = "record_box_bg"
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(recBgColor)
                .border(
                    width = 2.dp,
                    color = if (isRecordingVoice) CandyPink else CandyGreen.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(14.dp)
                .testTag("voice_record_box"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isRecordingVoice) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GraphicEq,
                            contentDescription = null,
                            tint = CandyPink
                        )
                        Text(
                            text = "Recording chal rahi hai... ${recordedDurationSec}s",
                            style = MaterialTheme.typography.titleMedium,
                            color = CandyPink,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                LinearProgressIndicator(
                    progress = { recordingAmplitude.coerceIn(0.08f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(CircleShape),
                    color = CandyPink,
                    trackColor = Color.White,
                    strokeCap = StrokeCap.Round
                )
            }

            // Big Record / Stop Button at Bottom
            Button(
                onClick = ::handleRecordClick,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecordingVoice) CandyPink else CandyGreen,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("voice_record_button")
            ) {
                Icon(
                    imageVector = if (isRecordingVoice) Icons.Filled.Stop else Icons.Filled.Mic,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isRecordingVoice) {
                        stringResource(R.string.voice_record_stop)
                    } else {
                        stringResource(R.string.voice_record_start)
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (!isRecordingVoice && recordedVoicePath != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onSelectVoiceMode(VoiceMode.KHUD_KA)
                            onPlayRecorded()
                        },
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("voice_play_recorded_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${stringResource(R.string.voice_record_play)} (${recordedDurationSec}s)",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        shape = CircleShape,
                        color = CandyPink
                    ) {
                        IconButton(
                            onClick = onClearRecorded,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("voice_clear_recorded_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = stringResource(R.string.voice_record_delete),
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
