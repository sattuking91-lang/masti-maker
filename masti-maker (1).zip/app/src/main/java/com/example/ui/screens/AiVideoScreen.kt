package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AiGenerationPhase
import com.example.model.AnimalType
import com.example.model.CreatedVideo
import com.example.model.VeoDuration
import com.example.model.VeoModel
import com.example.model.VeoResolution
import com.example.model.VideoAspectRatio
import com.example.ui.MastiMakerUiState
import com.example.ui.components.PostVideoAdCard
import com.example.ui.components.ShareDownloadSection
import com.example.ui.components.VideoPlayerCard
import com.example.ui.theme.CandyBlue
import com.example.ui.theme.CandyGreen
import com.example.ui.theme.CandyOrange
import com.example.ui.theme.CandyPink
import com.example.ui.theme.CandyPurple
import com.example.ui.theme.CandyTeal
import com.example.ui.theme.CandyYellow
import com.example.video.VeoBackendClient

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiVideoScreen(
    uiState: MastiMakerUiState,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    onUpdateScript: (String) -> Unit,
    onToggleAnimal: (AnimalType) -> Unit,
    onSelectAspectRatio: (VideoAspectRatio) -> Unit,
    onSelectDuration: (VeoDuration) -> Unit,
    onSelectResolution: (VeoResolution) -> Unit,
    onSelectModel: (VeoModel) -> Unit,
    onUpdateEnhancedPrompt: (String) -> Unit,
    onSaveBackendUrl: (String) -> Unit,
    onTestBackend: (String) -> Unit,
    onEnhancePrompt: () -> Unit,
    onRequestGenerate: () -> Unit,
    onConfirmBillingAndGenerate: () -> Unit,
    onDismissBillingDialog: () -> Unit,
    onCancelGeneration: () -> Unit,
    onRetry: () -> Unit,
    onResetToEdit: () -> Unit,
    onDismissAd: () -> Unit,
    onOpenPro: () -> Unit,
    onDownload: (CreatedVideo) -> Unit,
    onShare: (CreatedVideo, String?, String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBack()
    }

    var showBackendConfig by remember(uiState.cloudRunBackendUrl) {
        mutableStateOf(!VeoBackendClient.isValidBackendUrl(uiState.cloudRunBackendUrl))
    }
    var draftBackendUrl by remember(uiState.cloudRunBackendUrl) {
        mutableStateOf(uiState.cloudRunBackendUrl)
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 620.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("ai_video_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.ai_video_screen_title),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Real Moving Animals • MP4",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    onClick = { showBackendConfig = !showBackendConfig },
                    shape = CircleShape,
                    color = if (VeoBackendClient.isValidBackendUrl(uiState.cloudRunBackendUrl)) {
                        CandyGreen.copy(alpha = 0.16f)
                    } else {
                        CandyOrange.copy(alpha = 0.18f)
                    },
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("ai_video_backend_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudQueue,
                            contentDescription = "Cloud Run Backend",
                            tint = if (VeoBackendClient.isValidBackendUrl(uiState.cloudRunBackendUrl)) {
                                CandyGreen
                            } else {
                                CandyOrange
                            },
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = if (VeoBackendClient.isValidBackendUrl(uiState.cloudRunBackendUrl)) {
                                "Backend Ready"
                            } else {
                                "Set Server"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Expandable Cloud Run Backend Config Card
            AnimatedVisibility(visible = showBackendConfig) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(CandyPurple.copy(alpha = 0.10f))
                        .border(2.dp, CandyPurple.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = stringResource(R.string.ai_video_backend_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Secure Google Cloud Run proxy URL (GEMINI_API_KEY backend par safe rehti hai, APK me nahi).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = draftBackendUrl,
                        onValueChange = { draftBackendUrl = it },
                        singleLine = true,
                        label = { Text("Cloud Run URL") },
                        placeholder = { Text(stringResource(R.string.ai_video_backend_hint)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_video_backend_url_input")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onSaveBackendUrl(draftBackendUrl) },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CandyPurple),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("ai_video_save_backend_button")
                        ) {
                            Text("Save URL", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { onTestBackend(draftBackendUrl) },
                            enabled = !uiState.isCheckingBackend,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("ai_video_test_backend_button")
                        ) {
                            Text(if (uiState.isCheckingBackend) "Testing..." else "Test Connection")
                        }
                    }
                    if (!uiState.backendStatusMessage.isNullOrBlank()) {
                        Text(
                            text = uiState.backendStatusMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CandyPurple,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            when (val phase = uiState.aiPhase) {
                is AiGenerationPhase.Idle,
                is AiGenerationPhase.EnhancingPrompt -> {
                    val isEnhancing = phase is AiGenerationPhase.EnhancingPrompt

                    // Clear Pre-generation Billing Disclosure Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(CandyYellow.copy(alpha = 0.22f))
                            .border(1.5.dp, CandyOrange.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Payments,
                            contentDescription = null,
                            tint = CandyOrange,
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.ai_video_billing_title),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Asli moving Veo 3.1 video API paid Cloud Billing & Cloud Run backend use karti hai. Photo animation nahi, asli MP4 banega.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // 1. Hindi / English Script Input
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(2.dp, CandyPink.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.ai_video_script_label),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedTextField(
                            value = uiState.aiScript,
                            onValueChange = onUpdateScript,
                            minLines = 3,
                            maxLines = 6,
                            placeholder = { Text(stringResource(R.string.ai_video_script_placeholder)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_video_script_input")
                        )

                        // Quick Test Idea Chips (including exact user test phrase)
                        val starterScripts = remember {
                            listOf(
                                "A cute cat dances with a puppy",
                                "Ek pyari billi aur kutta jungle me naach rahe hain",
                                "A playful monkey jumps and plays with a baby elephant"
                            )
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            starterScripts.forEachIndexed { idx, sample ->
                                FilterChip(
                                    selected = uiState.aiScript == sample,
                                    onClick = { onUpdateScript(sample) },
                                    label = { Text(sample, maxLines = 1) },
                                    modifier = Modifier.testTag("ai_sample_chip_$idx")
                                )
                            }
                        }
                    }

                    // 2. Animal Characters Selection (multi-select up to 3)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(2.dp, CandyTeal.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "${stringResource(R.string.ai_video_pick_animals)} (Max 3)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AnimalType.entries.forEach { animal ->
                                val selected = animal in uiState.aiSelectedAnimals
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(18.dp))
                                        .background(
                                            if (selected) Color(animal.accentHex) else Color(animal.cardBgHex)
                                        )
                                        .border(
                                            width = 2.dp,
                                            color = if (selected) Color.White else Color(animal.accentHex).copy(alpha = 0.4f),
                                            shape = RoundedCornerShape(18.dp)
                                        )
                                        .clickable { onToggleAnimal(animal) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                        .testTag("ai_animal_chip_${animal.id}"),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = animal.imageRes),
                                        contentDescription = stringResource(animal.labelRes),
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                    )
                                    Text(
                                        text = stringResource(animal.labelRes),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) Color.White else Color(0xFF1F1A38)
                                    )
                                }
                            }
                        }
                    }

                    // 3. Video Format (9:16 Reels/Shorts vs 16:9), Duration, Quality, Model
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(2.dp, CandyBlue.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.ai_video_aspect_ratio),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            VideoAspectRatio.entries.forEach { ratio ->
                                val selected = uiState.aiAspectRatio == ratio
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSelectAspectRatio(ratio) },
                                    label = { Text(ratio.label, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CandyPurple,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("ai_ratio_${ratio.apiValue}")
                                )
                            }
                        }

                        Text(
                            text = stringResource(R.string.ai_video_duration),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            VeoDuration.entries.forEach { dur ->
                                FilterChip(
                                    selected = uiState.aiDuration == dur,
                                    onClick = { onSelectDuration(dur) },
                                    label = { Text(dur.label, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CandyTeal,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("ai_duration_${dur.seconds}")
                                )
                            }
                        }

                        Text(
                            text = stringResource(R.string.ai_video_quality),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            VeoResolution.entries.forEach { res ->
                                FilterChip(
                                    selected = uiState.aiResolution == res,
                                    onClick = { onSelectResolution(res) },
                                    label = { Text(res.apiValue.uppercase(), fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CandyOrange,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("ai_resolution_${res.apiValue}")
                                )
                            }
                        }

                        Text(
                            text = stringResource(R.string.ai_video_model),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            VeoModel.entries.forEach { model ->
                                FilterChip(
                                    selected = uiState.aiModel == model,
                                    onClick = { onSelectModel(model) },
                                    label = { Text(model.displayName, fontWeight = FontWeight.Bold) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CandyPink,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("ai_model_${model.modelId}")
                                )
                            }
                        }

                        if (!uiState.aiConfigNote.isNullOrBlank()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Info,
                                    contentDescription = null,
                                    tint = CandyOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = uiState.aiConfigNote,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CandyOrange,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // 4. AI Cinematic Prompt Enhancement & Preview Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(CandyPurple.copy(alpha = 0.08f))
                            .border(2.dp, CandyPurple.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.ai_video_prompt_preview),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Button(
                                onClick = onEnhancePrompt,
                                enabled = !isEnhancing,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CandyPurple),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("ai_enhance_prompt_button")
                            ) {
                                if (isEnhancing) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Ban raha hai...")
                                } else {
                                    Icon(
                                        imageVector = Icons.Filled.AutoAwesome,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(stringResource(R.string.ai_video_enhance_prompt))
                                }
                            }
                        }

                        OutlinedTextField(
                            value = uiState.aiEnhancedPrompt,
                            onValueChange = onUpdateEnhancedPrompt,
                            minLines = 3,
                            maxLines = 6,
                            placeholder = {
                                Text("AI Prompt Banao dabao (ya Generate dabane par AI khud script ko cinematic prompt me badal dega)")
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_enhanced_prompt_input")
                        )
                    }

                    // 5. Big Generate AI Video CTA
                    Button(
                        onClick = onRequestGenerate,
                        enabled = !isEnhancing,
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CandyOrange,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(62.dp)
                            .testTag("ai_generate_video_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MovieCreation,
                            contentDescription = null,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.ai_video_generate_btn),
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                is AiGenerationPhase.SubmittingJob,
                is AiGenerationPhase.PollingOperation,
                is AiGenerationPhase.DownloadingMp4 -> {
                    RealOperationStatusCard(
                        phase = phase,
                        onCancel = onCancelGeneration
                    )
                }

                is AiGenerationPhase.Completed -> {
                    val video = phase.video
                    if (uiState.showPostVideoAd) {
                        PostVideoAdCard(
                            onSkipAd = onDismissAd,
                            onUpgradePro = onOpenPro
                        )
                    } else {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(22.dp))
                                .background(
                                    Brush.horizontalGradient(listOf(CandyPurple, CandyPink))
                                )
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Celebration,
                                contentDescription = null,
                                tint = CandyYellow,
                                modifier = Modifier.size(30.dp)
                            )
                            Column {
                                Text(
                                    text = "Real AI MP4 Video Ready!",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${video.aspectRatio} • ${video.resolution} • ${video.durationSeconds}s • ${video.veoModel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.9f)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            VideoPlayerCard(
                                videoPath = video.filePath,
                                aspectRatio = video.aspectRatioFloat,
                                modifier = Modifier.testTag("ai_generated_video_player")
                            )
                        }

                        if (video.aiPrompt.isNotBlank()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Prompt Used:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = video.aiPrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        ShareDownloadSection(
                            video = video,
                            onDownload = { onDownload(video) },
                            onShare = { pkg, label -> onShare(video, pkg, label) }
                        )

                        Button(
                            onClick = onResetToEdit,
                            shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CandyOrange),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("ai_make_another_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Naya AI Video Banao",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                is AiGenerationPhase.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.errorContainer)
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = "AI Video Error",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = if (phase.isBillingOrAuthError) {
                                "Cloud Billing / API Access Required"
                            } else if (phase.isBackendMissing) {
                                "Cloud Run Backend Setup Required"
                            } else {
                                "AI Video Error${phase.httpCode?.let { " (HTTP $it)" } ?: ""}"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = phase.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onRetry,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("ai_error_retry_button")
                            ) {
                                Text("Retry")
                            }
                            OutlinedButton(
                                onClick = {
                                    if (phase.isBackendMissing) {
                                        showBackendConfig = true
                                        onResetToEdit()
                                    } else {
                                        onResetToEdit()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("ai_error_edit_button")
                            ) {
                                Text(if (phase.isBackendMissing) "Set URL" else "Edit Script")
                            }
                        }
                        if (phase.isBackendMissing) {
                            TextButton(onClick = onOpenSettings) {
                                Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Open Full Settings")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (uiState.showAiBillingDialog) {
        AlertDialog(
            onDismissRequest = onDismissBillingDialog,
            title = { Text(stringResource(R.string.ai_video_billing_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.ai_video_billing_body))
                    Text(
                        text = "Model: ${uiState.aiModel.displayName} • ${uiState.aiAspectRatio.apiValue} • ${uiState.aiResolution.label} • ${uiState.aiDuration.label}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = onConfirmBillingAndGenerate,
                    colors = ButtonDefaults.buttonColors(containerColor = CandyOrange),
                    modifier = Modifier.testTag("ai_confirm_billing_generate_button")
                ) {
                    Text("Confirm & Generate")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissBillingDialog,
                    modifier = Modifier.testTag("ai_cancel_billing_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun RealOperationStatusCard(
    phase: AiGenerationPhase,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(CandyPurple.copy(alpha = 0.14f), CandyTeal.copy(alpha = 0.14f))
                )
            )
            .border(2.dp, CandyPurple.copy(alpha = 0.45f), RoundedCornerShape(28.dp))
            .padding(20.dp)
            .testTag("ai_real_status_card"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = when (phase) {
                    is AiGenerationPhase.SubmittingJob -> "Submitting to Veo 3.1..."
                    is AiGenerationPhase.PollingOperation -> "Veo 3.1 Generating Video..."
                    is AiGenerationPhase.DownloadingMp4 -> "Downloading Real MP4..."
                    else -> "Processing..."
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            if (phase is AiGenerationPhase.PollingOperation) {
                Surface(shape = CircleShape, color = CandyOrange) {
                    Text(
                        text = "${phase.elapsedSeconds}s",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Indeterminate server operation progress or real MP4 byte download progress
        if (phase is AiGenerationPhase.DownloadingMp4 && phase.totalBytes > 0L) {
            val fraction = (phase.bytesDownloaded.toFloat() / phase.totalBytes.toFloat()).coerceIn(0f, 1f)
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(14.dp)
                    .clip(CircleShape),
                color = CandyTeal,
                trackColor = Color.White
            )
            Text(
                text = "Downloaded ${phase.bytesDownloaded / 1024} KB / ${phase.totalBytes / 1024} KB",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
        } else {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(14.dp)
                    .clip(CircleShape)
                    .testTag("ai_indeterminate_progress"),
                color = CandyPurple,
                trackColor = Color.White
            )
        }

        when (phase) {
            is AiGenerationPhase.SubmittingJob -> {
                Text(
                    text = "Model: ${phase.model.modelId}\nPrompt: ${phase.prompt}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            is AiGenerationPhase.PollingOperation -> {
                Text(
                    text = "Operation Status: ${phase.serverStatus}\nOperation ID: ${phase.operationName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Asli Google Veo servers video render kar rahe hain (typically 45s–180s). Fake progress nahi dikhaya ja raha.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            is AiGenerationPhase.DownloadingMp4 -> {
                Text(
                    text = "Operation ${phase.operationName} complete! Saving real MP4 locally...",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            else -> {}
        }

        OutlinedButton(
            onClick = onCancel,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("ai_cancel_generation_button")
        ) {
            Text("Cancel Request")
        }
    }
}
