package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.model.AnimalType
import com.example.model.StoryDuration
import com.example.model.VoiceMode
import com.example.ui.theme.CandyOrange
import com.example.ui.theme.CandyPink
import com.example.ui.theme.CandyPurple
import com.example.ui.theme.CandyTeal
import com.example.ui.theme.CandyYellow

@Composable
fun KahaniMakerDialog(
    initialAnimal: AnimalType,
    initialDuration: StoryDuration,
    recordedVoicePath: String?,
    recordedDurationSec: Int,
    isRecordingVoice: Boolean,
    recordingAmplitude: Float,
    isPreviewingVoice: Boolean,
    onPreviewVoice: (VoiceMode, AnimalType, String) -> Unit,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onPlayRecorded: () -> Unit,
    onClearRecorded: () -> Unit,
    onMicPermissionDenied: () -> Unit,
    onDismiss: () -> Unit,
    onCreateStory: (storyText: String, animal: AnimalType, duration: StoryDuration, voiceMode: VoiceMode) -> Unit
) {
    var storyText by remember { mutableStateOf("") }
    var selectedAnimal by remember { mutableStateOf(initialAnimal) }
    var selectedDuration by remember { mutableStateOf(initialDuration) }
    var selectedVoiceMode by remember { mutableStateOf(VoiceMode.KAHANI) }
    var showEmptyError by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp)
                .testTag("kahani_likho_dialog"),
            shape = RoundedCornerShape(30.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = CandyPurple
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AutoStories,
                                contentDescription = null,
                                tint = CandyYellow,
                                modifier = Modifier
                                    .padding(8.dp)
                                    .size(26.dp)
                            )
                        }
                        Text(
                            text = stringResource(R.string.kahani_dialog_title),
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("kahani_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close"
                        )
                    }
                }

                // Story Text Input Box
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = stringResource(R.string.kahani_input_label),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(
                        value = storyText,
                        onValueChange = {
                            storyText = it
                            if (showEmptyError && it.isNotBlank()) showEmptyError = false
                        },
                        placeholder = {
                            Text(
                                text = stringResource(R.string.kahani_input_placeholder),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        },
                        isError = showEmptyError,
                        supportingText = if (showEmptyError) {
                            { Text(text = stringResource(R.string.kahani_empty_error)) }
                        } else null,
                        minLines = 4,
                        maxLines = 6,
                        shape = RoundedCornerShape(22.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CandyPurple,
                            unfocusedBorderColor = CandyPurple.copy(alpha = 0.45f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("kahani_text_input")
                    )
                }

                // Janwar Chuno
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.kahani_pick_animal),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        AnimalType.entries.forEach { animal ->
                            val isSelected = selectedAnimal == animal
                            val accent = Color(animal.accentHex)
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .width(88.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color(animal.cardBgHex))
                                    .border(
                                        width = if (isSelected) 3.5.dp else 1.5.dp,
                                        color = if (isSelected) accent else Color.White,
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .clickable { selectedAnimal = animal }
                                    .testTag("kahani_animal_${animal.id}")
                                    .padding(8.dp)
                            ) {
                                Box(modifier = Modifier.size(64.dp)) {
                                    Image(
                                        painter = painterResource(id = animal.imageRes),
                                        contentDescription = stringResource(animal.labelRes),
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(RoundedCornerShape(14.dp))
                                    )
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = "Selected",
                                            tint = accent,
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .size(20.dp)
                                                .background(Color.White, CircleShape)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = stringResource(animal.labelRes),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFF1F1A38),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Time Chuno: 1 Minute / 2 Minute
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.kahani_pick_time),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StoryDuration.entries.forEach { dur ->
                            val isSelected = selectedDuration == dur
                            val chipColor = Color(dur.colorHex)
                            Surface(
                                onClick = { selectedDuration = dur },
                                shape = RoundedCornerShape(20.dp),
                                color = if (isSelected) chipColor else chipColor.copy(alpha = 0.14f),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(54.dp)
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.5.dp,
                                        color = if (isSelected) Color.White else chipColor.copy(alpha = 0.5f),
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .testTag("kahani_duration_${dur.seconds}")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Timer,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else chipColor,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(dur.labelRes),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Voice Chuno (Kahani Voice / Janwar Bolega / Khud Ka Voice + Record Button)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.section_voice),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    VoiceSelectorPanel(
                        selectedVoiceMode = selectedVoiceMode,
                        recordedVoicePath = recordedVoicePath,
                        recordedDurationSec = recordedDurationSec,
                        isRecordingVoice = isRecordingVoice,
                        recordingAmplitude = recordingAmplitude,
                        isPreviewingVoice = isPreviewingVoice,
                        onSelectVoiceMode = { selectedVoiceMode = it },
                        onPreviewVoice = { mode ->
                            onPreviewVoice(mode, selectedAnimal, storyText)
                        },
                        onStartRecording = {
                            selectedVoiceMode = VoiceMode.KHUD_KA
                            onStartRecording()
                        },
                        onStopRecording = onStopRecording,
                        onPlayRecorded = onPlayRecorded,
                        onClearRecorded = onClearRecorded,
                        onMicPermissionDenied = onMicPermissionDenied
                    )
                }

                // BANAO! Button
                Button(
                    onClick = {
                        if (storyText.isBlank()) {
                            showEmptyError = true
                        } else {
                            onCreateStory(storyText, selectedAnimal, selectedDuration, selectedVoiceMode)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .shadow(10.dp, RoundedCornerShape(24.dp))
                        .testTag("kahani_banao_button"),
                    shape = RoundedCornerShape(24.dp),
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent,
                        contentColor = Color.White
                    )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(CandyPurple, CandyPink, CandyOrange)
                                )
                            )
                            .border(2.5.dp, Color.White, RoundedCornerShape(24.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MovieCreation,
                                contentDescription = stringResource(R.string.btn_banao),
                                tint = CandyYellow,
                                modifier = Modifier.size(30.dp)
                            )
                            Text(
                                text = stringResource(R.string.btn_banao),
                                style = MaterialTheme.typography.headlineMedium.copy(fontSize = 24.sp),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
