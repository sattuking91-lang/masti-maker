package com.example

import com.example.audio.MusicSynthesizer
import com.example.model.AnimalType
import com.example.model.DanceDuration
import com.example.model.DanceStyle
import com.example.model.OWNER_EMAIL
import com.example.model.SongTrack
import com.example.model.SoundLevel
import com.example.model.StoryDuration
import com.example.model.UserProfile
import com.example.model.isValidEmail
import com.example.video.StoryScriptHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun catalogCountsMatchSpecification() {
        assertEquals(6, AnimalType.entries.size)
        assertEquals(4, DanceStyle.entries.size)
        assertEquals(5, DanceDuration.entries.size)
        assertEquals(4, SongTrack.entries.size)
        assertEquals(2, StoryDuration.entries.size)
        assertEquals(3, SoundLevel.entries.size)
    }

    @Test
    fun musicSynthesizerRespectsVolumeGain() {
        SongTrack.entries.forEach { song ->
            val loud = MusicSynthesizer.renderChunk(song, 0, 2048, volumeGain = 1.0f)
            val soft = MusicSynthesizer.renderChunk(song, 0, 2048, volumeGain = 0.3f)
            assertEquals(2048, loud.size)
            assertTrue("Expected non-zero PCM signal for ${song.id}", loud.any { it != 0.toShort() })
            val loudPeak = loud.maxOf { kotlin.math.abs(it.toInt()) }
            val softPeak = soft.maxOf { kotlin.math.abs(it.toInt()) }
            assertTrue("Soft gain peak should be lower than loud peak", softPeak < loudPeak)
        }
    }

    @Test
    fun storyScriptHelperSplitsSentencesIntoScenes() {
        val scenes = StoryScriptHelper.splitStoryIntoScenes(
            "Ek din Billi jungle gayi. Waha usko Bandar mila! Dono ne milkar dance kiya.",
            "Fallback"
        )
        assertEquals(3, scenes.size)
    }

    @Test
    fun emailValidationAndOwnerDefaultsWorkCorrectly() {
        assertTrue(isValidEmail(OWNER_EMAIL))
        assertTrue(isValidEmail("priya.dance123@gmail.com"))
        assertFalse(isValidEmail(""))
        assertFalse(isValidEmail("not-an-email"))
        assertFalse(isValidEmail("bad@domain"))
        val defaultProfile = UserProfile()
        assertFalse(defaultProfile.isLoggedIn)
        assertFalse(defaultProfile.isOwner)
    }
}

