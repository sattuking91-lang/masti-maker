package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.MusicSynthesizer
import com.example.model.AnimalType
import com.example.model.DanceDuration
import com.example.model.DanceStyle
import com.example.model.SongTrack
import com.example.model.SoundLevel
import com.example.model.StoryDuration
import com.example.video.StoryScriptHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name and catalog counts match specification`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Masti Maker", appName)
        assertEquals(6, AnimalType.entries.size)
        assertEquals(4, DanceStyle.entries.size)
        assertEquals(5, DanceDuration.entries.size)
        assertEquals(4, SongTrack.entries.size)
        assertEquals(2, StoryDuration.entries.size)
        assertEquals(3, SoundLevel.entries.size)
    }

    @Test
    fun `music synthesizer generates non-silent audio and respects volume gain`() {
        SongTrack.entries.forEach { song ->
            val loud = MusicSynthesizer.renderChunk(song, 0, 2048, volumeGain = 1.0f)
            val soft = MusicSynthesizer.renderChunk(song, 0, 2048, volumeGain = 0.3f)
            assertEquals(2048, loud.size)
            assertTrue("Expected non-zero PCM signal for ${song.id}", loud.any { it != 0.toShort() })
            val loudPeak = loud.maxOf { kotlin.math.abs(it.toInt()) }
            val softPeak = soft.maxOf { kotlin.math.abs(it.toInt()) }
            assertTrue("Soft gain peak should be lower than loud peak", softPeak < loudPeak)
        }
    }

    @Test
    fun `story script helper splits multi-sentence story into scenes`() {
        val scenes = StoryScriptHelper.splitStoryIntoScenes(
            "Ek din Billi jungle gayi. Waha usko Bandar mila! Dono ne milkar dance kiya.",
            "Fallback"
        )
        assertEquals(3, scenes.size)
    }
}
