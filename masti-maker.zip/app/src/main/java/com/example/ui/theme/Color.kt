package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CandyOrange = Color(0xFFFF6B35)
val CandyPink = Color(0xFFFF3E8A)
val CandyTeal = Color(0xFF00C2A8)
val CandyYellow = Color(0xFFFFC928)
val CandyPurple = Color(0xFF6C4BFF)
val CandyGreen = Color(0xFF2ECC71)
val CandyBlue = Color(0xFF2D9CFF)

val CreamBackground = Color(0xFFFFFBF2)
val SoftSurface = Color(0xFFFFFFFF)
val SoftSurfaceVariant = Color(0xFFFFF1E0)
val DeepInk = Color(0xFF1F1A38)
val MutedInk = Color(0xFF5D5775)

val DarkBackground = Color(0xFF17132B)
val DarkSurface = Color(0xFF231D42)
val DarkSurfaceVariant = Color(0xFF2E2654)
val LightInk = Color(0xFFFFF9F0)

val WhatsAppGreen = Color(0xFF25D366)
val YouTubeRed = Color(0xFFFF0033)
val InstagramMagenta = Color(0xFFE1306C)
