package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPreviewPlayer
import com.example.model.AnimalType
import com.example.model.CreatedVideo
import com.example.model.DanceDuration
import com.example.model.DanceStyle
import com.example.model.OWNER_DEFAULT_NAME
import com.example.model.OWNER_EMAIL
import com.example.model.SongTrack
import com.example.model.StoryDuration
import com.example.model.UserProfile
import com.example.video.VideoGenerator
import com.example.video.VideoShareHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

sealed interface GenerationState {
    data object Idle : GenerationState
    data class Generating(val progress: Float, val statusText: String) : GenerationState
    data class Completed(val video: CreatedVideo) : GenerationState
    data class Error(val message: String) : GenerationState
}

data class MastiMakerUiState(
    val selectedAnimal: AnimalType = AnimalType.BILLI,
    val selectedDance: DanceStyle = DanceStyle.DJ_DANCE,
    val selectedDuration: DanceDuration = DanceDuration.SEC_10,
    val selectedSong: SongTrack = SongTrack.DJ_DHAMAKA,
    val previewingSong: SongTrack? = null,
    val generationState: GenerationState = GenerationState.Idle,
    val isGeneratingStory: Boolean = false,
    val activeStoryText: String = "",
    val storyAnimal: AnimalType = AnimalType.BILLI,
    val storyDuration: StoryDuration = StoryDuration.MIN_1,
    val soundGain: Float = 1.0f,
    val isPro: Boolean = false,
    val showPostVideoAd: Boolean = false,
    val userProfile: UserProfile = UserProfile(),
    val totalVideosCreated: Int = 0,
    val savedVideos: List<CreatedVideo> = emptyList(),
    val snackbarMessage: String? = null
)

class MastiMakerViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val prefs = appContext.getSharedPreferences("masti_prefs", Context.MODE_PRIVATE)
    private val audioPlayer = AudioPreviewPlayer(viewModelScope)
    private var generationJob: Job? = null

    private val _uiState = MutableStateFlow(
        MastiMakerUiState(
            soundGain = prefs.getFloat("sound_gain", 1.0f).coerceIn(0.2f, 1.0f),
            isPro = prefs.getBoolean("is_pro", false),
            userProfile = UserProfile(
                name = prefs.getString("user_name", "") ?: "",
                email = prefs.getString("user_email", "") ?: "",
                isLoggedIn = prefs.getBoolean("user_logged_in", false),
                isOwner = prefs.getBoolean("user_is_owner", false)
            ),
            totalVideosCreated = prefs.getInt("total_videos_created", 0)
        )
    )
    val uiState: StateFlow<MastiMakerUiState> = _uiState.asStateFlow()

    init {
        audioPlayer.setVolumeGain(_uiState.value.soundGain)
        refreshSavedVideos()
    }

    fun refreshSavedVideos() {
        val list = VideoGenerator.loadSavedVideos(appContext)
        val mergedTotal = maxOf(_uiState.value.totalVideosCreated, list.size)
        if (mergedTotal != _uiState.value.totalVideosCreated) {
            prefs.edit().putInt("total_videos_created", mergedTotal).apply()
        }
        _uiState.update { it.copy(savedVideos = list, totalVideosCreated = mergedTotal) }
    }

    fun loginWithEmail(name: String, email: String) {
        val cleanedName = name.trim().ifEmpty { "Masti Star" }
        val cleanedEmail = email.trim()
        val isOwner = cleanedEmail.equals(OWNER_EMAIL, ignoreCase = true)
        val profile = UserProfile(
            name = cleanedName,
            email = cleanedEmail,
            isLoggedIn = true,
            isOwner = isOwner
        )
        prefs.edit()
            .putBoolean("user_logged_in", true)
            .putString("user_name", profile.name)
            .putString("user_email", profile.email)
            .putBoolean("user_is_owner", profile.isOwner)
            .apply()
        _uiState.update {
            it.copy(
                userProfile = profile,
                snackbarMessage = if (isOwner) {
                    "Swagat hai Owner ${profile.name}!"
                } else {
                    "Swagat hai ${profile.name}! Login save ho gaya."
                }
            )
        }
    }

    fun enterOwnerMode() {
        val profile = UserProfile(
            name = OWNER_DEFAULT_NAME,
            email = OWNER_EMAIL,
            isLoggedIn = true,
            isOwner = true
        )
        prefs.edit()
            .putBoolean("user_logged_in", true)
            .putString("user_name", profile.name)
            .putString("user_email", profile.email)
            .putBoolean("user_is_owner", true)
            .apply()
        _uiState.update {
            it.copy(
                userProfile = profile,
                snackbarMessage = "Owner Mode Active — No Login!"
            )
        }
    }

    fun updateUserName(newName: String) {
        val cleaned = newName.trim()
        if (cleaned.isEmpty()) return
        prefs.edit().putString("user_name", cleaned).apply()
        _uiState.update { state ->
            state.copy(
                userProfile = state.userProfile.copy(name = cleaned),
                snackbarMessage = "Naam update ho gaya!"
            )
        }
    }

    fun logout() {
        stopAudio()
        prefs.edit()
            .putBoolean("user_logged_in", false)
            .putString("user_name", "")
            .putString("user_email", "")
            .putBoolean("user_is_owner", false)
            .apply()
        _uiState.update {
            it.copy(
                userProfile = UserProfile(),
                snackbarMessage = "Account logout ho gaya"
            )
        }
    }

    fun setSoundGain(gain: Float) {
        val clamped = gain.coerceIn(0.2f, 1.0f)
        prefs.edit().putFloat("sound_gain", clamped).apply()
        audioPlayer.setVolumeGain(clamped)
        _uiState.update { it.copy(soundGain = clamped) }
    }

    fun unlockPro() {
        prefs.edit().putBoolean("is_pro", true).apply()
        _uiState.update {
            it.copy(
                isPro = true,
                showPostVideoAd = false,
                snackbarMessage = "Pro Active! Ab bina 'Masti Maker' naam aur bina Ad ke video milega!"
            )
        }
    }

    fun resetToFreePlan() {
        prefs.edit().putBoolean("is_pro", false).apply()
        _uiState.update {
            it.copy(
                isPro = false,
                snackbarMessage = "Free Plan active: Video par watermark aur Ad dikhega"
            )
        }
    }

    fun dismissPostVideoAd() {
        _uiState.update { it.copy(showPostVideoAd = false) }
    }

    fun selectAnimal(animal: AnimalType) {
        _uiState.update { it.copy(selectedAnimal = animal) }
    }

    fun selectDance(dance: DanceStyle) {
        _uiState.update { it.copy(selectedDance = dance) }
    }

    fun selectDuration(duration: DanceDuration) {
        _uiState.update { it.copy(selectedDuration = duration) }
    }

    fun selectSong(song: SongTrack) {
        _uiState.update { it.copy(selectedSong = song) }
    }

    fun toggleSongPreview(song: SongTrack) {
        val current = _uiState.value.previewingSong
        if (current == song) {
            stopAudio()
        } else {
            audioPlayer.playLoop(song, _uiState.value.soundGain)
            _uiState.update { it.copy(selectedSong = song, previewingSong = song) }
        }
    }

    fun stopAudio() {
        audioPlayer.stop()
        _uiState.update { it.copy(previewingSong = null) }
    }

    fun randomizeAndStartBanao() {
        val randomAnimal = AnimalType.entries.random()
        val randomDance = DanceStyle.entries.random()
        val randomSong = SongTrack.entries.random()
        _uiState.update {
            it.copy(
                selectedAnimal = randomAnimal,
                selectedDance = randomDance,
                selectedDuration = DanceDuration.SEC_10,
                selectedSong = randomSong
            )
        }
        startBanao()
    }

    fun startBanao() {
        generationJob?.cancel()
        val state = _uiState.value
        audioPlayer.playLoop(state.selectedSong, state.soundGain)
        _uiState.update {
            it.copy(
                isGeneratingStory = false,
                activeStoryText = "",
                showPostVideoAd = false,
                previewingSong = state.selectedSong,
                generationState = GenerationState.Generating(0.02f, "Stage saj raha hai...")
            )
        }

        generationJob = viewModelScope.launch {
            runCatching {
                VideoGenerator.generateDanceVideo(
                    context = appContext,
                    animal = state.selectedAnimal,
                    dance = state.selectedDance,
                    durationSeconds = state.selectedDuration.seconds,
                    song = state.selectedSong,
                    volumeGain = state.soundGain,
                    isPro = state.isPro,
                    onProgress = { progress, status ->
                        _uiState.update {
                            it.copy(
                                generationState = GenerationState.Generating(progress, status)
                            )
                        }
                    }
                )
            }.onSuccess { createdVideo ->
                stopAudio()
                incrementTotalVideosCreated()
                refreshSavedVideos()
                _uiState.update {
                    it.copy(
                        showPostVideoAd = !it.isPro,
                        generationState = GenerationState.Completed(createdVideo)
                    )
                }
            }.onFailure { err ->
                stopAudio()
                _uiState.update {
                    it.copy(
                        generationState = GenerationState.Error(
                            err.localizedMessage ?: "Video banane me dikkat aayi, dobara try karo!"
                        )
                    )
                }
            }
        }
    }

    fun startStoryBanao(
        storyText: String,
        animal: AnimalType,
        duration: StoryDuration
    ) {
        generationJob?.cancel()
        val state = _uiState.value
        val cleanedStory = storyText.trim()
        audioPlayer.playLoop(SongTrack.FUNNY_BOING, state.soundGain)

        _uiState.update {
            it.copy(
                selectedAnimal = animal,
                selectedDance = DanceStyle.FUNNY_DANCE,
                storyAnimal = animal,
                storyDuration = duration,
                isGeneratingStory = true,
                activeStoryText = cleanedStory,
                showPostVideoAd = false,
                previewingSong = SongTrack.FUNNY_BOING,
                generationState = GenerationState.Generating(0.02f, "Kahani ka stage saj raha hai...")
            )
        }

        generationJob = viewModelScope.launch {
            runCatching {
                VideoGenerator.generateStoryVideo(
                    context = appContext,
                    animal = animal,
                    storyText = cleanedStory,
                    durationSeconds = duration.seconds,
                    volumeGain = state.soundGain,
                    isPro = state.isPro,
                    onProgress = { progress, status ->
                        _uiState.update {
                            it.copy(
                                generationState = GenerationState.Generating(progress, status)
                            )
                        }
                    }
                )
            }.onSuccess { createdVideo ->
                stopAudio()
                incrementTotalVideosCreated()
                refreshSavedVideos()
                _uiState.update {
                    it.copy(
                        showPostVideoAd = !it.isPro,
                        generationState = GenerationState.Completed(createdVideo)
                    )
                }
            }.onFailure { err ->
                stopAudio()
                _uiState.update {
                    it.copy(
                        generationState = GenerationState.Error(
                            err.localizedMessage ?: "Kahani video banane me dikkat aayi!"
                        )
                    )
                }
            }
        }
    }

    private fun incrementTotalVideosCreated() {
        val nextCount = _uiState.value.totalVideosCreated + 1
        prefs.edit().putInt("total_videos_created", nextCount).apply()
        _uiState.update { it.copy(totalVideosCreated = nextCount) }
    }

    fun retryCurrentGeneration() {
        val state = _uiState.value
        if (state.isGeneratingStory) {
            startStoryBanao(state.activeStoryText, state.storyAnimal, state.storyDuration)
        } else {
            startBanao()
        }
    }

    fun cancelGeneration() {
        generationJob?.cancel()
        generationJob = null
        stopAudio()
        _uiState.update { it.copy(generationState = GenerationState.Idle) }
    }

    fun resetGenerationToIdle() {
        stopAudio()
        _uiState.update { it.copy(generationState = GenerationState.Idle) }
    }

    fun downloadVideo(video: CreatedVideo) {
        viewModelScope.launch {
            val result = VideoShareHelper.saveVideoToGallery(appContext, File(video.filePath))
            result.onSuccess { msg ->
                VideoGenerator.markSavedToGallery(appContext, video.id)
                refreshSavedVideos()
                _uiState.update { state ->
                    val updatedGen = (state.generationState as? GenerationState.Completed)?.let {
                        if (it.video.id == video.id) {
                            GenerationState.Completed(it.video.copy(savedToGallery = true))
                        } else it
                    } ?: state.generationState
                    state.copy(generationState = updatedGen, snackbarMessage = msg)
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(snackbarMessage = err.localizedMessage ?: "Download nahi ho saka")
                }
            }
        }
    }

    fun deleteVideo(video: CreatedVideo) {
        val remaining = VideoGenerator.deleteVideo(appContext, video.id)
        _uiState.update {
            it.copy(
                savedVideos = remaining,
                snackbarMessage = "Purana video delete ho gaya!"
            )
        }
    }

    fun deleteAllVideos() {
        val remaining = VideoGenerator.deleteAllVideos(appContext)
        _uiState.update {
            it.copy(
                savedVideos = remaining,
                snackbarMessage = "Saare purane videos delete ho gaye!"
            )
        }
    }

    fun shareVideo(video: CreatedVideo, targetPackage: String?, appLabel: String) {
        stopAudio()
        val msg = VideoShareHelper.shareVideo(
            context = appContext,
            file = File(video.filePath),
            targetPackage = targetPackage,
            appLabel = appLabel
        )
        _uiState.update { it.copy(snackbarMessage = msg) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
    }
}
