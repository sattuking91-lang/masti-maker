package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SentimentVerySatisfied
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AnimalType
import com.example.model.DanceDuration
import com.example.model.DanceStyle
import com.example.model.SongTrack
import com.example.ui.MastiMakerUiState
import com.example.ui.theme.CandyGreen
import com.example.ui.theme.CandyOrange
import com.example.ui.theme.CandyPink
import com.example.ui.theme.CandyPurple
import com.example.ui.theme.CandyTeal
import com.example.ui.theme.CandyYellow

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioScreen(
    uiState: MastiMakerUiState,
    onSelectAnimal: (AnimalType) -> Unit,
    onSelectDance: (DanceStyle) -> Unit,
    onSelectDuration: (DanceDuration) -> Unit,
    onSelectSong: (SongTrack) -> Unit,
    onToggleSongPreview: (SongTrack) -> Unit,
    onOpenPro: () -> Unit,
    onBanaoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            // 1. Janwar Chuno
            SectionHeader(
                title = stringResource(R.string.section_janwar),
                accentColor = CandyOrange
            )

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val rows = AnimalType.entries.chunked(2)
                rows.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowItems.forEach { animal ->
                            AnimalCard(
                                animal = animal,
                                selected = uiState.selectedAnimal == animal,
                                onClick = { onSelectAnimal(animal) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 2. Dance Chuno
            SectionHeader(
                title = stringResource(R.string.section_dance),
                accentColor = CandyPink
            )

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val danceRows = DanceStyle.entries.chunked(2)
                danceRows.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowItems.forEach { dance ->
                            DanceStyleCard(
                                dance = dance,
                                selected = uiState.selectedDance == dance,
                                onClick = { onSelectDance(dance) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 3. Time Chuno
            SectionHeader(
                title = stringResource(R.string.section_time),
                accentColor = CandyPurple
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DanceDuration.entries.forEach { duration ->
                    DurationChipButton(
                        duration = duration,
                        selected = uiState.selectedDuration == duration,
                        onClick = { onSelectDuration(duration) }
                    )
                }
            }

            // 4. Gaana Chuno
            SectionHeader(
                title = stringResource(R.string.section_gaana),
                accentColor = CandyTeal
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SongTrack.entries.forEach { song ->
                    SongCard(
                        song = song,
                        selected = uiState.selectedSong == song,
                        isPlaying = uiState.previewingSong == song,
                        onSelect = { onSelectSong(song) },
                        onTogglePreview = { onToggleSongPreview(song) }
                    )
                }
            }

            // Free Watermark vs Pro ₹50 Pill
            Surface(
                onClick = onOpenPro,
                shape = RoundedCornerShape(20.dp),
                color = if (uiState.isPro) {
                    CandyGreen.copy(alpha = 0.14f)
                } else {
                    CandyYellow.copy(alpha = 0.25f)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.5.dp,
                        color = if (uiState.isPro) CandyGreen else CandyOrange,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .testTag("studio_pro_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.WorkspacePremium,
                        contentDescription = null,
                        tint = if (uiState.isPro) CandyGreen else CandyOrange,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (uiState.isPro) {
                            stringResource(R.string.pro_active_label)
                        } else {
                            stringResource(R.string.pro_free_note)
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 5. Big BANAO Button!
            Button(
                onClick = onBanaoClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .shadow(12.dp, RoundedCornerShape(28.dp))
                    .testTag("banao_button"),
                shape = RoundedCornerShape(28.dp),
                contentPadding = PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = Color.White
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(CandyOrange, CandyPink, CandyPurple)
                            )
                        )
                        .border(3.dp, Color.White, RoundedCornerShape(28.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MovieCreation,
                            contentDescription = stringResource(R.string.btn_banao),
                            tint = CandyYellow,
                            modifier = Modifier.size(34.dp)
                        )
                        Text(
                            text = stringResource(R.string.btn_banao),
                            style = MaterialTheme.typography.headlineMedium.copy(fontSize = 26.sp),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String, accentColor: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(14.dp, 28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(accentColor)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun AnimalCard(
    animal: AnimalType,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.03f else 1f,
        animationSpec = spring(dampingRatio = 0.55f),
        label = "animal_scale"
    )
    val accent = Color(animal.accentHex)

    Box(
        modifier = modifier
            .scale(scale)
            .shadow(if (selected) 10.dp else 4.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(Color(animal.cardBgHex))
            .border(
                width = if (selected) 4.dp else 2.dp,
                color = if (selected) accent else Color.White,
                shape = RoundedCornerShape(24.dp)
            )
            .clickable(onClick = onClick)
            .testTag("animal_card_${animal.id}")
            .padding(10.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(18.dp))
            ) {
                Image(
                    painter = painterResource(id = animal.imageRes),
                    contentDescription = stringResource(animal.labelRes),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (selected) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Selected",
                        tint = accent,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                            .size(28.dp)
                            .background(Color.White, CircleShape)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = CircleShape,
                color = if (selected) accent else Color.White.copy(alpha = 0.85f)
            ) {
                Text(
                    text = stringResource(animal.labelRes),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (selected) Color.White else Color(0xFF1F1A38),
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun DanceStyleCard(
    dance: DanceStyle,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val primary = Color(dance.primaryHex)
    val secondary = Color(dance.secondaryHex)
    val icon: ImageVector = when (dance) {
        DanceStyle.DJ_DANCE -> Icons.Filled.Headphones
        DanceStyle.HIP_HOP -> Icons.Filled.Speaker
        DanceStyle.GAON_WALA -> Icons.Filled.Celebration
        DanceStyle.FUNNY_DANCE -> Icons.Filled.SentimentVerySatisfied
    }

    Box(
        modifier = modifier
            .shadow(if (selected) 8.dp else 3.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(
                if (selected) {
                    Brush.linearGradient(listOf(primary, secondary))
                } else {
                    Brush.linearGradient(
                        listOf(
                            primary.copy(alpha = 0.14f),
                            secondary.copy(alpha = 0.14f)
                        )
                    )
                }
            )
            .border(
                width = if (selected) 3.dp else 1.5.dp,
                color = if (selected) Color.White else primary.copy(alpha = 0.4f),
                shape = RoundedCornerShape(22.dp)
            )
            .clickable(onClick = onClick)
            .testTag("dance_card_${dance.id}")
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (selected) Color.White.copy(alpha = 0.25f) else primary.copy(alpha = 0.18f),
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = stringResource(dance.labelRes),
                            tint = if (selected) Color.White else primary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
                if (selected) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Selected",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.DirectionsRun,
                        contentDescription = null,
                        tint = primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Text(
                text = stringResource(dance.labelRes),
                style = MaterialTheme.typography.titleMedium,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = dance.subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = if (selected) Color.White.copy(alpha = 0.92f) else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DurationChipButton(
    duration: DanceDuration,
    selected: Boolean,
    onClick: () -> Unit
) {
    val chipColor = Color(duration.colorHex)
    val bgColor by animateColorAsState(
        targetValue = if (selected) chipColor else chipColor.copy(alpha = 0.14f),
        label = "duration_bg"
    )

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = bgColor,
        modifier = Modifier
            .height(54.dp)
            .border(
                width = if (selected) 2.5.dp else 1.5.dp,
                color = if (selected) Color.White else chipColor.copy(alpha = 0.5f),
                shape = RoundedCornerShape(20.dp)
            )
            .testTag("duration_chip_${duration.seconds}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Timer,
                contentDescription = null,
                tint = if (selected) Color.White else chipColor,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = stringResource(duration.labelRes),
                style = MaterialTheme.typography.titleMedium,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun SongCard(
    song: SongTrack,
    selected: Boolean,
    isPlaying: Boolean,
    onSelect: () -> Unit,
    onTogglePreview: () -> Unit
) {
    val songColor = Color(song.colorHex)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(if (selected) 8.dp else 2.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(
                if (selected) songColor else songColor.copy(alpha = 0.12f)
            )
            .border(
                width = if (selected) 3.dp else 1.5.dp,
                color = if (selected) Color.White else songColor.copy(alpha = 0.45f),
                shape = RoundedCornerShape(22.dp)
            )
            .clickable(onClick = onSelect)
            .testTag("song_card_${song.id}")
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = CircleShape,
            color = if (selected) Color.White.copy(alpha = 0.25f) else songColor.copy(alpha = 0.2f),
            modifier = Modifier.size(48.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.GraphicEq else Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = if (selected) Color.White else songColor,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = stringResource(song.labelRes),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    shape = CircleShape,
                    color = if (selected) CandyYellow else songColor.copy(alpha = 0.22f)
                ) {
                    Text(
                        text = song.badge,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) Color(0xFF1F1A38) else songColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
            Text(
                text = if (isPlaying) "Baj raha hai..." else "Sunne ke liye Play dabao",
                style = MaterialTheme.typography.bodyMedium,
                color = if (selected) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Surface(
            shape = CircleShape,
            color = if (selected) Color.White else songColor
        ) {
            IconButton(
                onClick = onTogglePreview,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("song_preview_button_${song.id}")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Stop preview" else "Play preview",
                    tint = if (selected) songColor else Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
