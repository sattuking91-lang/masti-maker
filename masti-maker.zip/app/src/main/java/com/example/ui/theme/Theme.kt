package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = CandyOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF5A2510),
    onPrimaryContainer = Color(0xFFFFD8C8),
    secondary = CandyTeal,
    onSecondary = Color(0xFF002B25),
    secondaryContainer = Color(0xFF004D42),
    onSecondaryContainer = Color(0xFFB5FFF2),
    tertiary = CandyPink,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = LightInk,
    surface = DarkSurface,
    onSurface = LightInk,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFD2CCE8)
)

private val LightColorScheme = lightColorScheme(
    primary = CandyOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE4D6),
    onPrimaryContainer = Color(0xFF4A1804),
    secondary = CandyTeal,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3FFF7),
    onSecondaryContainer = Color(0xFF003B32),
    tertiary = CandyPink,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFD9E8),
    onTertiaryContainer = Color(0xFF4A0020),
    background = CreamBackground,
    onBackground = DeepInk,
    surface = SoftSurface,
    onSurface = DeepInk,
    surfaceVariant = SoftSurfaceVariant,
    onSurfaceVariant = MutedInk
)

val MastiShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(36.dp)
)

@Composable
fun MastiMakerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = MastiShapes,
        content = content
    )
}
