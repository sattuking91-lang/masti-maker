package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AnimalType
import com.example.model.DanceStyle
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun DancingAnimalStage3D(
    animal: AnimalType,
    dance: DanceStyle,
    isDancing: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "stage_3d")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isDancing) (60000 / dance.bpm) * 2 else 2200,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "dance_phase"
    )

    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isDancing) 2200 else 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    val primaryColor = Color(dance.primaryHex)
    val secondaryColor = Color(dance.secondaryHex)
    val density = LocalDensity.current.density

    val rotX: Float
    val rotY: Float
    val rotZ: Float
    val transX: Float
    val transY: Float
    val scaleX: Float
    val scaleY: Float

    if (!isDancing) {
        rotY = sin(phase) * 10f
        rotX = 0f
        rotZ = sin(phase) * 3f
        transX = 0f
        transY = -abs(sin(phase)) * 10f
        scaleX = 1f + sin(phase * 2f) * 0.02f
        scaleY = 1f - sin(phase * 2f) * 0.02f
    } else {
        when (dance) {
            DanceStyle.DJ_DANCE -> {
                rotY = sin(phase) * 28f
                rotX = cos(phase * 2f) * 10f
                rotZ = sin(phase) * 9f
                transX = sin(phase) * 18f
                transY = -abs(sin(phase * 2f)) * 28f
                scaleX = 1f + abs(sin(phase * 2f)) * 0.08f
                scaleY = 1f - abs(sin(phase * 2f)) * 0.05f
            }
            DanceStyle.HIP_HOP -> {
                rotY = cos(phase) * 24f
                rotX = sin(phase * 2f) * 16f
                rotZ = sin(phase) * 15f
                transX = sin(phase) * 34f
                transY = -abs(sin(phase * 2f)) * 22f
                scaleX = 1f + abs(sin(phase)) * 0.08f
                scaleY = 1f + abs(sin(phase)) * 0.06f
            }
            DanceStyle.GAON_WALA -> {
                rotY = sin(phase) * 20f
                rotX = sin(phase * 2f) * 12f
                rotZ = sin(phase * 2f) * 16f
                transX = sin(phase) * 24f
                transY = -abs(sin(phase * 2f)) * 42f
                scaleX = 1f - abs(sin(phase * 2f)) * 0.07f
                scaleY = 1f + abs(sin(phase * 2f)) * 0.10f
            }
            DanceStyle.FUNNY_DANCE -> {
                rotY = spinAngle
                rotX = cos(phase * 2f) * 18f
                rotZ = sin(phase * 2f) * 22f
                transX = sin(phase) * 20f
                transY = -abs(sin(phase * 2f)) * 34f
                scaleX = 1f + sin(phase * 4f) * 0.13f
                scaleY = 1f - sin(phase * 4f) * 0.13f
            }
        }
    }

    val confettiPalette = listOf(
        Color(0xFFFF6B35),
        Color(0xFFFF3E8A),
        Color(0xFF00E5FF),
        Color(0xFFFFD13B),
        Color(0xFF4CD964),
        Color(0xFFB388FF)
    )

    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.92f),
                        Color(0xFF23154F),
                        secondaryColor.copy(alpha = 0.85f)
                    )
                )
            )
            .border(3.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(28.dp)),
        contentAlignment = Alignment.Center
    ) {
        val stageSize = minOf(maxWidth, maxHeight)
        val animalCardSize = stageSize * 0.58f

        // Animated Stage Lights, Floor & Confetti Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val sweep = sin(phase) * w * 0.22f

            // Spotlight beams
            val beam1 = Path().apply {
                moveTo(w * 0.22f, 0f)
                lineTo(w * 0.30f, 0f)
                lineTo(w * 0.65f + sweep, h * 0.88f)
                lineTo(w * 0.35f + sweep, h * 0.88f)
                close()
            }
            drawPath(
                path = beam1,
                brush = Brush.verticalGradient(
                    colors = listOf(Color.White.copy(alpha = 0.35f), Color.Transparent)
                )
            )

            val beam2 = Path().apply {
                moveTo(w * 0.70f, 0f)
                lineTo(w * 0.78f, 0f)
                lineTo(w * 0.65f - sweep, h * 0.88f)
                lineTo(w * 0.35f - sweep, h * 0.88f)
                close()
            }
            drawPath(
                path = beam2,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFFEA70).copy(alpha = 0.32f), Color.Transparent)
                )
            )

            // Glowing stage floor
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(
                        secondaryColor.copy(alpha = 0.7f),
                        primaryColor.copy(alpha = 0.5f),
                        Color.Transparent
                    ),
                    center = Offset(w / 2f, h * 0.85f),
                    radius = w * 0.55f
                ),
                topLeft = Offset(w * 0.05f, h * 0.70f),
                size = androidx.compose.ui.geometry.Size(w * 0.9f, h * 0.32f)
            )

            // Dynamic shadow under animal
            val shadowScale = (1f - abs(transY) / 110f).coerceIn(0.6f, 1f)
            val shadowW = w * 0.38f * shadowScale
            val shadowH = 22f * shadowScale
            drawOval(
                color = Color.Black.copy(alpha = 0.35f),
                topLeft = Offset(w / 2f + transX - shadowW / 2f, h * 0.80f - shadowH / 2f),
                size = androidx.compose.ui.geometry.Size(shadowW, shadowH)
            )

            // Confetti particles when dancing
            if (isDancing) {
                for (i in 0 until 12) {
                    val cx = ((i * 89f + sin(phase + i) * 40f) % w + w) % w
                    val cy = ((i * 63f + (spinAngle / 360f) * h) % h)
                    val pColor = confettiPalette[i % confettiPalette.size]
                    rotate(degrees = spinAngle + i * 30f, pivot = Offset(cx, cy)) {
                        drawCircle(color = pColor, radius = 7f, center = Offset(cx, cy))
                    }
                }
            }
        }

        // Cute 3D Cartoon Animal Sticker with real 3D perspective transforms
        Box(
            modifier = Modifier
                .size(animalCardSize)
                .graphicsLayer {
                    cameraDistance = 14f * density
                    rotationX = rotX
                    rotationY = rotY
                    rotationZ = rotZ
                    translationX = transX
                    translationY = transY
                    this.scaleX = scaleX
                    this.scaleY = scaleY
                }
                .clip(RoundedCornerShape(28.dp))
                .background(Color(animal.cardBgHex))
                .border(4.dp, Color.White, RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = animal.imageRes),
                contentDescription = stringResource(animal.labelRes),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Top Stage Tag Pill
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp),
            shape = CircleShape,
            color = Color.Black.copy(alpha = 0.45f)
        ) {
            Text(
                text = "${stringResource(animal.labelRes)} • ${stringResource(dance.labelRes)}",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        // Playful animal sound bubble when actively dancing
        if (isDancing) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .offset(y = (-abs(sin(phase)) * 6).dp),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFFFD13B)
            ) {
                Text(
                    text = animal.funSound,
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFF1F1A38),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}
