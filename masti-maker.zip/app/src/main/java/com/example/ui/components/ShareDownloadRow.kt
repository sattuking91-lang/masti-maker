package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.CreatedVideo
import com.example.ui.theme.CandyGreen
import com.example.ui.theme.CandyPurple
import com.example.ui.theme.CandyTeal
import com.example.ui.theme.InstagramMagenta
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.theme.YouTubeRed
import com.example.video.VideoShareHelper

@Composable
fun ShareDownloadSection(
    video: CreatedVideo,
    onDownload: () -> Unit,
    onShare: (targetPackage: String?, label: String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Big Download Button
        Button(
            onClick = onDownload,
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .testTag("download_video_button"),
            shape = RoundedCornerShape(22.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (video.savedToGallery) CandyGreen else CandyTeal,
                contentColor = Color.White
            )
        ) {
            Icon(
                imageVector = if (video.savedToGallery) Icons.Filled.CheckCircle else Icons.Filled.Download,
                contentDescription = stringResource(R.string.btn_download),
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = if (video.savedToGallery) {
                    stringResource(R.string.btn_downloaded)
                } else {
                    stringResource(R.string.btn_download)
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        // Share Title
        Text(
            text = "Dosto ke sath Share karo:",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        // Row 1: WhatsApp + YouTube
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onShare(VideoShareHelper.PACKAGE_WHATSAPP, "WhatsApp") },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("share_whatsapp_button"),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = WhatsAppGreen,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.Chat,
                    contentDescription = stringResource(R.string.btn_share_whatsapp),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.btn_share_whatsapp),
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Button(
                onClick = { onShare(VideoShareHelper.PACKAGE_YOUTUBE, "YouTube") },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("share_youtube_button"),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = YouTubeRed,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayCircleFilled,
                    contentDescription = stringResource(R.string.btn_share_youtube),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.btn_share_youtube),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }

        // Row 2: Instagram + More Share
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onShare(VideoShareHelper.PACKAGE_INSTAGRAM, "Instagram") },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("share_instagram_button"),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = InstagramMagenta,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.CameraAlt,
                    contentDescription = stringResource(R.string.btn_share_instagram),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.btn_share_instagram),
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Button(
                onClick = { onShare(null, "Share") },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("share_more_button"),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CandyPurple,
                    contentColor = Color.White
                )
            ) {
                Icon(
                    imageVector = Icons.Filled.Share,
                    contentDescription = stringResource(R.string.btn_share_more),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.btn_share_more),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}
