package com.example.audio

import com.example.model.SongTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh

object MusicSynthesizer {
    const val SAMPLE_RATE = 44100

    private val djMelody = floatArrayOf(
        523.25f, 659.25f, 783.99f, 1046.50f,
        783.99f, 659.25f, 587.33f, 783.99f,
        523.25f, 659.25f, 783.99f, 880.00f,
        783.99f, 659.25f, 523.25f, 392.00f
    )

    private val dholMelody = floatArrayOf(
        440.00f, 440.00f, 554.37f, 659.25f,
        587.33f, 554.37f, 440.00f, 392.00f,
        440.00f, 554.37f, 659.25f, 783.99f,
        659.25f, 587.33f, 554.37f, 440.00f
    )

    private val funnyMelody = floatArrayOf(
        523.25f, 0f, 659.25f, 587.33f,
        783.99f, 0f, 523.25f, 698.46f,
        880.00f, 783.99f, 659.25f, 523.25f,
        587.33f, 659.25f, 523.25f, 0f
    )

    private val partyMelody = floatArrayOf(
        587.33f, 739.99f, 880.00f, 1174.66f,
        880.00f, 739.99f, 659.25f, 880.00f,
        783.99f, 987.77f, 1174.66f, 880.00f,
        739.99f, 659.25f, 587.33f, 440.00f
    )

    fun renderChunk(
        song: SongTrack,
        startSample: Int,
        numSamples: Int,
        volumeGain: Float = 1.0f
    ): ShortArray {
        val out = ShortArray(numSamples)
        val samplesPerBeat = (SAMPLE_RATE * 60f / song.bpm).toInt()
        val samplesPerStep = samplesPerBeat / 2 // 8th-note steps
        val clampedGain = volumeGain.coerceIn(0.05f, 1.0f)

        for (i in 0 until numSamples) {
            val globalSample = startSample + i
            val stepIndex = globalSample / samplesPerStep
            val stepOffset = globalSample % samplesPerStep
            val tStep = stepOffset.toFloat() / SAMPLE_RATE
            val beatOffset = globalSample % samplesPerBeat
            val tBeat = beatOffset.toFloat() / SAMPLE_RATE

            val sample = when (song) {
                SongTrack.DJ_DHAMAKA -> synthesizeDj(globalSample, stepIndex, tStep, tBeat)
                SongTrack.DHOL_TADKA -> synthesizeDhol(globalSample, stepIndex, tStep, tBeat)
                SongTrack.FUNNY_BOING -> synthesizeFunny(globalSample, stepIndex, tStep, tBeat)
                SongTrack.MASTI_PARTY -> synthesizeParty(globalSample, stepIndex, tStep, tBeat)
            }

            val softClipped = tanh(sample * 0.9f) * clampedGain
            out[i] = (softClipped * 30000f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return out
    }

    private fun synthesizeDj(globalSample: Int, stepIndex: Int, tStep: Float, tBeat: Float): Float {
        // Punchy 4-on-the-floor kick
        val kickFreq = 45f + 110f * exp(-tBeat * 28f)
        val kick = sin(2.0 * PI * kickFreq * tBeat).toFloat() * exp(-tBeat * 11f) * 0.75f

        // Off-beat hi-hat noise
        val hatEnv = if (stepIndex % 2 == 1) exp(-tStep * 45f) * 0.25f else 0f
        val hatNoise = pseudoNoise(globalSample) * hatEnv

        // Bouncy synth bass
        val bassNote = if ((stepIndex / 4) % 2 == 0) 130.81f else 98.00f
        val bass = sin(2.0 * PI * bassNote * tStep).toFloat() * exp(-tStep * 7f) * 0.35f

        // Bright arpeggio lead
        val freq = djMelody[stepIndex % djMelody.size]
        val leadEnv = exp(-tStep * 8.5f)
        val lead = (sin(2.0 * PI * freq * tStep).toFloat() +
            0.35f * sin(4.0 * PI * freq * tStep).toFloat()) * leadEnv * 0.32f

        return kick + hatNoise + bass + lead
    }

    private fun synthesizeDhol(globalSample: Int, stepIndex: Int, tStep: Float, tBeat: Float): Float {
        // Desi dhol pattern across 8 steps
        val patternStep = stepIndex % 8
        val dhum = if (patternStep == 0 || patternStep == 3 || patternStep == 4) {
            val dholFreq = 62f + 75f * exp(-tStep * 22f)
            sin(2.0 * PI * dholFreq * tStep).toFloat() * exp(-tStep * 8.5f) * 0.85f
        } else 0f

        val chapak = if (patternStep == 2 || patternStep == 5 || patternStep == 6 || patternStep == 7) {
            val rim = sin(2.0 * PI * 360f * tStep).toFloat() * exp(-tStep * 24f)
            val slap = pseudoNoise(globalSample) * exp(-tStep * 36f)
            (rim * 0.45f + slap * 0.35f)
        } else 0f

        // Tumbi / folk plucked lead
        val freq = dholMelody[stepIndex % dholMelody.size]
        val tumbi = (sin(2.0 * PI * freq * tStep).toFloat() +
            0.4f * sin(6.0 * PI * freq * tStep).toFloat()) * exp(-tStep * 10f) * 0.34f

        // Light shaker on beat
        val shaker = pseudoNoise(globalSample * 3) * exp(-tBeat * 30f) * 0.12f

        return dhum + chapak + tumbi + shaker
    }

    private fun synthesizeFunny(globalSample: Int, stepIndex: Int, tStep: Float, tBeat: Float): Float {
        val patternStep = stepIndex % 16
        val freq = funnyMelody[patternStep]

        // Cartoon xylophone pop
        val xylo = if (freq > 0f) {
            sin(2.0 * PI * freq * tStep).toFloat() * exp(-tStep * 13f) * 0.48f
        } else 0f

        // Comedic spring "BOING!" every 4th step
        val boing = if (patternStep == 1 || patternStep == 5 || patternStep == 15) {
            val vibrato = 1f + 0.14f * sin(2.0 * PI * 18.0 * tStep).toFloat()
            val slideFreq = (220f + 380f * (1f - exp(-tStep * 6f))) * vibrato
            sin(2.0 * PI * slideFreq * tStep).toFloat() * exp(-tStep * 5.5f) * 0.45f
        } else 0f

        // Bouncy tuba bass
        val tubaFreq = if (patternStep % 4 < 2) 130.81f else 196.00f
        val tuba = sin(2.0 * PI * tubaFreq * tBeat).toFloat() * exp(-tBeat * 9f) * 0.42f

        val popPerc = pseudoNoise(globalSample) * exp(-tStep * 55f) * 0.15f
        return xylo + boing + tuba + popPerc
    }

    private fun synthesizeParty(globalSample: Int, stepIndex: Int, tStep: Float, tBeat: Float): Float {
        // Combined DJ kick + Dhol bounce + Carnival melody
        val kickFreq = 52f + 100f * exp(-tBeat * 24f)
        val kick = sin(2.0 * PI * kickFreq * tBeat).toFloat() * exp(-tBeat * 10f) * 0.7f

        val clap = if (stepIndex % 4 == 2) {
            pseudoNoise(globalSample) * exp(-tStep * 28f) * 0.45f
        } else 0f

        val freq = partyMelody[stepIndex % partyMelody.size]
        val brass = (sin(2.0 * PI * freq * tStep).toFloat() +
            0.35f * sin(4.0 * PI * freq * tStep).toFloat() +
            0.2f * sin(6.0 * PI * freq * tStep).toFloat()) * exp(-tStep * 7.5f) * 0.32f

        val bassFreq = if ((stepIndex / 4) % 2 == 0) 146.83f else 110.00f
        val bass = sin(2.0 * PI * bassFreq * tStep).toFloat() * exp(-tStep * 8f) * 0.35f

        return kick + clap + brass + bass
    }

    private fun pseudoNoise(seed: Int): Float {
        var x = seed * 747796405 + 2891336453.toInt()
        x = ((x ushr ((x ushr 28) + 4)) xor x) * 277803737
        x = (x ushr 22) xor x
        return (x and 0xFFFF) / 32768f - 1f
    }
}
