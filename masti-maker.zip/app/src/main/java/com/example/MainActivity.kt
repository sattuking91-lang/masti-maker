package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MovieCreation
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.MastiMakerViewModel
import com.example.ui.components.KahaniMakerDialog
import com.example.ui.components.ProUpgradeDialog
import com.example.ui.screens.DanceStageScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.screens.VideosScreen
import com.example.ui.theme.CandyOrange
import com.example.ui.theme.MastiMakerTheme

object MastiRoutes {
    const val ROUTE_HOME = "home"
    const val ROUTE_STUDIO = "studio"
    const val ROUTE_STAGE = "stage"
    const val ROUTE_VIDEOS = "videos"
    const val ROUTE_PROFILE = "profile"
    const val ROUTE_SETTINGS = "settings"
}

private data class BottomNavTab(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MastiMakerTheme {
                MastiMakerApp()
            }
        }
    }
}

@Composable
fun MastiMakerApp(viewModel: MastiMakerViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: MastiRoutes.ROUTE_HOME
    var showKahaniDialog by remember { mutableStateOf(false) }
    var showProDialog by remember { mutableStateOf(false) }

    LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_STOP) {
        viewModel.stopAudio()
    }

    LaunchedEffect(uiState.snackbarMessage) {
        val msg = uiState.snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    if (!uiState.userProfile.isLoggedIn) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            LoginScreen(
                onLogin = viewModel::loginWithEmail,
                onOwnerNoLogin = viewModel::enterOwnerMode,
                modifier = Modifier.padding(innerPadding)
            )
        }
        return
    }

    val tabs = remember {
        listOf(
            BottomNavTab(
                route = MastiRoutes.ROUTE_HOME,
                labelRes = R.string.nav_home,
                selectedIcon = Icons.Filled.Home,
                unselectedIcon = Icons.Outlined.Home,
                testTag = "nav_home_tab"
            ),
            BottomNavTab(
                route = MastiRoutes.ROUTE_STUDIO,
                labelRes = R.string.nav_banao,
                selectedIcon = Icons.Filled.MovieCreation,
                unselectedIcon = Icons.Outlined.MovieCreation,
                testTag = "nav_banao_tab"
            ),
            BottomNavTab(
                route = MastiRoutes.ROUTE_VIDEOS,
                labelRes = R.string.nav_videos,
                selectedIcon = Icons.Filled.VideoLibrary,
                unselectedIcon = Icons.Outlined.VideoLibrary,
                testTag = "nav_videos_tab"
            ),
            BottomNavTab(
                route = MastiRoutes.ROUTE_PROFILE,
                labelRes = R.string.nav_profile,
                selectedIcon = Icons.Filled.Person,
                unselectedIcon = Icons.Outlined.Person,
                testTag = "nav_profile_tab"
            )
        )
    }

    fun navigateTopTab(route: String) {
        viewModel.stopAudio()
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val showChromeNav = currentRoute != MastiRoutes.ROUTE_STAGE &&
        currentRoute != MastiRoutes.ROUTE_SETTINGS

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (showChromeNav && !useRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        tabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                modifier = Modifier.testTag(tab.testTag),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(tab.labelRes),
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = CandyOrange,
                                    indicatorColor = CandyOrange
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showChromeNav && useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        tabs.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopTab(tab.route) },
                                modifier = Modifier.testTag(tab.testTag),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = {
                                    Text(text = stringResource(tab.labelRes))
                                }
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = MastiRoutes.ROUTE_HOME
                    ) {
                        composable(MastiRoutes.ROUTE_HOME) {
                            HomeScreen(
                                uiState = uiState,
                                onOpenStudio = { navigateTopTab(MastiRoutes.ROUTE_STUDIO) },
                                onQuickDance = {
                                    viewModel.randomizeAndStartBanao()
                                    navController.navigate(MastiRoutes.ROUTE_STAGE)
                                },
                                onOpenVideos = { navigateTopTab(MastiRoutes.ROUTE_VIDEOS) },
                                onOpenKahani = { showKahaniDialog = true },
                                onOpenSettings = {
                                    viewModel.stopAudio()
                                    navController.navigate(MastiRoutes.ROUTE_SETTINGS)
                                },
                                onOpenPro = { showProDialog = true },
                                onOpenProfile = { navigateTopTab(MastiRoutes.ROUTE_PROFILE) }
                            )
                        }

                        composable(MastiRoutes.ROUTE_STUDIO) {
                            StudioScreen(
                                uiState = uiState,
                                onSelectAnimal = viewModel::selectAnimal,
                                onSelectDance = viewModel::selectDance,
                                onSelectDuration = viewModel::selectDuration,
                                onSelectSong = viewModel::selectSong,
                                onToggleSongPreview = viewModel::toggleSongPreview,
                                onOpenPro = { showProDialog = true },
                                onBanaoClick = {
                                    viewModel.startBanao()
                                    navController.navigate(MastiRoutes.ROUTE_STAGE)
                                }
                            )
                        }

                        composable(MastiRoutes.ROUTE_STAGE) {
                            DanceStageScreen(
                                uiState = uiState,
                                onBack = {
                                    viewModel.cancelGeneration()
                                    navController.popBackStack()
                                },
                                onRetry = { viewModel.retryCurrentGeneration() },
                                onDismissAd = viewModel::dismissPostVideoAd,
                                onOpenPro = { showProDialog = true },
                                onDownload = { video -> viewModel.downloadVideo(video) },
                                onShare = { video, pkg, label ->
                                    viewModel.shareVideo(video, pkg, label)
                                },
                                onMakeAnother = {
                                    viewModel.resetGenerationToIdle()
                                    navController.popBackStack(MastiRoutes.ROUTE_HOME, inclusive = false)
                                    navigateTopTab(MastiRoutes.ROUTE_STUDIO)
                                }
                            )
                        }

                        composable(MastiRoutes.ROUTE_VIDEOS) {
                            VideosScreen(
                                videos = uiState.savedVideos,
                                onGoToStudio = { navigateTopTab(MastiRoutes.ROUTE_STUDIO) },
                                onDownload = { video -> viewModel.downloadVideo(video) },
                                onShare = { video, pkg, label ->
                                    viewModel.shareVideo(video, pkg, label)
                                }
                            )
                        }

                        composable(MastiRoutes.ROUTE_PROFILE) {
                            ProfileScreen(
                                uiState = uiState,
                                onEditName = viewModel::updateUserName,
                                onOpenPro = { showProDialog = true },
                                onOpenSettings = {
                                    viewModel.stopAudio()
                                    navController.navigate(MastiRoutes.ROUTE_SETTINGS)
                                },
                                onLogout = viewModel::logout
                            )
                        }

                        composable(MastiRoutes.ROUTE_SETTINGS) {
                            SettingsScreen(
                                soundGain = uiState.soundGain,
                                isPro = uiState.isPro,
                                savedVideos = uiState.savedVideos,
                                onBack = { navController.popBackStack() },
                                onChangeSoundGain = viewModel::setSoundGain,
                                onOpenPro = { showProDialog = true },
                                onResetToFree = viewModel::resetToFreePlan,
                                onDeleteVideo = viewModel::deleteVideo,
                                onDeleteAllVideos = viewModel::deleteAllVideos
                            )
                        }
                    }
                }
            }
        }
    }

    if (showKahaniDialog) {
        KahaniMakerDialog(
            initialAnimal = uiState.storyAnimal,
            initialDuration = uiState.storyDuration,
            onDismiss = { showKahaniDialog = false },
            onCreateStory = { storyText, animal, duration ->
                showKahaniDialog = false
                viewModel.startStoryBanao(storyText, animal, duration)
                navController.navigate(MastiRoutes.ROUTE_STAGE)
            }
        )
    }

    if (showProDialog) {
        ProUpgradeDialog(
            isPro = uiState.isPro,
            onDismiss = { showProDialog = false },
            onUnlockPro = {
                viewModel.unlockPro()
                showProDialog = false
            }
        )
    }
}
