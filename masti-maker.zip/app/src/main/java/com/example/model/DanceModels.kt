package com.example.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.example.R

enum class AnimalType(
    val id: String,
    @StringRes val labelRes: Int,
    @DrawableRes val imageRes: Int,
    val cardBgHex: Long,
    val accentHex: Long,
    val funSound: String
) {
    BILLI(
        id = "billi",
        labelRes = R.string.animal_billi,
        imageRes = R.drawable.img_animal_billi_1795322414450,
        cardBgHex = 0xFFD6F0FF,
        accentHex = 0xFF0099FF,
        funSound = "Meow!"
    ),
    KUTTA(
        id = "kutta",
        labelRes = R.string.animal_kutta,
        imageRes = R.drawable.img_animal_kutta_1795322416556,
        cardBgHex = 0xFFD7F9E9,
        accentHex = 0xFF00B87C,
        funSound = "Bhow!"
    ),
    BANDAR(
        id = "bandar",
        labelRes = R.string.animal_bandar,
        imageRes = R.drawable.img_animal_bandar_1795322416910,
        cardBgHex = 0xFFFFF4C2,
        accentHex = 0xFFFF8C00,
        funSound = "Kho-Kho!"
    ),
    HATHI(
        id = "hathi",
        labelRes = R.string.animal_hathi,
        imageRes = R.drawable.img_animal_hathi_1795322432493,
        cardBgHex = 0xFFEAD9FF,
        accentHex = 0xFF7A3EFF,
        funSound = "Pawoo!"
    ),
    MURGA(
        id = "murga",
        labelRes = R.string.animal_murga,
        imageRes = R.drawable.img_animal_murga_1795322430737,
        cardBgHex = 0xFFFFE2D1,
        accentHex = 0xFFFF5722,
        funSound = "Kukdu-Koo!"
    ),
    SHER(
        id = "sher",
        labelRes = R.string.animal_sher,
        imageRes = R.drawable.img_animal_sher_1795322430668,
        cardBgHex = 0xFFFFD8E4,
        accentHex = 0xFFFF2D78,
        funSound = "Roar!"
    )
}

enum class DanceStyle(
    val id: String,
    @StringRes val labelRes: Int,
    val subtitle: String,
    val bpm: Int,
    val primaryHex: Long,
    val secondaryHex: Long
) {
    DJ_DANCE(
        id = "dj",
        labelRes = R.string.dance_dj,
        subtitle = "Disco lights & party beat",
        bpm = 128,
        primaryHex = 0xFF6C4BFF,
        secondaryHex = 0xFF00E5FF
    ),
    HIP_HOP(
        id = "hiphop",
        labelRes = R.string.dance_hiphop,
        subtitle = "Cool swag & street groove",
        bpm = 108,
        primaryHex = 0xFFFF3E8A,
        secondaryHex = 0xFFFFC928
    ),
    GAON_WALA(
        id = "gaon",
        labelRes = R.string.dance_gaon,
        subtitle = "Desi dhol & bhangra jump",
        bpm = 124,
        primaryHex = 0xFFFF6B35,
        secondaryHex = 0xFF2ECC71
    ),
    FUNNY_DANCE(
        id = "funny",
        labelRes = R.string.dance_funny,
        subtitle = "Wacky spin & jelly wobble",
        bpm = 136,
        primaryHex = 0xFF00C2A8,
        secondaryHex = 0xFFFFC928
    )
}

enum class DanceDuration(
    val seconds: Int,
    @StringRes val labelRes: Int,
    val colorHex: Long
) {
    SEC_10(10, R.string.time_10s, 0xFFFF6B35),
    SEC_20(20, R.string.time_20s, 0xFFFF3E8A),
    SEC_30(30, R.string.time_30s, 0xFF6C4BFF),
    MIN_1(60, R.string.time_1m, 0xFF00C2A8),
    MIN_2(120, R.string.time_2m, 0xFF2D9CFF)
}

enum class StoryDuration(
    val seconds: Int,
    @StringRes val labelRes: Int,
    val colorHex: Long
) {
    MIN_1(60, R.string.time_1m, 0xFF00C2A8),
    MIN_2(120, R.string.time_2m, 0xFF6C4BFF)
}

enum class SoundLevel(
    val gain: Float,
    @StringRes val labelRes: Int
) {
    DHEERE(0.30f, R.string.sound_dheere),
    MEDIUM(0.65f, R.string.sound_medium),
    TEZ(1.0f, R.string.sound_tez)
}

enum class SongTrack(
    val id: String,
    @StringRes val labelRes: Int,
    val badge: String,
    val bpm: Int,
    val colorHex: Long
) {
    DJ_DHAMAKA(
        id = "dj_dhamaka",
        labelRes = R.string.song_dj_dhamaka,
        badge = "DJ",
        bpm = 128,
        colorHex = 0xFF6C4BFF
    ),
    DHOL_TADKA(
        id = "dhol_tadka",
        labelRes = R.string.song_dhol_tadka,
        badge = "Dhol",
        bpm = 124,
        colorHex = 0xFFFF6B35
    ),
    FUNNY_BOING(
        id = "funny_boing",
        labelRes = R.string.song_funny_boing,
        badge = "Funny",
        bpm = 136,
        colorHex = 0xFF00C2A8
    ),
    MASTI_PARTY(
        id = "masti_party",
        labelRes = R.string.song_masti_party,
        badge = "DJ + Dhol",
        bpm = 132,
        colorHex = 0xFFFF3E8A
    )
}

data class CreatedVideo(
    val id: String,
    val filePath: String,
    val animal: AnimalType,
    val dance: DanceStyle,
    val durationSeconds: Int,
    val song: SongTrack,
    val createdAtMillis: Long,
    val savedToGallery: Boolean = false,
    val isStory: Boolean = false,
    val storyText: String = "",
    val hasWatermark: Boolean = true
)

const val OWNER_EMAIL = "satishkunjam750@gmail.com"
const val OWNER_DEFAULT_NAME = "Satish Kunjam"

data class UserProfile(
    val name: String = "",
    val email: String = "",
    val isLoggedIn: Boolean = false,
    val isOwner: Boolean = false
)

private val MASTI_EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

fun isValidEmail(email: String): Boolean = MASTI_EMAIL_REGEX.matches(email.trim())

