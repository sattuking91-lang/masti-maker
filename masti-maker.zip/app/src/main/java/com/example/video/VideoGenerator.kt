package com.example.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import com.example.audio.MusicSynthesizer
import com.example.model.AnimalType
import com.example.model.CreatedVideo
import com.example.model.DanceStyle
import com.example.model.SongTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.coroutineContext

object VideoGenerator {
    private const val VIDEO_WIDTH = 480
    private const val VIDEO_HEIGHT = 480
    private const val FPS = 12
    private const val AUDIO_SAMPLE_RATE = MusicSynthesizer.SAMPLE_RATE
    private const val INDEX_FILE_NAME = "videos_index.json"

    suspend fun generateDanceVideo(
        context: Context,
        animal: AnimalType,
        dance: DanceStyle,
        durationSeconds: Int,
        song: SongTrack,
        volumeGain: Float = 1.0f,
        isPro: Boolean = false,
        onProgress: (Float, String) -> Unit
    ): CreatedVideo = withContext(Dispatchers.Default) {
        val videosDir = File(context.filesDir, "videos").apply { mkdirs() }
        val id = System.currentTimeMillis().toString()
        val outFile = File(videosDir, "masti_${animal.id}_${dance.id}_$id.mp4")

        val renderer = DanceStageRenderer(
            context = context,
            animal = animal,
            dance = dance,
            song = song,
            showWatermark = !isPro,
            width = VIDEO_WIDTH,
            height = VIDEO_HEIGHT
        )
        encodeMp4(
            renderer = renderer,
            outFile = outFile,
            durationSeconds = durationSeconds,
            song = song,
            volumeGain = volumeGain,
            isStory = false,
            onProgress = onProgress
        )

        val created = CreatedVideo(
            id = id,
            filePath = outFile.absolutePath,
            animal = animal,
            dance = dance,
            durationSeconds = durationSeconds,
            song = song,
            createdAtMillis = System.currentTimeMillis(),
            isStory = false,
            storyText = "",
            hasWatermark = !isPro
        )
        saveVideoRecord(context, created)
        created
    }

    suspend fun generateStoryVideo(
        context: Context,
        animal: AnimalType,
        storyText: String,
        durationSeconds: Int,
        volumeGain: Float = 1.0f,
        isPro: Boolean = false,
        onProgress: (Float, String) -> Unit
    ): CreatedVideo = withContext(Dispatchers.Default) {
        val videosDir = File(context.filesDir, "videos").apply { mkdirs() }
        val id = System.currentTimeMillis().toString()
        val outFile = File(videosDir, "kahani_${animal.id}_$id.mp4")
        val storySong = SongTrack.FUNNY_BOING

        val renderer = StoryStageRenderer(
            context = context,
            animal = animal,
            storyText = storyText,
            totalDurationSeconds = durationSeconds,
            showWatermark = !isPro,
            width = VIDEO_WIDTH,
            height = VIDEO_HEIGHT
        )
        encodeMp4(
            renderer = renderer,
            outFile = outFile,
            durationSeconds = durationSeconds,
            song = storySong,
            volumeGain = volumeGain,
            isStory = true,
            onProgress = onProgress
        )

        val created = CreatedVideo(
            id = id,
            filePath = outFile.absolutePath,
            animal = animal,
            dance = DanceStyle.FUNNY_DANCE,
            durationSeconds = durationSeconds,
            song = storySong,
            createdAtMillis = System.currentTimeMillis(),
            isStory = true,
            storyText = storyText.trim(),
            hasWatermark = !isPro
        )
        saveVideoRecord(context, created)
        created
    }

    private suspend fun encodeMp4(
        renderer: StageFrameRenderer,
        outFile: File,
        durationSeconds: Int,
        song: SongTrack,
        volumeGain: Float,
        isStory: Boolean,
        onProgress: (Float, String) -> Unit
    ) {
        val frameBitmap = Bitmap.createBitmap(VIDEO_WIDTH, VIDEO_HEIGHT, Bitmap.Config.ARGB_8888)
        val frameCanvas = Canvas(frameBitmap)
        val argbPixels = IntArray(VIDEO_WIDTH * VIDEO_HEIGHT)

        onProgress(0.03f, if (isStory) "Kahani ka stage saj raha hai..." else "Stage saj raha hai...")

        var muxer: MediaMuxer? = null
        var videoCodec: MediaCodec? = null
        var audioCodec: MediaCodec? = null

        try {
            val videoFormat = MediaFormat.createVideoFormat(
                MediaFormat.MIMETYPE_VIDEO_AVC,
                VIDEO_WIDTH,
                VIDEO_HEIGHT
            ).apply {
                setInteger(
                    MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
                )
                setInteger(MediaFormat.KEY_BIT_RATE, 1_400_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            videoCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
                configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                start()
            }

            audioCodec = runCatching {
                val aFormat = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC,
                    AUDIO_SAMPLE_RATE,
                    1
                ).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                }
                MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
                    configure(aFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    start()
                }
            }.getOrNull()

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val totalFrames = durationSeconds * FPS
            val totalAudioSamples = durationSeconds * AUDIO_SAMPLE_RATE
            val samplesPerAudioChunk = 1024

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var muxerStarted = false

            val pendingVideoPackets = mutableListOf<Pair<ByteArray, MediaCodec.BufferInfo>>()
            val pendingAudioPackets = mutableListOf<Pair<ByteArray, MediaCodec.BufferInfo>>()

            val vBufferInfo = MediaCodec.BufferInfo()
            val aBufferInfo = MediaCodec.BufferInfo()

            fun tryStartMuxer() {
                if (muxerStarted) return
                val ready = videoTrackIndex >= 0 && (audioCodec == null || audioTrackIndex >= 0)
                if (ready) {
                    muxer?.start()
                    muxerStarted = true
                    pendingVideoPackets.forEach { (bytes, info) ->
                        muxer?.writeSampleData(videoTrackIndex, ByteBuffer.wrap(bytes), info)
                    }
                    pendingVideoPackets.clear()
                    pendingAudioPackets.forEach { (bytes, info) ->
                        muxer?.writeSampleData(audioTrackIndex, ByteBuffer.wrap(bytes), info)
                    }
                    pendingAudioPackets.clear()
                }
            }

            fun drainVideo(endOfStream: Boolean) {
                val codec = videoCodec ?: return
                while (true) {
                    val outIdx = codec.dequeueOutputBuffer(vBufferInfo, if (endOfStream) 5000L else 0L)
                    when {
                        outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> break
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            videoTrackIndex = muxer!!.addTrack(codec.outputFormat)
                            tryStartMuxer()
                        }
                        outIdx >= 0 -> {
                            val encoded = codec.getOutputBuffer(outIdx)
                            if (encoded != null && vBufferInfo.size > 0 &&
                                (vBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                            ) {
                                encoded.position(vBufferInfo.offset)
                                encoded.limit(vBufferInfo.offset + vBufferInfo.size)
                                if (muxerStarted) {
                                    muxer?.writeSampleData(videoTrackIndex, encoded, vBufferInfo)
                                } else {
                                    val copy = ByteArray(vBufferInfo.size)
                                    encoded.get(copy)
                                    val infoCopy = MediaCodec.BufferInfo().apply {
                                        set(0, copy.size, vBufferInfo.presentationTimeUs, vBufferInfo.flags)
                                    }
                                    pendingVideoPackets.add(copy to infoCopy)
                                }
                            }
                            codec.releaseOutputBuffer(outIdx, false)
                            if ((vBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                        }
                    }
                }
            }

            fun drainAudio(endOfStream: Boolean) {
                val codec = audioCodec ?: return
                while (true) {
                    val outIdx = codec.dequeueOutputBuffer(aBufferInfo, if (endOfStream) 5000L else 0L)
                    when {
                        outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> break
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            audioTrackIndex = muxer!!.addTrack(codec.outputFormat)
                            tryStartMuxer()
                        }
                        outIdx >= 0 -> {
                            val encoded = codec.getOutputBuffer(outIdx)
                            if (encoded != null && aBufferInfo.size > 0 &&
                                (aBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                            ) {
                                encoded.position(aBufferInfo.offset)
                                encoded.limit(aBufferInfo.offset + aBufferInfo.size)
                                if (muxerStarted) {
                                    muxer?.writeSampleData(audioTrackIndex, encoded, aBufferInfo)
                                } else {
                                    val copy = ByteArray(aBufferInfo.size)
                                    encoded.get(copy)
                                    val infoCopy = MediaCodec.BufferInfo().apply {
                                        set(0, copy.size, aBufferInfo.presentationTimeUs, aBufferInfo.flags)
                                    }
                                    pendingAudioPackets.add(copy to infoCopy)
                                }
                            }
                            codec.releaseOutputBuffer(outIdx, false)
                            if ((aBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                        }
                    }
                }
            }

            var audioSampleCursor = 0

            fun feedAudioUpTo(targetSamples: Int) {
                val codec = audioCodec ?: return
                while (audioSampleCursor < targetSamples) {
                    val inIdx = codec.dequeueInputBuffer(2000L)
                    if (inIdx < 0) {
                        drainAudio(false)
                        break
                    }
                    val count = minOf(samplesPerAudioChunk, totalAudioSamples - audioSampleCursor)
                    if (count <= 0) break
                    val pcm = MusicSynthesizer.renderChunk(
                        song = song,
                        startSample = audioSampleCursor,
                        numSamples = count,
                        volumeGain = volumeGain
                    )
                    val inBuf = codec.getInputBuffer(inIdx)!!
                    inBuf.clear()
                    inBuf.order(ByteOrder.LITTLE_ENDIAN)
                    for (s in pcm) {
                        inBuf.putShort(s)
                    }
                    val ptsUs = audioSampleCursor * 1_000_000L / AUDIO_SAMPLE_RATE
                    codec.queueInputBuffer(inIdx, 0, count * 2, ptsUs, 0)
                    audioSampleCursor += count
                    drainAudio(false)
                }
            }

            for (frameIdx in 0 until totalFrames) {
                coroutineContext.ensureActive()

                val timeSec = frameIdx.toFloat() / FPS
                renderer.drawFrame(frameCanvas, timeSec)
                frameBitmap.getPixels(argbPixels, 0, VIDEO_WIDTH, 0, 0, VIDEO_WIDTH, VIDEO_HEIGHT)

                var queued = false
                while (!queued) {
                    coroutineContext.ensureActive()
                    val inIdx = videoCodec.dequeueInputBuffer(5000L)
                    if (inIdx >= 0) {
                        val image = videoCodec.getInputImage(inIdx)
                        val ptsUs = frameIdx * 1_000_000L / FPS
                        if (image != null) {
                            writeArgbToYuv420Image(argbPixels, VIDEO_WIDTH, VIDEO_HEIGHT, image)
                            val cap = videoCodec.getInputBuffer(inIdx)?.capacity()
                                ?: (VIDEO_WIDTH * VIDEO_HEIGHT * 3 / 2)
                            videoCodec.queueInputBuffer(inIdx, 0, cap, ptsUs, 0)
                        } else {
                            val buf = videoCodec.getInputBuffer(inIdx)!!
                            buf.clear()
                            writeArgbToNv12Buffer(argbPixels, VIDEO_WIDTH, VIDEO_HEIGHT, buf)
                            videoCodec.queueInputBuffer(
                                inIdx, 0, VIDEO_WIDTH * VIDEO_HEIGHT * 3 / 2, ptsUs, 0
                            )
                        }
                        queued = true
                    } else {
                        drainVideo(false)
                    }
                }
                drainVideo(false)

                val targetAudio = (((frameIdx + 1).toLong() * AUDIO_SAMPLE_RATE) / FPS)
                    .toInt().coerceAtMost(totalAudioSamples)
                feedAudioUpTo(targetAudio)

                val progress = 0.05f + 0.90f * ((frameIdx + 1).toFloat() / totalFrames)
                val status = if (isStory) {
                    when {
                        progress < 0.30f -> "Kahani ke scenes ban rahe hain..."
                        progress < 0.65f -> "Janwar kahani suna raha hai..."
                        progress < 0.88f -> "Awaz aur music mix ho raha hai..."
                        else -> "Kahani video taiyar ho raha hai!"
                    }
                } else {
                    when {
                        progress < 0.30f -> "Janwar dance kar raha hai..."
                        progress < 0.60f -> "3D stage aur lights lag rahe hain..."
                        progress < 0.85f -> "Gaana aur beats mix ho rahe hain..."
                        else -> "Video taiyar ho raha hai!"
                    }
                }
                if (frameIdx % 3 == 0 || frameIdx == totalFrames - 1) {
                    onProgress(progress, status)
                    yield()
                }
            }

            var vEosQueued = false
            while (!vEosQueued) {
                val inIdx = videoCodec.dequeueInputBuffer(5000L)
                if (inIdx >= 0) {
                    val ptsUs = totalFrames * 1_000_000L / FPS
                    videoCodec.queueInputBuffer(
                        inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                    )
                    vEosQueued = true
                } else {
                    drainVideo(false)
                }
            }
            drainVideo(true)

            if (audioCodec != null) {
                feedAudioUpTo(totalAudioSamples)
                var aEosQueued = false
                while (!aEosQueued) {
                    val inIdx = audioCodec.dequeueInputBuffer(5000L)
                    if (inIdx >= 0) {
                        val ptsUs = totalAudioSamples * 1_000_000L / AUDIO_SAMPLE_RATE
                        audioCodec.queueInputBuffer(
                            inIdx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                        )
                        aEosQueued = true
                    } else {
                        drainAudio(false)
                    }
                }
                drainAudio(true)
            }

            onProgress(1f, "Video taiyar hai!")
        } finally {
            runCatching { videoCodec?.stop() }
            runCatching { videoCodec?.release() }
            runCatching { audioCodec?.stop() }
            runCatching { audioCodec?.release() }
            runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            renderer.release()
            if (!frameBitmap.isRecycled) frameBitmap.recycle()
        }
    }

    private fun writeArgbToYuv420Image(
        argb: IntArray,
        width: Int,
        height: Int,
        image: Image
    ) {
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val yBuf = yPlane.buffer
        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer
        val yRowStride = yPlane.rowStride
        val yPixStride = yPlane.pixelStride
        val uvRowStride = uPlane.rowStride
        val uvPixStride = uPlane.pixelStride

        for (j in 0 until height) {
            val yRowOffset = j * yRowStride
            val uvRowOffset = (j shr 1) * uvRowStride
            for (i in 0 until width) {
                val px = argb[j * width + i]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF

                val y = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(0, 255)
                yBuf.put(yRowOffset + i * yPixStride, y.toByte())

                if ((j and 1) == 0 && (i and 1) == 0) {
                    val u = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    val v = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    val uvPos = uvRowOffset + (i shr 1) * uvPixStride
                    uBuf.put(uvPos, u.toByte())
                    vBuf.put(uvPos, v.toByte())
                }
            }
        }
    }

    private fun writeArgbToNv12Buffer(
        argb: IntArray,
        width: Int,
        height: Int,
        buf: ByteBuffer
    ) {
        val frameSize = width * height
        var yIdx = 0
        var uvIdx = frameSize
        for (j in 0 until height) {
            for (i in 0 until width) {
                val px = argb[j * width + i]
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                val y = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(0, 255)
                buf.put(yIdx++, y.toByte())
                if ((j and 1) == 0 && (i and 1) == 0) {
                    val u = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    val v = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255)
                    buf.put(uvIdx++, u.toByte())
                    buf.put(uvIdx++, v.toByte())
                }
            }
        }
    }

    fun loadSavedVideos(context: Context): List<CreatedVideo> {
        val indexFile = File(File(context.filesDir, "videos"), INDEX_FILE_NAME)
        if (!indexFile.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(indexFile.readText())
            val list = mutableListOf<CreatedVideo>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val path = obj.getString("filePath")
                if (!File(path).exists()) continue
                val animal = AnimalType.entries.firstOrNull { it.id == obj.getString("animal") }
                    ?: AnimalType.BILLI
                val dance = DanceStyle.entries.firstOrNull { it.id == obj.getString("dance") }
                    ?: DanceStyle.DJ_DANCE
                val song = SongTrack.entries.firstOrNull { it.id == obj.getString("song") }
                    ?: SongTrack.DJ_DHAMAKA
                list.add(
                    CreatedVideo(
                        id = obj.getString("id"),
                        filePath = path,
                        animal = animal,
                        dance = dance,
                        durationSeconds = obj.getInt("durationSeconds"),
                        song = song,
                        createdAtMillis = obj.getLong("createdAtMillis"),
                        savedToGallery = obj.optBoolean("savedToGallery", false),
                        isStory = obj.optBoolean("isStory", false),
                        storyText = obj.optString("storyText", ""),
                        hasWatermark = obj.optBoolean("hasWatermark", true)
                    )
                )
            }
            list.sortedByDescending { it.createdAtMillis }
        }.getOrElse { emptyList() }
    }

    fun markSavedToGallery(context: Context, videoId: String) {
        val existing = loadSavedVideos(context).map {
            if (it.id == videoId) it.copy(savedToGallery = true) else it
        }
        persistList(context, existing)
    }

    fun deleteVideo(context: Context, videoId: String): List<CreatedVideo> {
        val existing = loadSavedVideos(context)
        val target = existing.firstOrNull { it.id == videoId }
        if (target != null) {
            runCatching { File(target.filePath).delete() }
        }
        val remaining = existing.filterNot { it.id == videoId }
        persistList(context, remaining)
        return remaining
    }

    fun deleteAllVideos(context: Context): List<CreatedVideo> {
        val existing = loadSavedVideos(context)
        existing.forEach { video ->
            runCatching { File(video.filePath).delete() }
        }
        persistList(context, emptyList())
        return emptyList()
    }

    private fun saveVideoRecord(context: Context, video: CreatedVideo) {
        val existing = loadSavedVideos(context).toMutableList()
        existing.add(0, video)
        persistList(context, existing)
    }

    private fun persistList(context: Context, list: List<CreatedVideo>) {
        val videosDir = File(context.filesDir, "videos").apply { mkdirs() }
        val indexFile = File(videosDir, INDEX_FILE_NAME)
        val arr = JSONArray()
        list.forEach { v ->
            arr.put(
                JSONObject().apply {
                    put("id", v.id)
                    put("filePath", v.filePath)
                    put("animal", v.animal.id)
                    put("dance", v.dance.id)
                    put("durationSeconds", v.durationSeconds)
                    put("song", v.song.id)
                    put("createdAtMillis", v.createdAtMillis)
                    put("savedToGallery", v.savedToGallery)
                    put("isStory", v.isStory)
                    put("storyText", v.storyText)
                    put("hasWatermark", v.hasWatermark)
                }
            )
        }
        indexFile.writeText(arr.toString())
    }
}
