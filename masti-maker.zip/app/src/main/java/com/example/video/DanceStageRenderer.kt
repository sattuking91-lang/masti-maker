package com.example.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.example.model.AnimalType
import com.example.model.DanceStyle
import com.example.model.SongTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class DanceStageRenderer(
    private val context: Context,
    private val animal: AnimalType,
    private val dance: DanceStyle,
    private val song: SongTrack,
    private val showWatermark: Boolean = true,
    private val width: Int = 480,
    private val height: Int = 480
) : StageFrameRenderer {
    private val animalBitmap: Bitmap = run {
        val opts = BitmapFactory.Options().apply {
            inSampleSize = 2
        }
        val raw = BitmapFactory.decodeResource(context.resources, animal.imageRes, opts)
        val targetSize = (width * 0.56f).toInt()
        Bitmap.createScaledBitmap(raw, targetSize, targetSize, true).also {
            if (it !== raw) raw.recycle()
        }
    }

    private val camera = Camera()
    private val matrix = Matrix()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spotlightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val floorPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
    }
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 24f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(175, 25, 20, 50)
    }

    private val confettiColors = intArrayOf(
        Color.parseColor("#FF6B35"),
        Color.parseColor("#FF3E8A"),
        Color.parseColor("#00E5FF"),
        Color.parseColor("#FFD13B"),
        Color.parseColor("#4CD964"),
        Color.parseColor("#A77BFF")
    )

    override fun drawFrame(canvas: Canvas, timeSeconds: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val beatHz = song.bpm / 60f
        val beatPhase = timeSeconds * beatHz * 2f * PI.toFloat()
        val beatPulse = abs(sin(beatPhase / 2f))

        // 1. Animated vibrant stage background
        val primary = (0xFF000000L or dance.primaryHex).toInt()
        val secondary = (0xFF000000L or dance.secondaryHex).toInt()
        val bgTop = blendColors(primary, Color.parseColor("#1D1147"), 0.45f)
        val bgBottom = blendColors(secondary, Color.parseColor("#2E1760"), 0.55f)
        bgPaint.shader = LinearGradient(0f, 0f, w, h, bgTop, bgBottom, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // 2. Stage spotlights
        drawSpotlights(canvas, w, h, timeSeconds, beatPulse)

        // 3. Stage floor
        val floorRect = RectF(-w * 0.1f, h * 0.72f, w * 1.1f, h * 1.15f)
        floorPaint.shader = RadialGradient(
            w / 2f, h * 0.8f, w * 0.55f,
            intArrayOf(
                blendColors(secondary, Color.WHITE, 0.25f),
                primary,
                Color.parseColor("#1A103D")
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawOval(floorRect, floorPaint)

        // 4. Compute 3D choreography parameters
        var rotY = 0f
        var rotX = 0f
        var rotZ = 0f
        var transX = 0f
        var transY = 0f
        var scaleX = 1f
        var scaleY = 1f

        when (dance) {
            DanceStyle.DJ_DANCE -> {
                rotY = sin(beatPhase * 0.5f) * 26f
                rotZ = sin(beatPhase * 0.5f) * 8f
                transY = -abs(sin(beatPhase)) * 28f
                scaleX = 1f + beatPulse * 0.08f
                scaleY = 1f - beatPulse * 0.05f
            }
            DanceStyle.HIP_HOP -> {
                transX = sin(beatPhase * 0.5f) * 34f
                transY = -abs(sin(beatPhase)) * 22f
                rotZ = sin(beatPhase * 0.5f) * 14f
                rotX = sin(beatPhase) * 14f
                rotY = cos(beatPhase * 0.5f) * 20f
                scaleX = 1f + beatPulse * 0.07f
                scaleY = 1f + beatPulse * 0.07f
            }
            DanceStyle.GAON_WALA -> {
                transY = -abs(sin(beatPhase * 1.1f)) * 42f
                transX = sin(beatPhase * 0.55f) * 24f
                rotZ = sin(beatPhase * 1.1f) * 15f
                rotY = sin(beatPhase * 0.55f) * 18f
                scaleX = 1f - abs(sin(beatPhase)) * 0.06f
                scaleY = 1f + abs(sin(beatPhase)) * 0.09f
            }
            DanceStyle.FUNNY_DANCE -> {
                rotY = (timeSeconds * 160f) % 360f
                rotZ = sin(beatPhase * 1.3f) * 22f
                rotX = cos(beatPhase) * 16f
                transY = -abs(sin(beatPhase * 1.2f)) * 36f
                scaleX = 1f + sin(beatPhase * 2f) * 0.14f
                scaleY = 1f - sin(beatPhase * 2f) * 0.14f
            }
        }

        // 5. Dynamic floor shadow
        val shadowScale = (1f - abs(transY) / 140f).coerceIn(0.55f, 1f)
        shadowPaint.color = Color.argb(120, 0, 0, 0)
        val shadowW = w * 0.28f * shadowScale
        val shadowH = 18f * shadowScale
        canvas.drawOval(
            w / 2f + transX - shadowW,
            h * 0.78f - shadowH,
            w / 2f + transX + shadowW,
            h * 0.78f + shadowH,
            shadowPaint
        )

        // 6. Glowing beat ring behind animal
        ringPaint.color = confettiColors[(timeSeconds * 2).toInt() % confettiColors.size]
        ringPaint.alpha = 180
        val ringRadius = animalBitmap.width * 0.55f + beatPulse * 14f
        canvas.drawCircle(w / 2f + transX, h * 0.48f + transY, ringRadius, ringPaint)

        // 7. Draw 3D transformed animal sticker card
        draw3DAnimal(canvas, w / 2f + transX, h * 0.48f + transY, rotX, rotY, rotZ, scaleX, scaleY)

        // 8. Confetti & floating musical notes
        drawConfettiAndNotes(canvas, w, h, timeSeconds)

        // 9. Top & bottom playful banner pill
        if (showWatermark) {
            val topPill = RectF(w * 0.22f, 18f, w * 0.78f, 56f)
            canvas.drawRoundRect(topPill, 20f, 20f, badgeBgPaint)
            textPaint.textSize = 22f
            canvas.drawText("MASTI MAKER", w / 2f, 45f, textPaint)
        }

        val bottomPill = RectF(w * 0.16f, h - 54f, w * 0.84f, h - 16f)
        canvas.drawRoundRect(bottomPill, 20f, 20f, badgeBgPaint)
        textPaint.textSize = 20f
        val animalName = context.getString(animal.labelRes)
        val danceName = context.getString(dance.labelRes)
        canvas.drawText("$animalName • $danceName", w / 2f, h - 28f, textPaint)
    }

    private fun drawSpotlights(
        canvas: Canvas,
        w: Float,
        h: Float,
        timeSeconds: Float,
        beatPulse: Float
    ) {
        val sweep = sin(timeSeconds * 2.2f) * w * 0.25f
        spotlightPaint.shader = LinearGradient(
            w * 0.2f, 0f, w * 0.5f + sweep, h * 0.85f,
            Color.argb((70 + beatPulse * 55).toInt(), 255, 255, 255),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        val path1 = Path().apply {
            moveTo(w * 0.18f, 0f)
            lineTo(w * 0.26f, 0f)
            lineTo(w * 0.65f + sweep, h * 0.85f)
            lineTo(w * 0.35f + sweep, h * 0.85f)
            close()
        }
        canvas.drawPath(path1, spotlightPaint)

        spotlightPaint.shader = LinearGradient(
            w * 0.8f, 0f, w * 0.5f - sweep, h * 0.85f,
            Color.argb((65 + beatPulse * 50).toInt(), 255, 230, 120),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        val path2 = Path().apply {
            moveTo(w * 0.74f, 0f)
            lineTo(w * 0.82f, 0f)
            lineTo(w * 0.65f - sweep, h * 0.85f)
            lineTo(w * 0.35f - sweep, h * 0.85f)
            close()
        }
        canvas.drawPath(path2, spotlightPaint)
    }

    private fun draw3DAnimal(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        rotX: Float,
        rotY: Float,
        rotZ: Float,
        scaleX: Float,
        scaleY: Float
    ) {
        val bw = animalBitmap.width.toFloat()
        val bh = animalBitmap.height.toFloat()

        camera.save()
        camera.setLocation(0f, 0f, -14f)
        camera.rotateX(rotX)
        camera.rotateY(rotY)
        camera.rotateZ(rotZ)
        camera.getMatrix(matrix)
        camera.restore()

        matrix.preScale(scaleX, scaleY)
        matrix.preTranslate(-bw / 2f, -bh / 2f)
        matrix.postTranslate(cx, cy)

        canvas.save()
        canvas.concat(matrix)

        // Rounded clip sticker frame so the 3D cartoon animal pops cleanly
        val cardRect = RectF(0f, 0f, bw, bh)
        val clipPath = Path().apply {
            addRoundRect(cardRect, 48f, 48f, Path.Direction.CW)
        }
        canvas.clipPath(clipPath)
        canvas.drawBitmap(animalBitmap, 0f, 0f, bitmapPaint)

        // Bright white sticker border
        ringPaint.color = Color.WHITE
        ringPaint.alpha = 235
        ringPaint.strokeWidth = 10f
        canvas.drawRoundRect(cardRect, 48f, 48f, ringPaint)
        canvas.restore()
    }

    private fun drawConfettiAndNotes(canvas: Canvas, w: Float, h: Float, timeSeconds: Float) {
        for (i in 0 until 14) {
            val seed = i * 47.3f
            val x = ((seed * 19f + sin(timeSeconds * 1.8f + i) * 35f) % w + w) % w
            val y = ((seed * 11f + timeSeconds * (95f + (i % 4) * 25f)) % h)
            particlePaint.color = confettiColors[i % confettiColors.size]
            particlePaint.alpha = 220
            if (i % 3 == 0) {
                canvas.drawCircle(x, y, 7f, particlePaint)
            } else {
                canvas.save()
                canvas.translate(x, y)
                canvas.rotate(timeSeconds * 140f + i * 35f)
                canvas.drawRect(-7f, -4f, 7f, 4f, particlePaint)
                canvas.restore()
            }
        }
    }

    private fun blendColors(c1: Int, c2: Int, ratio: Float): Int {
        val inv = 1f - ratio
        val r = (Color.red(c1) * inv + Color.red(c2) * ratio).toInt()
        val g = (Color.green(c1) * inv + Color.green(c2) * ratio).toInt()
        val b = (Color.blue(c1) * inv + Color.blue(c2) * ratio).toInt()
        return Color.rgb(r, g, b)
    }

    override fun release() {
        if (!animalBitmap.isRecycled) {
            animalBitmap.recycle()
        }
    }
}
