package com.example.video

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object VideoShareHelper {
    const val PACKAGE_WHATSAPP = "com.whatsapp"
    const val PACKAGE_YOUTUBE = "com.google.android.youtube"
    const val PACKAGE_INSTAGRAM = "com.instagram.android"

    suspend fun saveVideoToGallery(context: Context, sourceFile: File): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (!sourceFile.exists()) error("Video file nahi mili")
                val displayName = "MastiMaker_${sourceFile.nameWithoutExtension}.mp4"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(
                            MediaStore.Video.Media.RELATIVE_PATH,
                            "${Environment.DIRECTORY_MOVIES}/MastiMaker"
                        )
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("Gallery me save nahi ho saka")

                    resolver.openOutputStream(uri)?.use { out ->
                        sourceFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    } ?: error("Output stream open nahi hui")

                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    "Movies/MastiMaker me save ho gaya!"
                } else {
                    val moviesDir = File(
                        context.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
                        "MastiMaker"
                    ).apply { mkdirs() }
                    val destFile = File(moviesDir, displayName)
                    sourceFile.copyTo(destFile, overwrite = true)
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(destFile.absolutePath),
                        arrayOf("video/mp4"),
                        null
                    )
                    "Movies/MastiMaker me save ho gaya!"
                }
            }
        }

    fun shareVideo(
        context: Context,
        file: File,
        targetPackage: String?,
        appLabel: String
    ): String {
        if (!file.exists()) return "Video file nahi mili!"

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(
                Intent.EXTRA_TEXT,
                "Dekho mera Masti Maker 3D Animal Dance Video!"
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (targetPackage != null) {
            val targeted = Intent(baseIntent).apply { setPackage(targetPackage) }
            val resolved = context.packageManager.resolveActivity(targeted, 0)
            if (resolved != null) {
                context.startActivity(targeted)
                return "$appLabel me khul raha hai..."
            }
        }

        val chooser = Intent.createChooser(baseIntent, "Dance Video Share Karo").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
        return if (targetPackage != null) {
            "$appLabel install nahi hai — Share menu khola gaya!"
        } else {
            "Share menu khul gaya!"
        }
    }
}
